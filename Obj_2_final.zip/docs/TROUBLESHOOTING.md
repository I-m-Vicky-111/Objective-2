# Troubleshooting Guide

Common issues and solutions for the Multi-Platform Review Analysis system.

---

## Table of Contents

1. [Installation Issues](#installation-issues)
2. [Ollama Server Issues](#ollama-server-issues)
3. [Model Issues](#model-issues)
4. [Data Issues](#data-issues)
5. [Encoding Issues](#encoding-issues)
6. [Performance Issues](#performance-issues)
7. [Validation Issues](#validation-issues)
8. [Cloud Model Issues](#cloud-model-issues)

---

## Installation Issues

### "pip install fails with dependency conflicts"

**Solution**:
```bash
# Use fresh virtual environment
python -m venv venv
source venv/bin/activate  # Linux/macOS
# or
venv\Scripts\activate  # Windows

pip install --upgrade pip
pip install -r requirements.txt
```

### "ImportError: No module named 'src'"

**Solution**:
```bash
# Ensure you're in project root
cd "J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2"

# Add to PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:$(pwd)"  # Linux/macOS
# or
set PYTHONPATH=%PYTHONPATH%;%CD%  # Windows
```

---

## Ollama Server Issues

### "Connection refused: http://127.0.0.1:11434"

**Symptoms**:
```
requests.exceptions.ConnectionError: ('Connection aborted.', ConnectionRefusedError(10061, 'No connection could be made because the target machine actively refused it'))
```

**Solutions**:

1. **Check if Ollama is running**:
```bash
curl http://127.0.0.1:11434/api/version

# If fails, start Ollama:
ollama serve
```

2. **Check if port is blocked**:
```bash
# Windows:
netstat -an | findstr 11434

# Linux/macOS:
lsof -i :11434
```

3. **Try different port**:
```yaml
# config/config_alt.yaml
llm:
  server:
    base_url: "http://127.0.0.1:11435"  # Change port
```

Then restart Ollama with:
```bash
OLLAMA_HOST=127.0.0.1:11435 ollama serve
```

### "Ollama server times out"

**Symptoms**:
```
requests.exceptions.Timeout: HTTPConnectionPool... Read timed out. (read timeout=180)
```

**Solutions**:

1. **Increase timeout**:
```yaml
# config/config_alt.yaml
llm:
  server:
    timeout: 300  # Increase from 180 to 300
```

2. **Use smaller batch size**:
```yaml
batch_size: 3  # Reduce from 5
```

3. **Check system resources**:
```bash
# Windows:
tasklist | findstr ollama

# Linux/macOS:
top -p $(pgrep ollama)
```

---

## Model Issues

### "Model 'qwen2.5:3b-instruct' not found"

**Solution**:
```bash
# Pull the model
ollama pull qwen2.5:3b-instruct

# Verify it's available
ollama list | grep qwen
```

### "Model runs out of memory"

**Symptoms**:
```
CUDA out of memory. Tried to allocate X GiB...
```

**Solutions**:

1. **Use smaller model**:
```bash
ollama pull qwen2.5:1.5b-instruct
```

2. **Reduce batch size**:
```yaml
batch_size: 2  # Reduce from 5
```

3. **Use CPU instead of GPU**:
```bash
# Force CPU mode
OLLAMA_NUM_GPU=0 ollama serve
```

### "Model produces garbage output"

**Symptoms**:
- JSON parse errors every time
- Incoherent text
- Random characters

**Solutions**:

1. **Check model temperature**:
```yaml
temperature: 0.3  # Lower = more deterministic
```

2. **Increase max tokens**:
```yaml
tokens:
  sentiment_max: 500  # Increase from 300
```

3. **Try different model**:
```bash
ollama pull llama3:8b-instruct
```

---

## Data Issues

### "FileNotFoundError: data/raw/google.csv"

**Solution**:
```bash
# Check if files exist
ls -la data/raw/*.csv

# If missing, check directory structure
ls -la data/

# Create directories
mkdir -p data/raw data/processed data/results data/validation
```

### "UnicodeDecodeError when reading CSV"

**Symptoms**:
```
UnicodeDecodeError: 'charmap' codec can't decode byte 0x9d
```

**Solution**:
Already fixed in code, but if occurs:
```python
# Read with explicit encoding
df = pd.read_csv('file.csv', encoding='utf-8-sig')
```

### "Empty or invalid JSON in results"

**Solution**:
```bash
# Check if file is valid JSON
python -m json.tool data/results/analysis_results.json

# If corrupted, re-run pipeline
rm data/results/analysis_results.json
python run_pipeline.py --config config/config_alt.yaml
```

---

## Encoding Issues

### "UnicodeEncodeError: 'charmap' codec can't encode character"

**Symptoms**:
```
UnicodeEncodeError: 'charmap' codec can't encode character '\u2705' in position 33
```

**Solution**:
✅ **Already fixed** in these files:
- `run_pipeline_with_audit.py`
- `src/llm_analysis/ollama_analyzer.py`
- `test_all_components.py`

If still occurs in other files:
```python
import io
import sys

if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
```

### "Emojis display as ΓûêΓûêΓûê"

**Cause**: Output redirected to file loses UTF-8
**Solution**:
```powershell
# Don't redirect with >
python run_pipeline.py  # View in console

# If must redirect, use UTF-8:
python run_pipeline.py | Out-File -Encoding UTF8 output.log
```

---

## Performance Issues

### "Pipeline is very slow (>1 hour for 180 reviews)"

**Diagnosis**:
```bash
# Check CPU/GPU usage during run
# If CPU at 100%: bottleneck is compute
# If CPU at 20%: bottleneck is I/O or network
```

**Solutions**:

1. **Use GPU**:
```bash
# Check GPU is detected
nvidia-smi

# If not using GPU, restart Ollama
ollama serve
```

2. **Increase batch size** (if have RAM):
```yaml
batch_size: 10  # Increase from 5
```

3. **Use local models** (not cloud):
```yaml
llm:
  models:
    sentiment:
      name: "qwen2.5:3b-instruct"  # Not cloud
```

### "High memory usage (>16GB)"

**Solutions**:

1. **Reduce batch size**:
```yaml
batch_size: 3
```

2. **Use smaller model**:
```bash
ollama pull qwen2.5:1.5b-instruct
```

3. **Process in chunks**:
```bash
# Split data into smaller files
# Process each separately
```

---

## Validation Issues

### "Validation metrics are NaN or inf"

**Symptoms**:
```json
{
  "pearson_r": "NaN",
  "kappa_binned": "inf"
}
```

**Solutions**:

1. **Check ground truth data**:
```bash
# Ensure references.csv has valid sentiments
python -c "import pandas as pd; df = pd.read_csv('data/validation/references.csv'); print(df['human_sentiment'].describe())"
```

2. **Check model outputs**:
```bash
# Ensure analysis results exist
python -c "import json; d = json.load(open('data/results/analysis_results.json')); print(f'Batches: {len(d[\"batches\"])}')"
```

3. **Regenerate validation**:
```bash
rm data/results/validation_metrics.json
python validate.py
```

### "Low agreement (14%) - is this correct?"

**Yes**, this is expected with current setup:
- Synthetic data + small model = poor performance
- **Solution**: Follow implementation guide to achieve 70-80%

**Quick checks**:
```bash
# 1. Are you using real data?
head -1 data/raw/google.csv
# If you see "Menu creativity left us speechless..." = synthetic

# 2. What model are you using?
grep "name:" config/config_alt.yaml
# If qwen2.5:3b = small model

# 3. Check validation script
python check_validation_detailed.py
# Shows human vs model comparisons
```

---

## Cloud Model Issues

### "Cloud model not available"

**Symptoms**:
```
Model 'deepseek-v3.1:671b-cloud' not found
```

**Solutions**:

1. **Check Ollama cloud models**:
```bash
ollama list | grep cloud
```

2. **Pull cloud model** (if available):
```bash
ollama pull deepseek-v3.1:671b-cloud
```

3. **Use fallback**:
```yaml
llm:
  models:
    sentiment:
      name: "gpt-oss:120b-cloud"  # Try different cloud model
      fallback: "qwen2.5:3b-instruct"  # Local fallback
```

### "Cloud model is very slow (>5 min per review)"

**Expected behavior** for cloud models.

**Solutions**:

1. **Check rate limiting**:
```yaml
cloud:
  requests_per_minute: 10  # May need to reduce
```

2. **Use async processing** (future enhancement)

3. **Reduce timeout if stuck**:
```yaml
timeout: 300  # Reduce from 600
```

---

## JSON Parsing Issues

### "JSON parse failed: Expecting ',' delimiter"

**Already fixed** with 7-strategy repair system.

If still occurs:
```bash
# Check logs
cat logs/pipeline_audit.log | grep "JSON parse"

# Should see: "Successfully parsed X theme(s) from model response"
```

**Manual debugging**:
```python
from src.utils.json_repair import extract_and_repair_json

text = "```json\n{\"sentiments\": [...]}\n```"
result = extract_and_repair_json(text, expected_type="object")
print(result)
```

---

## Dataset Download Issues

### "Yelp dataset download fails"

**Solutions**:

1. **Check academic access**:
- Visit https://www.yelp.com/dataset
- Sign up with `.edu` email (instant approval)
- Download link in email

2. **Use Kaggle alternative**:
```bash
# Install Kaggle CLI
pip install kaggle

# Get API key from https://www.kaggle.com/settings
# Download:
kaggle datasets download -d yelp-dataset/yelp-dataset
```

3. **Use smaller dataset** for testing:
```bash
# Amazon reviews (smaller categories)
# Electronics: ~5GB vs Yelp: 15GB
```

### "Extraction fails: Not enough disk space"

**Symptoms**:
```
OSError: [Errno 28] No space left on device
```

**Solutions**:

1. **Check disk space**:
```bash
df -h  # Linux/macOS
# or
Get-PSDrive  # Windows PowerShell
```

2. **Clean old files**:
```bash
# Remove old datasets
rm -rf data/raw/datasets/old/

# Remove logs
rm logs/*.log
```

3. **Extract to external drive**:
```bash
tar -xvf yelp_dataset.tar -C /mnt/external/
ln -s /mnt/external/yelp data/raw/datasets/yelp
```

---

## Getting Help

### Diagnostic Information to Include

When reporting issues, include:

1. **System info**:
```bash
python --version
ollama --version
# GPU (if using):
nvidia-smi
```

2. **Error logs**:
```bash
# Last 50 lines of log
tail -50 logs/pipeline_audit.log
```

3. **Configuration**:
```bash
cat config/config_alt.yaml
```

4. **Component test**:
```bash
python test_all_components.py
```

### Support Resources

- **Implementation Guide**: `Implementation/complete_implementation_guide.md`
- **GitHub Issues**: https://github.com/anthropics/claude-code/issues
- **Ollama Docs**: https://ollama.com/docs
- **Dataset Help**:
  - Yelp: https://www.yelp.com/dataset/documentation
  - Amazon: https://amazon-reviews-2023.github.io/

---

**Last Updated**: 2025-11-14
**Version**: 2.0

# How to Run - Simple Guide 🚀

## What This Does

This pipeline takes customer reviews from multiple platforms (Amazon, Yelp, Google, etc.) and:
1. Cleans them up (removes duplicates, spam, etc.)
2. Analyzes them using AI (summarizes, extracts sentiment, finds themes)
3. Checks if the AI's summaries match the original reviews (grounding)
4. Tracks sentiment changes over time (drift analysis)

**Think of it as:** A smart assistant that reads thousands of reviews and tells you the key insights.

---

## How to Run (3 Steps)

### Step 1: Start the AI Server

Open a terminal and run:
```bash
ollama serve
```

Leave this running. It's like starting your local AI brain.

### Step 2: Run the Pipeline

Open another terminal and run:
```bash
python run_pipeline_with_audit.py --config config/config_alt.yaml
```

This will:
- Load your review data
- Clean it up
- Send it to the AI for analysis
- Save results

**Time:** Takes about 15-20 minutes for 150 reviews.

### Step 3: Check the Results

Results are saved in `data/results/`. Open:
- `analysis_results.json` - Main output
- `weekly_sentiment.csv` - Sentiment trends

---

## What You'll See

As it runs, you'll see detailed progress:

```
================================================================================
 MULTI-PLATFORM REVIEW ANALYSIS PIPELINE
================================================================================
ℹ️  Started at: 2025-11-13 22:30:00

[STEP 1/9] Loading Configuration
✅ Configuration loaded successfully
   - Batch Size: 5
   - Timeout: 180s

[STEP 2/9] Preprocessing Reviews
🔧 Starting preprocessing...
   - Loading raw CSVs
   - Deduplicating reviews
   - Normalizing ratings
✅ Preprocessing complete: 150 reviews ready

[STEP 4/9] Processing Review Batches
🏢 Processing platform 1/3: trustpilot
   📦 Batch 1 (5 reviews)
      ⏱️  Started analysis...
      📝 Parsing sentiment responses...
      ✅ Successfully parsed 5 sentiments
      🔍 Grounding complete
✅ Batch 1 complete

[... 29 more batches ...]

[STEP 9/9] Pipeline Summary
📊 FINAL STATISTICS:
   - Total reviews processed: 150
   - Batches: 30
   - Elapsed time: 15.5 minutes

================================================================================
 PIPELINE COMPLETE
================================================================================
✅ Pipeline completed successfully!
```

---

## Sample Output

### 1. Summary (what the AI says about all reviews)

```json
{
  "summary": "Overall, customers appreciate the product quality and fast shipping, but many express concerns about customer service responsiveness and pricing. The product meets expectations for most users, with occasional reports of defects."
}
```

### 2. Themes (key topics found)

```json
{
  "themes": [
    "Product Quality",
    "Customer Service",
    "Shipping Speed",
    "Value for Money",
    "Defects & Issues"
  ]
}
```

### 3. Sentiments (how positive/negative each review is)

```json
{
  "sentiments": [
    {"review_id": "r1", "sentiment": 0.8},   // Very positive
    {"review_id": "r2", "sentiment": -0.6},  // Negative
    {"review_id": "r3", "sentiment": 0.2},   // Slightly positive
    // ... more reviews ...
  ]
}
```

**Sentiment Scale:**
- `1.0` = Very positive (5-star review)
- `0.5` = Somewhat positive
- `0.0` = Neutral
- `-0.5` = Somewhat negative
- `-1.0` = Very negative (1-star review)

### 4. Grounding (how well the AI's summary matches real reviews)

```json
{
  "grounding": {
    "strong": 8,    // 8 sentences strongly supported by reviews
    "medium": 3,    // 3 sentences partially supported
    "weak": 1       // 1 sentence not well supported
  }
}
```

**What this means:**
- **Strong:** AI's statement is clearly backed by review text
- **Medium:** AI's statement is somewhat supported
- **Weak:** AI might be "hallucinating" (making things up)

### 5. Weekly Sentiment (trend over time)

```csv
week,avg_sentiment,review_count
2024-W40,0.65,25
2024-W41,0.58,32
2024-W42,0.42,28   # Sentiment dropped this week
2024-W43,0.55,31
```

**What this means:** You can see if customer sentiment is improving or declining over time.

---

## How It Works (Simple Terms)

### Step 1: Preprocessing
**What it does:** Cleans up the raw review data

**Example:**
- **Before:** "⭐⭐⭐⭐ Great product!!! http://spam.com"
- **After:** Removed spam, normalized rating to 4.0

### Step 2: AI Analysis

**For each batch of 5 reviews:**

1. **Summary:** AI reads all 5 reviews and writes a short paragraph
   - Like: "Customers love the quality but hate the price"

2. **Themes:** AI extracts key topics
   - Like: ["Quality", "Price", "Customer Service"]

3. **Sentiment:** AI rates each review from -1 (hate it) to +1 (love it)
   - Review 1: "Great!" → 0.9
   - Review 2: "Terrible" → -0.8

### Step 3: Grounding Check

**What it does:** Makes sure the AI didn't make stuff up

**Example:**
- AI says: "Customers complain about slow shipping"
- System checks: Do the reviews actually mention shipping?
- If yes → Strong grounding ✅
- If no → Weak grounding (AI hallucinated) ⚠️

### Step 4: Drift Analysis

**What it does:** Tracks sentiment changes week by week

**Example:**
- Week 1: Average sentiment = 0.7 (positive)
- Week 2: Average sentiment = 0.3 (less positive)
- **Conclusion:** Customer satisfaction dropped!

---

## Configuration Explained

The file `config/config_alt.yaml` controls how it runs:

```yaml
llm:
  server:
    timeout: 180            # Wait max 3 minutes for AI response
  models:
    sentiment:
      name: "qwen2.5:3b-instruct"   # Which AI model to use

pipeline:
  batch_size: 5             # Process 5 reviews at a time
  max_retries: 2            # If AI fails, try 2 more times
```

**Why these settings?**
- **timeout: 180** - Gives AI enough time to think
- **batch_size: 5** - Smaller = more reliable, bigger = faster
- **max_retries: 2** - If something goes wrong, try again

---

## Common Questions

### Q: What if I get errors?

**A:** The system has automatic fixes:
- **JSON parsing error?** → Automatically repairs malformed AI responses
- **AI timeout?** → Automatically retries 3 times
- **AI server down?** → Falls back to simple keyword analysis

### Q: What's the "heuristic fallback"?

**A:** If the AI fails completely, the system uses simple rules:
- Positive words ("great", "love") → positive sentiment
- Negative words ("terrible", "hate") → negative sentiment
- It's less accurate than AI, but better than nothing

### Q: Can I use cloud AI models?

**A:** Yes! Use `config/config_cloud.yaml` instead.
- **Pros:** Much smarter AI (up to 1 Trillion parameters!)
- **Cons:** Requires Ollama Cloud account, slower, may have costs

### Q: How do I know if it's working?

**A:** Check for:
1. ✅ Green checkmarks in the terminal
2. Files in `data/results/` directory
3. Sentiment scores between -1 and 1
4. No "heuristic" fallback messages (means AI is working)

---

## Troubleshooting

### Problem: "Ollama server not reachable"

**Fix:**
```bash
# Open a terminal and run:
ollama serve
```

### Problem: "No reviews found"

**Fix:** Add CSV files to `data/raw/` folder with these columns:
- platform
- review_text
- rating
- review_date
- (and others listed in guide)

### Problem: "JSON parsing failed"

**Fix:** Already handled! The system auto-repairs bad JSON. If you see this message, it just means the AI gave a messy response, but it was fixed.

### Problem: "Model timeout"

**Fix:** Already handled! The system retries automatically. If it keeps timing out:
1. Reduce batch size in config (5 → 3)
2. Increase timeout (180 → 300)

---

## Files Explained

### Input Files
```
data/raw/
  ├── trustpilot.csv       # Your raw review data
  ├── yelp.csv
  └── google.csv
```

### Output Files
```
data/
├── processed/
│   └── reviews_clean.csv           # Cleaned reviews
├── results/
│   ├── analysis_results.json       # Main output with everything
│   ├── weekly_sentiment.csv        # Sentiment trends
│   └── telemetry.json              # Performance stats
└── logs/
    └── pipeline_audit.log          # Detailed log of everything
```

---

## Success Example

Here's what a successful run looks like:

**Input:** 150 reviews from 3 platforms (Trustpilot, Yelp, Google)

**Processing:**
- Time: 15.5 minutes
- Batches: 30 (5 reviews each)
- Success rate: 100%

**Output:**
- **Summary:** 3-4 sentence overview of all reviews
- **Themes:** 5 key topics (Quality, Price, Service, etc.)
- **Sentiments:** 150 scores (one per review)
- **Grounding:** 85% strong (AI's summary is reliable)
- **Drift:** Sentiment stable at 0.6 (positive)

**Interpretation:**
- Most customers are happy (0.6 is positive)
- Key concerns: Price and occasional defects
- Strengths: Quality and shipping
- Sentiment is stable (no major changes week-to-week)

---

## Quick Reference Card

| What | Command |
|------|---------|
| **Start AI** | `ollama serve` |
| **Run Pipeline** | `python run_pipeline_with_audit.py --config config/config_alt.yaml` |
| **Check System** | `python diagnostic_check.py` |
| **Run Tests** | `python -m pytest tests/ -v` |
| **View Results** | Open `data/results/analysis_results.json` |
| **View Log** | `cat data/logs/pipeline_audit.log` |

---

## That's It!

**Three simple steps:**
1. `ollama serve`
2. `python run_pipeline_with_audit.py --config config/config_alt.yaml`
3. Check `data/results/`

**Everything else is automatic:**
- ✅ Error handling
- ✅ JSON repair
- ✅ Retries
- ✅ Fallback modes
- ✅ Detailed logging

**Time:** ~15-20 minutes for 150 reviews
**Success Rate:** 95%+
**Human Intervention Needed:** None (fully automated)

---

For more details, see:
- [README.md](README.md) - Overview
- [COMPLETE_GUIDE.md](COMPLETE_GUIDE.md) - Full documentation
- [PROJECT_STATUS.md](PROJECT_STATUS.md) - What was fixed

# Multi-Platform Review Analysis Pipeline

**Status:** ✅ ALL ISSUES FIXED - READY TO RUN

---

## Quick Start (3 Commands)

```bash
# 1. Start Ollama
ollama serve

# 2. Run pipeline with audit logging
python run_pipeline_with_audit.py --config config/config_alt.yaml

# 3. Validate output
python validate.py
```

**That's it!** The pipeline is now fully functional.

---

## What Was Fixed ✅

1. **JSON Parsing Errors** - 7-strategy repair system, handles all malformed JSON
2. **Model Timeouts** - Automatic retry with exponential backoff (3 retries)
3. **Local Model Connection** - Graceful fallback to heuristic mode
4. **Cloud Model Support** - Full configuration with auto-fallback
5. **Comprehensive Audit Logging** - Every step logged with visual indicators

---

## Configuration to Use

### ✅ `config/config_alt.yaml` (RECOMMENDED)
**Use this for your end-to-end run.**

- Local model: `qwen2.5:3b-instruct`
- No cloud dependencies
- Batch size: 5 (reliable)
- Timeout: 180s
- Works on CPU
- Falls back to heuristic if needed

### Other Options:
- `config/config.yaml` - Balanced settings (batch: 10)
- `config/config_cloud.yaml` - Cloud models with auto-fallback

---

## Date Range Question

The date range in config:
```yaml
data:
  collection_window:
    start: "2024-09-10"
    end: "2024-11-01"
```

**Does NOT cause errors!**
- Just filters which reviews to include
- Reviews outside range are filtered out
- No reviews in range? You get a warning, not an error

**To include all dates:**
Set to your data range or remove the filter entirely.

---

## Output Files

After running:
```
data/
├── processed/
│   ├── reviews_clean.csv          # Cleaned reviews
│   └── reviews.sqlite              # SQLite database
├── results/
│   ├── analysis_results.json       # Main analysis output
│   ├── weekly_sentiment.csv        # Sentiment trends
│   ├── telemetry.json              # Performance metrics
│   └── descriptive.json            # Statistics
└── logs/
    ├── pipeline_audit.log          # Detailed audit log
    └── diagnostic_results.json      # System check results
```

---

## Troubleshooting

### "Ollama server not reachable"
```bash
ollama serve
```

### "Required model not found"
```bash
ollama pull qwen2.5:3b-instruct
```

### "JSON parsing still failing"
✅ **Already fixed!** New robust parser handles all cases.

### "Model timeout"
✅ **Already fixed!** Automatic retry with backoff.

---

## Testing

```bash
# Run diagnostic check
python diagnostic_check.py

# Run all tests
python -m pytest tests/ -v

# Run specific test
python -m pytest tests/test_ollama_analyzer.py -v
```

---

## What You'll See

With `run_pipeline_with_audit.py`:

```
================================================================================
 MULTI-PLATFORM REVIEW ANALYSIS PIPELINE
================================================================================
ℹ️  Started at: 2025-11-13 22:30:00
ℹ️  Config: config/config_alt.yaml

[STEP 1/9] Loading Configuration
✅ Configuration loaded successfully

[STEP 2/9] Preprocessing Reviews
✅ Preprocessing complete: 150 reviews ready

[STEP 3/9] Initializing Analysis Components
✅ LLM analyzer initialized
✅ Semantic grounder initialized

[STEP 4/9] Processing Review Batches
🏢 Processing platform 1/3: trustpilot
   📦 Batch 1 (5 reviews)
      📝 Attempting to parse sentiment JSON response...
      ✅ Successfully parsed 5 sentiment(s)
      ✅ Batch complete

[... processing continues ...]

[STEP 9/9] Pipeline Summary
📊 FINAL STATISTICS:
   - Total reviews: 150
   - Total batches: 30
   - Elapsed time: 15.5 minutes

================================================================================
 PIPELINE COMPLETE
================================================================================
✅ Pipeline completed successfully!
```

---

## Documentation

- [COMPLETE_GUIDE.md](COMPLETE_GUIDE.md) - Full setup and troubleshooting
- [PROJECT_STATUS.md](PROJECT_STATUS.md) - What's been fixed and validated
- [API_REFERENCE.md](API_REFERENCE.md) - Technical documentation

---

## Performance

**For 150 reviews (batch size 5):**
- Local model (CPU): ~15-20 minutes
- Local model (GPU): ~5-10 minutes
- Cloud models: ~30-60 minutes (depends on network/rate limits)

---

## Need Help?

```bash
# 1. Check logs
cat data/logs/pipeline_audit.log

# 2. Run diagnostic
python diagnostic_check.py

# 3. Test components
python test_ollama.py
```

---

## Success Indicators ✅

Pipeline is working when:
1. Diagnostic passes with no critical issues
2. All tests pass
3. Pipeline completes without errors
4. Output files generated
5. Sentiment scores in range [-1, 1]
6. Models show actual names (not always "heuristic")

---

**Ready to run!** All issues fixed, tests passing, comprehensive logging added.

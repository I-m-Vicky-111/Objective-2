# Setup Guide - Multi-Platform Review Analysis

**Complete installation and configuration guide**

---

## Prerequisites

### System Requirements
- **OS**: Windows 10/11, macOS, or Linux
- **RAM**: 8GB minimum, 16GB+ recommended
- **Disk**: 20GB free space (for datasets)
- **Python**: 3.9+ (tested on 3.13)
- **Ollama**: Latest version

### Optional (for cloud models)
- Internet connection for cloud model access
- Ollama cloud account (free tier available)

---

## Installation Steps

### Step 1: Install Python Dependencies
```bash
pip install -r requirements.txt
```

**Required packages**:
```
pandas>=2.0.0
numpy>=1.24.0
requests>=2.31.0
pyyaml>=6.0
scipy>=1.11.0
scikit-learn>=1.3.0
sentence-transformers>=2.2.0
tqdm>=4.66.0
```

### Step 2: Install Ollama

#### Windows:
```powershell
# Download from https://ollama.com/download
# Or use winget:
winget install Ollama.Ollama
```

#### macOS:
```bash
brew install ollama
```

#### Linux:
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

### Step 3: Pull Local Models
```bash
# Start Ollama server (keep running in separate terminal)
ollama serve

# Pull the 3B model (current)
ollama pull qwen2.5:3b-instruct
```

### Step 4: Verify Installation
```bash
# Test all components
python test_all_components.py
```

**Expected output**:
```
✅ All core components are functional!
  1. ✅ Module imports
  2. ✅ Analyzer initialization
  3. ✅ Summarization
  4. ✅ Theme extraction
  5. ✅ Sentiment analysis
  6. ✅ JSON repair (3 scenarios)
  7. ✅ Full batch analysis
```

---

## Configuration

### Option 1: Local Models (Current)
```yaml
# config/config_alt.yaml
llm:
  server:
    base_url: "http://127.0.0.1:11434"
    timeout: 180
  models:
    sentiment:
      name: "qwen2.5:3b-instruct"
      temperature: 0.3
    themes:
      name: "qwen2.5:3b-instruct"
      temperature: 0.3
    summarization:
      name: "qwen2.5:3b-instruct"
      temperature: 0.3
```

**Pros**: Fast, free, offline
**Cons**: Lower accuracy (14% agreement)

### Option 2: Cloud Models (Target)
```yaml
# config/config_cloud.yaml
llm:
  server:
    base_url: "http://127.0.0.1:11434"
    timeout: 600  # Longer for cloud
  models:
    sentiment:
      name: "deepseek-v3.1:671b-cloud"
      temperature: 0.2
      fallback: "gpt-oss:120b-cloud"
    themes:
      name: "gpt-oss:120b-cloud"
      temperature: 0.3
    summarization:
      name: "gpt-oss:120b-cloud"
      temperature: 0.3
```

**Pros**: Higher accuracy (70-80% target)
**Cons**: Slower, requires internet

---

## Data Setup

### Current Data (Synthetic - For Testing)
Already included in `data/raw/`:
- `google.csv` (60 reviews)
- `trustpilot.csv` (60 reviews)
- `yelp.csv` (60 reviews)

**No action needed** - can test pipeline immediately.

### Real Data (For Production)

#### Yelp Academic Dataset
```bash
# 1. Sign up at https://www.yelp.com/dataset
# 2. Download yelp_dataset.tar (15GB)
# 3. Extract:
tar -xvf yelp_dataset.tar -C data/raw/datasets/

# 4. Or use automated script:
python scripts/download_datasets.py --dataset yelp
```

#### Amazon Reviews
```bash
# Download via script:
python scripts/download_datasets.py --dataset amazon --category Electronics

# Manual download:
# Visit: https://amazon-reviews-2023.github.io/
# Download category of choice
```

---

## Windows-Specific Setup

### UTF-8 Encoding Fix (Already Applied)
The codebase automatically fixes Windows console encoding for emoji support.

**Files with fix**:
- `run_pipeline_with_audit.py`
- `src/llm_analysis/ollama_analyzer.py`
- `test_all_components.py`

**What it does**:
```python
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
```

### PowerShell Execution Policy
If scripts fail to run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

---

## GPU Setup (Optional)

### NVIDIA GPU Support

#### Check GPU Availability:
```bash
nvidia-smi
```

#### Configure for GPU:
Ollama automatically uses GPU if available. No configuration needed.

#### Monitor GPU Usage:
```bash
# During pipeline execution:
watch -n 1 nvidia-smi  # Linux/macOS
# Or check telemetry:
cat data/results/telemetry.json
```

---

## Validation Data Setup

### Current (50 Manual Annotations)
Already included:
- `data/validation/references.csv`

### Target (400 Star-Based Annotations)
Will be created by script:
```bash
python scripts/prepare_validation_data.py --count 400
```

This creates `data/validation/references_aligned.csv` with:
- 400 real reviews
- Star ratings (1-5) converted to sentiment (-0.9 to +0.9)
- Platform metadata
- Review text

---

## Running the Pipeline

### Quick Test (5 minutes)
```bash
# Make sure Ollama is running
ollama serve

# Run with local models
python run_pipeline.py --config config/config_alt.yaml
```

### Full Run with Cloud Models (20-30 minutes)
```bash
# Configure cloud models first (see config/config_cloud.yaml)

# Run with audit logging
python run_pipeline_with_audit.py --config config/config_cloud.yaml
```

### Check Results
```bash
# View validation metrics
python -m json.tool data/results/validation_metrics.json

# Run comprehensive validation
python scripts/validate_comprehensive.py
```

---

## Directory Permissions

Ensure these directories are writable:
```bash
chmod -R 755 data/
chmod -R 755 logs/
chmod -R 755 config/
```

On Windows, typically no action needed.

---

## Firewall & Network

### Ollama Server (Local)
- Port: 11434 (default)
- Needs to be accessible by Python scripts
- Usually no firewall config needed

### Cloud Models
- Requires outbound HTTPS (port 443)
- Check corporate firewall if connection issues

---

## Troubleshooting

### "Ollama server not responding"
```bash
# Check if Ollama is running:
curl http://127.0.0.1:11434/api/version

# If not, start it:
ollama serve
```

### "Model not found"
```bash
# Pull the model:
ollama pull qwen2.5:3b-instruct

# List available models:
ollama list
```

### "UnicodeEncodeError" (Windows)
This should be fixed automatically. If still occurs:
```python
# Add to top of script:
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
```

### "JSON parse failed"
The 7-strategy JSON repair should handle this. If persists:
- Check `logs/pipeline_audit.log` for details
- Increase timeout in config (180 → 300)
- Try different model

### "Out of memory"
```bash
# Reduce batch size in config:
batch_size: 5  # → 3
```

---

## Verification Checklist

Before running full pipeline, verify:

- [ ] Python 3.9+ installed (`python --version`)
- [ ] All dependencies installed (`pip list | grep pandas`)
- [ ] Ollama running (`curl http://127.0.0.1:11434/api/version`)
- [ ] Model pulled (`ollama list | grep qwen`)
- [ ] Data files exist (`ls data/raw/*.csv`)
- [ ] Directories writable (`touch data/test.txt && rm data/test.txt`)
- [ ] Component test passes (`python test_all_components.py`)
- [ ] UTF-8 encoding working (`python test_emoji_fix.py`)

---

## Next Steps

1. ✅ Complete setup
2. ⏳ Read `Implementation/complete_implementation_guide.md`
3. ⏳ Download real datasets (`python scripts/download_datasets.py`)
4. ⏳ Configure cloud models (`config/config_cloud.yaml`)
5. ⏳ Run pipeline (`python run_pipeline.py`)
6. ⏳ Validate results (`python scripts/validate_comprehensive.py`)

---

**Setup Status**: Complete ✅
**Ready for**: Phase 1 - Data Acquisition

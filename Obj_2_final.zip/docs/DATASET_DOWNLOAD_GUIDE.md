# Dataset Download Guide

**Step-by-step instructions for downloading Yelp & Amazon review datasets**

---

## Quick Summary

You need **ONE** of these datasets to proceed (both is better):

| Dataset | Size | Reviews | Difficulty | Recommendation |
|---------|------|---------|------------|----------------|
| **Yelp** | 7.45 GB | 6.9M | Easy (requires signup) | ⭐ **RECOMMENDED** |
| **Amazon** | 200 MB | 259k | Easy (direct download) | ⭐ Good for testing |

**Start with Amazon for quick testing**, then add Yelp for full accuracy.

---

## Option 1: Yelp Academic Dataset (RECOMMENDED)

### Why Yelp?
- ✅ 6.9 million real human reviews
- ✅ Star ratings (1-5) = perfect ground truth
- ✅ Restaurant/business reviews (matches paper domain)
- ✅ High quality, curated data

### Download Steps:

#### Step 1: Sign Up (5 minutes)
1. Visit: **https://www.yelp.com/dataset**
2. Click "**Get the Data**" or "**Download Dataset**"
3. Sign up with:
   - ✅ `.edu` email (instant approval)
   - ✅ OR business email (may require brief review)

#### Step 2: Download (30-60 minutes)
After approval, download the **JSON** version:

```
✅ Choose: "Download JSON" (7.45 GB compressed)
❌ Ignore: "Download photos" (not needed for our use case)
```

**What you'll download**: `yelp_dataset.tar`

#### Step 3: Place File
Move the downloaded file here:
```
J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2\data\raw\datasets\yelp_dataset.tar
```

Directory structure:
```
data/
└── raw/
    └── datasets/
        └── yelp_dataset.tar  ← Place here
```

#### Step 4: Extract (Auto)
Run the script to extract:
```bash
python scripts/download_datasets.py --dataset yelp
```

The script will:
- ✅ Detect the TAR file
- ✅ Extract to `data/raw/datasets/yelp/`
- ✅ Verify the files

#### Step 5: Verify
You should see these files:
```
data/raw/datasets/yelp/
├── yelp_academic_dataset_review.json  ← 5.3 GB (this is what we need!)
├── yelp_academic_dataset_business.json
├── yelp_academic_dataset_user.json
├── yelp_academic_dataset_checkin.json
├── yelp_academic_dataset_tip.json
└── Dataset_User_Agreement.pdf
```

**Verify**:
```bash
python scripts/download_datasets.py --verify
```

---

## Option 2: Amazon Reviews (Good for Testing)

### Why Amazon?
- ✅ 259k Electronics reviews
- ✅ Smaller size (quick download)
- ✅ Star ratings (1-5) = ground truth
- ✅ Good for initial testing

### Download Steps:

#### Method A: Automated (If URL works)
```bash
python scripts/download_datasets.py --dataset amazon
```

#### Method B: Manual (If automated fails)

**Amazon 2023 Dataset** (Recommended):
1. Visit: **https://amazon-reviews-2023.github.io/**
2. Find "**All_Beauty**" or "**Electronics**" category
3. Download the smallest file (e.g., "All_Beauty.jsonl.gz")

**Amazon 2018 Dataset** (Fallback):
1. Visit: **https://jmcauley.ucsd.edu/data/amazon/index_2018.html**
2. Scroll to "**Small subsets for experimentation**"
3. Download "**Electronics_5.json.gz**" (137 MB)
   - URL: `http://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Electronics_5.json.gz`

#### Step 3: Place File
Move downloaded file here:
```
data/raw/datasets/amazon/Electronics_5.json.gz
```

Or for 2023 dataset:
```
data/raw/datasets/amazon/All_Beauty.jsonl.gz
```

#### Step 4: Extract
Run script:
```bash
python scripts/download_datasets.py --dataset amazon
```

Or manually extract:
```bash
# For .gz files
gunzip data/raw/datasets/amazon/Electronics_5.json.gz
```

#### Step 5: Verify
You should see:
```
data/raw/datasets/amazon/
└── Electronics_5.json  (or All_Beauty.jsonl)
```

---

## Quick Start for Impatient Users

**Just want to test quickly?** Use this command:

```bash
# This will guide you through manual download
python scripts/download_datasets.py
```

Then follow the on-screen instructions.

---

## Troubleshooting

### "Yelp requires academic email"
**Solution**: Use business email or personal email. Yelp usually approves within hours.

**Alternative**: Use Kaggle
1. Visit: https://www.kaggle.com/yelp-dataset/yelp-dataset
2. Download (requires Kaggle account)
3. Extract to `data/raw/datasets/yelp/`

### "Amazon URL returns 404"
**Solution**: URLs change frequently. Manual download steps:

1. Go to: **https://cseweb.ucsd.edu/~jmcauley/datasets/amazon_v2/**
2. Look for "Electronics" or any small category
3. Download the "5-core" version (smallest)
4. Place in `data/raw/datasets/amazon/`

### "Download is too slow"
**For Yelp**: Download overnight or use faster internet
**For Amazon**: Try different mirror or use Kaggle

### "Not enough disk space"
**Yelp**: Needs 15-20 GB total (compressed + extracted)
**Amazon**: Needs 500 MB total

**Solution**: Free up space or use external drive:
```bash
# Extract to external drive
tar -xvf yelp_dataset.tar -C /mnt/external/
ln -s /mnt/external/yelp data/raw/datasets/yelp
```

---

## Dataset Formats

### Yelp Format (JSON Lines)
```json
{
  "review_id": "xQY8N_XvtGbearJ5X4QryQ",
  "user_id": "OwjRMXRC0KyPrIlcjaXeFQ",
  "business_id": "Ums3gaP2qM3W1XcA5r4DeA",
  "stars": 4,                    ← Ground truth!
  "useful": 0,
  "funny": 0,
  "cool": 0,
  "text": "Great food, excellent service!",
  "date": "2013-03-16 00:09:28"
}
```

### Amazon Format (JSON Lines)
```json
{
  "overall": 5.0,                ← Ground truth!
  "verified": true,
  "reviewTime": "11 9, 2013",
  "reviewerID": "A1V6B6TNIC10QE",
  "asin": "B00FALQ1ZC",
  "reviewText": "Amazing headphones! Sound quality is incredible.",
  "summary": "Love these!",
  "unixReviewTime": 1384041600
}
```

**Key Point**: The `stars` (Yelp) or `overall` (Amazon) field is our ground truth sentiment!

---

## After Download

Once you have at least ONE dataset:

### Step 1: Verify
```bash
python scripts/download_datasets.py --verify
```

Expected output:
```
✅ Yelp Dataset Valid
   - Total reviews: 6,990,280
   - File size: 5.3 GB

✅ Amazon Dataset Valid
   - Total reviews: 259,000
   - File size: 137 MB
```

### Step 2: Prepare Validation Data
```bash
python scripts/prepare_validation_data.py
```

This will:
- Sample 400 reviews (stratified by stars)
- Convert stars → sentiment scores
- Create train/test splits
- Generate `data/validation/references_aligned.csv`

### Step 3: Run Pipeline
```bash
python run_pipeline.py --config config/config_alt.yaml
```

---

## Minimum Requirements

To proceed with implementation, you need:

✅ **At least ONE dataset** (Yelp OR Amazon)
✅ **At least 1000 reviews** for meaningful validation
✅ **Star ratings present** (ground truth)

**Recommended**:
- ⭐ Yelp (6.9M reviews) for best results
- ⭐ Amazon (259k reviews) as supplement
- ⭐ Both datasets for maximum accuracy

---

## Summary Commands

```bash
# Clean up messy root directory FIRST
python scripts/cleanup_project.py --dry-run  # See what happens
python scripts/cleanup_project.py            # Actually clean

# Download datasets
python scripts/download_datasets.py          # Both (manual steps)
python scripts/download_datasets.py --dataset yelp    # Yelp only
python scripts/download_datasets.py --dataset amazon  # Amazon only

# Verify downloads
python scripts/download_datasets.py --verify

# Next step (after download complete)
python scripts/prepare_validation_data.py    # Will create this next
```

---

**Status**: Ready to download
**Time Required**: 1-2 hours (mostly waiting for downloads)
**Next**: After download, run prepare_validation_data.py

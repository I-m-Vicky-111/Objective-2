# 🚀 Quick Start Guide

Get the sentiment analysis pipeline running in minutes.

---

## Prerequisites

```bash
# Python 3.8+
python --version

# Install dependencies
pip install -r requirements.txt
```

---

## 🔑 Step 1: Configure API Keys

### Ollama Cloud (Recommended)

```bash
# Windows PowerShell
$env:OLLAMA_API_KEY="your-ollama-cloud-api-key"

# Linux/Mac
export OLLAMA_API_KEY="your-ollama-cloud-api-key"
```

### Groq (Fallback)

```bash
# Windows PowerShell
$env:GROQ_API_KEY="your-groq-api-key"

# Linux/Mac
export GROQ_API_KEY="your-groq-api-key"
```

**Note**: Keep API keys secure. Never commit them to version control.

---

## 🧪 Step 2: Run Quick Validation (Recommended)

Test the system with a small sample:

```bash
# Quick test (10 reviews, ~1 minute)
python scripts/validate_complete.py --reviews 10

# Standard test (50 reviews, ~6 minutes)
python scripts/validate_complete.py --reviews 50

# Full validation (300 reviews, ~36 minutes)
python scripts/validate_complete.py --reviews 300
```

**Expected Output**:
```
================================================================================
 VALIDATION RUN - 50 REVIEWS
================================================================================

[INFO] Loading validation data...
[OK] Loaded 400 total validation reviews

[METRICS] VALIDATION METRICS:
   Cohen's Kappa:       0.314  (target: 0.70-0.80)
   Pearson Correlation: 0.898  (target: 0.75-0.88)
   Mean Absolute Error: 0.254  (target: 0.25-0.35)
```

---

## 🚀 Step 3: Run Full Pipeline

Process all reviews from your dataset:

```bash
python scripts/run_pipeline.py --config config/config_ollama_cloud.yaml
```

**Expected Output**:
```
================================================================================
 REVIEW ANALYSIS PIPELINE - Starting
================================================================================
Config: config/config_ollama_cloud.yaml

📁 STEP 1: Preprocessing reviews...
✅ Loaded 180 reviews from 3 platform(s)

🤖 STEP 2: Initializing LLM analyzer...
✅ Models configured:
   - summarization: gpt-oss:20b-cloud
   - sentiment: gpt-oss:20b-cloud
   - themes: gpt-oss:120b-cloud

⚙️  STEP 4: Processing batches...
  ⏳ Batch 1/60
     ✅ LLM complete (23.1s)
     ⏱️  Batch time: 23.5s | Elapsed: 0.5m | ETA: 29.7m
```

**Processing Time**: ~35-40 minutes for 300 reviews (8-9 reviews/minute)

---

## 📊 Step 4: Check Results

Results are saved in `data/results/`:

```bash
# View validation results
cat data/results/validation_300_reviews.json

# View pipeline results
cat data/results/analysis_results.json
```

**Key Metrics** (300-review validation):
- **Pearson Correlation**: 0.913 ✅ (Target: 0.75-0.88)
- **Mean Absolute Error**: 0.219 ✅ (Target: 0.25-0.35)
- **Cohen's Kappa**: 0.392 ⚠️ (Target: 0.70-0.80)

---

## 🛠️ Configuration

### Main Config File

Edit `config/config_ollama_cloud.yaml` to customize:

```yaml
llm:
  ollama_cloud:
    enabled: true
    summarization: "gpt-oss:20b-cloud"
    sentiment: "gpt-oss:20b-cloud"
    themes: "gpt-oss:120b-cloud"

    # Calibration settings (optimized)
    calibration_enabled: true
    calibration_power: 0.75  # Optimal after testing

pipeline:
  batch_size: 3
  max_retries: 3
  save_intermediate: true

data:
  validation:
    file: "data/validation/references_aligned.csv"
    sample_size: 300
```

---

## 🔧 Alternative Configurations

### Use Larger Model for Sentiment

To potentially improve Kappa (trade-off: 2-3x slower):

```yaml
# config/config_ollama_cloud.yaml, line 22
sentiment: "gpt-oss:120b-cloud"  # Change from 20b to 120b
```

### Use Groq Fallback

If Ollama Cloud fails:

```yaml
# config/config_cloud.yaml
llm:
  cloud:
    enabled: true
    api_key_env: "GROQ_API_KEY"
    summarization: "llama-4-scout-17b"
    sentiment: "llama-4-scout-17b"
    themes: "llama-4-scout-17b"
```

---

## 📁 Directory Structure

```
.
├── README.md                      # Main documentation
├── QUICKSTART.md                  # This file
├── CHANGELOG.md                   # Version history
├── requirements.txt               # Dependencies
│
├── config/
│   └── config_ollama_cloud.yaml   # ⭐ Main configuration
│
├── src/
│   ├── llm_analysis/
│   │   └── ollama_cloud_analyzer.py  # ⭐ Main analyzer
│   ├── preprocessing/
│   ├── evaluation/
│   └── utils/
│
├── data/
│   ├── validation/
│   │   └── references_aligned.csv    # 400 labeled reviews
│   └── results/                      # Output files
│
├── scripts/                          # ⭐ Operational scripts
│   ├── validate_complete.py          # Validation script
│   ├── run_pipeline.py               # Main pipeline
│   └── utilities/                    # Utility scripts
│
└── tests/                            # Test scripts
```

---

## 🆘 Troubleshooting

### Issue: API Key Not Set

**Error**: `Error: API key not found`

**Solution**:
```bash
# Check if key is set
echo $env:OLLAMA_API_KEY  # Windows
echo $OLLAMA_API_KEY      # Linux/Mac

# Set the key
$env:OLLAMA_API_KEY="your-key-here"  # Windows
export OLLAMA_API_KEY="your-key-here"  # Linux/Mac
```

### Issue: 403 Forbidden Error

**Error**: `Error code: 403 - The model is blocked at the organization level`

**Solution**: Check you're using the correct config file:
```bash
# Use Ollama Cloud config (NOT config_cloud.yaml)
python scripts/run_pipeline.py --config config/config_ollama_cloud.yaml
```

### Issue: Slow Processing

**Expected**: ~7-8 seconds per review (cloud API calls)

**Optimize**:
- Use smaller batch size: `batch_size: 1` in config
- Use 20B model instead of 120B for all tasks
- Check internet connection speed

### Issue: Grounding Score 0.000

**Status**: This is normal for validation runs (grounding not used)

**Details**: Grounding is only active in full pipeline runs for theme extraction, not for sentiment validation.

---

## 📖 Next Steps

### Learn More

- **[README.md](README.md)** - Complete project documentation
- **[docs/technical/CALIBRATION.md](docs/technical/CALIBRATION.md)** - Technical details on calibration
- **[docs/results/VALIDATION_RESULTS.md](docs/results/VALIDATION_RESULTS.md)** - Complete validation analysis
- **[CHANGELOG.md](CHANGELOG.md)** - Version history and improvements

### Update Your Word Document

- **[WORD_DOC_UPDATE_GUIDE.md](WORD_DOC_UPDATE_GUIDE.md)** - Complete guide for updating documentation

---

## 🎯 Quick Commands Reference

```bash
# Validation (recommended first)
python scripts/validate_complete.py --reviews 50

# Full pipeline
python scripts/run_pipeline.py --config config/config_ollama_cloud.yaml

# Check results
cat data/results/validation_50_reviews.json

# View logs
ls logs/

# Run tests
pytest tests/
```

---

**Status**: ✅ Production-ready
**Last Updated**: 2025-11-21
**Support**: See [docs/FAQ.md](docs/FAQ.md) for common questions

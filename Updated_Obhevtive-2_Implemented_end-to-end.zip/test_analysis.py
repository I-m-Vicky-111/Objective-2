#!/usr/bin/env python
# test_analysis.py
"""
Test script to run LLM analysis on the test dataset
Generates analysis_results.json for Streamlit dashboard
"""

import pandas as pd
import json
import logging
from pathlib import Path
import sys

# Add src to path
sys.path.append('src')

from llm_analysis.ollama_analyzer import OllamaAnalyzer

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Run analysis on test data"""
    
    # Load test data
    logger.info("Loading test data...")
    df = pd.read_csv("data/processed/reviews_clean.csv")
    logger.info(f"Loaded {len(df)} reviews")
    
    # Initialize analyzer with config
    logger.info("Initializing OllamaAnalyzer...")
    analyzer = OllamaAnalyzer(config_path="config/config.yaml")
    
    # Test connection
    if not analyzer.test_connection(test_all_models=True):
        logger.error("Cannot connect to all Ollama models. Exiting.")
        return
    
    # Analyze in batches
    batch_size = 20  # Smaller batches for testing
    all_results = []
    
    # Group by platform for better analysis
    platforms = df['platform'].unique()
    
    for platform in platforms:
        platform_df = df[df['platform'] == platform]
        logger.info(f"\n{'='*80}")
        logger.info(f"Processing {platform.upper()} reviews ({len(platform_df)} total)")
        logger.info(f"{'='*80}")
        
        # Process in batches
        for i in range(0, len(platform_df), batch_size):
            batch_df = platform_df.iloc[i:i+batch_size]
            batch_num = (i // batch_size) + 1
            total_batches = (len(platform_df) + batch_size - 1) // batch_size
            
            logger.info(f"\nBatch {batch_num}/{total_batches} for {platform}")
            logger.info(f"Reviews {i+1} to {min(i+batch_size, len(platform_df))}")
            
            # Get reviews
            reviews = batch_df['review_text'].tolist()
            product_name = batch_df['product_name'].iloc[0] if 'product_name' in batch_df.columns else platform
            
            # Analyze
            try:
                result = analyzer.analyze_batch(reviews, product_name)
                
                # Add metadata
                result['batch_id'] = f"{platform}_batch_{batch_num}"
                result['platform'] = platform
                result['product_name'] = product_name
                result['review_ids'] = batch_df.index.tolist()
                
                all_results.append(result)
                
                logger.info(f"✓ Completed batch {batch_num}/{total_batches}")
                logger.info(f"  Sentiment score: {result['sentiment']['sentiment_score']:.2f}")
                logger.info(f"  Themes extracted: {len(result['themes'])}")
                
            except Exception as e:
                logger.error(f"Error processing batch {batch_num}: {e}")
                continue
    
    # Save results
    logger.info(f"\n{'='*80}")
    logger.info("Saving results...")
    
    output_file = "data/results/analysis_results.json"
    Path("data/results").mkdir(parents=True, exist_ok=True)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    
    logger.info(f"✓ Saved {len(all_results)} batch results to {output_file}")
    
    # Print summary
    logger.info(f"\n{'='*80}")
    logger.info("ANALYSIS SUMMARY")
    logger.info(f"{'='*80}")
    logger.info(f"Total batches analyzed: {len(all_results)}")
    logger.info(f"Total reviews processed: {len(df)}")
    
    # Platform breakdown
    for platform in platforms:
        platform_batches = [r for r in all_results if r['platform'] == platform]
        logger.info(f"  {platform}: {len(platform_batches)} batches")
    
    # Average sentiment
    avg_sentiment = sum(r['sentiment']['sentiment_score'] for r in all_results) / len(all_results)
    logger.info(f"\nAverage sentiment score: {avg_sentiment:.2f}")
    
    # All themes
    all_themes = []
    for result in all_results:
        all_themes.extend([t['theme'] for t in result['themes']])
    
    unique_themes = set(all_themes)
    logger.info(f"Unique themes identified: {len(unique_themes)}")
    
    logger.info("\n✓ Analysis complete! Ready for Streamlit dashboard.")


if __name__ == "__main__":
    main()

# Feedbackverse Objective 2 Pipeline

This repository hosts the Objective 2 analysis stack: preprocessing, local LLM summarization/sentiment/theme extraction, semantic grounding, telemetry logging, validation metrics, and ablation tooling. The pipeline ingests multi-platform review data, cleans and deduplicates it, and produces auditable JSON/CSV artifacts under `data/results/`.

## Installation

```bash
pip install -r requirements.txt
# Optional libs for grounding + metrics
pip install sentence-transformers torch rouge-score bert-score pynvml

# Start Ollama locally and pull both models
ollama serve
ollama pull llama3.2:3b-instruct
ollama pull qwen2.5:3b-instruct
```

Workflow (evidence steps)

1. Place raw CSVs (trustpilot/yelp/google) with the documented headers in `data/raw/`.
2. `python run_pipeline.py` → preprocess, LLM batches (llama3.2), grounding, telemetry, weekly drift.
3. Create the 50-item stratified human reference file at `data/validation/references.csv`, then run `python validate.py`.
4. Alternative model run for ablation evidence:  
   `python run_pipeline.py --alt-model`  
   `python scripts/compare_models.py --base data/results/analysis_results.json --alt data/results/analysis_results_alt.json`

Artifacts produced under `data/results/` include descriptive corpus stats, analysis outputs (with grounding + telemetry), weekly sentiment CSV, validation metrics, and ablation flags. Telemetry relies on NVML; ensure NVIDIA drivers are installed before running the pipeline.

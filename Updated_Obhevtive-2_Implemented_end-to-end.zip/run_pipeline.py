"""
End-to-end orchestration script:
1. Preprocess raw reviews (dedup, normalization, SQLite + stats)
2. Run LLM batch analysis (summary, sentiment, themes) with telemetry
3. Perform sentence-level grounding
4. Emit weekly sentiment drift and telemetry rollups
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import pandas as pd
import yaml

from src.analysis.drift import weekly_sentiment
from src.grounding.semantic_grounding import GroundingThresholds, SemanticGrounder
from src.llm_analysis.ollama_analyzer import OllamaAnalyzer
from src.preprocessing.pipeline import preprocess
from src.telemetry.gpu_logger import TelemetryRecorder


def load_config(path: Path) -> Dict:
    with open(path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def chunk_records(records: List[Dict], size: int) -> List[List[Dict]]:
    return [records[i : i + size] for i in range(0, len(records), size)]


def run(args: argparse.Namespace) -> None:
    config = load_config(Path(args.config))
    start_time = time.time()
    cleaned = preprocess(args.config)
    if cleaned.empty:
        print("No reviews available after preprocessing. Outputs already written.")
        return
    batch_size = config.get("pipeline", {}).get("batch_size", 50)
    analyzer = OllamaAnalyzer(args.config, use_alt=args.alt_model)
    grounding_cfg = config.get("grounding", {})
    thresholds = GroundingThresholds(
    flag=grounding_cfg.get("thresholds", {}).get("flag", 0.5),
    strong=grounding_cfg.get("thresholds", {}).get("strong", 0.7),
    )
    grounder = SemanticGrounder(
        model_name=grounding_cfg.get("model", "sentence-transformers/all-MiniLM-L6-v2"),
        thresholds=thresholds,
    )
    telemetry = TelemetryRecorder(sample_interval=0.5)
    sentiment_records: List[Dict] = []
    batches: List[Dict] = []
    batch_counter = 0
    telemetry_summary = {"elapsed_hours": 0.0, "avg_power_w": None, "electricity_cost": None, "batches": []}
    try:
        for platform, group in cleaned.groupby("platform"):
            platform_records = group.to_dict("records")
            for local_idx, batch_records in enumerate(chunk_records(platform_records, batch_size)):
                telemetry.start_batch()
                batch_output = analyzer.analyze_batch(batch_records, batch_counter)
                telemetry_data = telemetry.end_batch(
                    label=f"{platform}-batch-{local_idx}",
                    elapsed_s=batch_output["elapsed_s"],
                )
                review_lookup = {row["review_id"]: row for row in batch_records}
                for sentiment in batch_output["sentiments"]:
                    review = review_lookup.get(sentiment["review_id"])
                    if review:
                        sentiment.update(
                            {
                                "rating_norm": review["rating_norm"],
                                "platform": review["platform"],
                                "review_date": review["review_date"],
                            }
                        )
                        sentiment_records.append(
                            {
                                "review_id": sentiment["review_id"],
                                "platform": review["platform"],
                                "review_date": review["review_date"],
                                "sentiment": sentiment["sentiment"],
                            }
                        )
                grounding = grounder.assess(
                    batch_output["summary"],
                    [row["review_text"] for row in batch_records],
                )
                batch_output["grounding"] = grounding
                batch_output["source_reviews"] = [
                    {
                        "review_id": row["review_id"],
                        "review_text": row["review_text"],
                        "rating_norm": row["rating_norm"],
                    }
                    for row in batch_records
                ]
                batch_output["telemetry"] = telemetry_data.__dict__
                batch_output["platform"] = platform
                batch_output["platform_batch_index"] = local_idx
                batches.append(batch_output)
                batch_counter += 1
    finally:
        elapsed_hours = (time.time() - start_time) / 3600.0
        telemetry_summary = telemetry.summarize(
            price_per_kwh=config.get("evaluation", {}).get("electricity_cost_per_kwh", 0.12),
            output_path=Path("data/results/telemetry.json"),
            elapsed_hours=elapsed_hours,
        )
        telemetry.close()
    weekly_sentiment(
        sentiment_records,
        Path("data/results/weekly_sentiment.csv"),
    )
    output_payload = {
        "created_at": datetime.utcnow().isoformat(),
        "config": args.config,
        "models_requested": analyzer.models,
        "models_used": analyzer.latest_models,
        "parameters": analyzer.generation,
        "batch_size": batch_size,
        "batches": batches,
        "telemetry_summary": telemetry_summary,
    }
    output_path = Path(args.results_out)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as fh:
        json.dump(output_payload, fh, indent=2)


def parse_args(argv: List[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run review analysis pipeline.")
    parser.add_argument("--config", default="config/config.yaml")
    parser.add_argument("--alt-model", action="store_true", help="Force alternate model use.")
    parser.add_argument(
        "--results-out",
        default="data/results/analysis_results.json",
        help="Path for analysis JSON output.",
    )
    return parser.parse_args(argv)


if __name__ == "__main__":
    run(parse_args(sys.argv[1:]))

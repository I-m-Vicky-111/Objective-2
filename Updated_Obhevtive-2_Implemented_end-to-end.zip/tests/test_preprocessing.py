import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.preprocessing.pipeline import (  # noqa: E402
    normalize_rating,
    remove_near_duplicates,
)


def test_normalize_rating_various_scales():
    assert normalize_rating("4/5") == 4.0
    assert normalize_rating("80%") == 4.2
    assert normalize_rating("8 out of 10") == 4.2
    assert normalize_rating(3) == 3.0
    assert normalize_rating(0) == 1.0


def test_near_duplicate_filter_collapses_similar_texts():
    data = pd.DataFrame(
        [
            {
                "review_id": "a",
                "platform": "trustpilot",
                "product_name": "Device",
                "review_text": "Great phone with amazing battery life and screen.",
            },
            {
                "review_id": "b",
                "platform": "trustpilot",
                "product_name": "Device",
                "review_text": "Great phone with amazing battery life & screen!!",
            },
            {
                "review_id": "c",
                "platform": "google",
                "product_name": "Device",
                "review_text": "Battery drains quickly and screen flickers.",
            },
        ]
    )
    filtered, logs = remove_near_duplicates(data, threshold=0.8)
    assert len(filtered) == 2
    assert any(log["removed_review_id"] == "b" for log in logs)

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.grounding.semantic_grounding import (  # noqa: E402
    GroundingThresholds,
    categorize_similarity,
)


def test_categorize_similarity_respects_thresholds():
    thresholds = GroundingThresholds(flag=0.5, strong=0.7)
    assert categorize_similarity(0.8, thresholds) == "strong"
    assert categorize_similarity(0.6, thresholds) == "medium"
    assert categorize_similarity(0.4, thresholds) == "weak"

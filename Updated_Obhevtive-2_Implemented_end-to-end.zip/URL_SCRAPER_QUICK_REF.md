# 🔧 Quick Reference - Universal URL Scraper

## ⚡ Quick Commands

### Test URL Detection
```powershell
python src/utils/url_detector.py
```

### Scrape Reviews (CLI)
```powershell
# Yelp (most reliable)
python scrape_url.py --url "https://www.yelp.com/biz/food-for-friends-brighton" --limit 10

# Google Maps (via Apify)
python scrape_url.py --url "https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6" --limit 10

# Trustpilot (may need Selenium fix)
python scrape_url.py --url "https://www.trustpilot.com/review/www.asus.com" --limit 10
```

### Scrape via Dashboard
```powershell
streamlit run streamlit_app.py
# Then go to: "7_URL_Scraper" page
```

---

## 📁 File Locations

| What | Where |
|------|-------|
| **Scraped Data** | `data/scraped/*.csv` |
| **Configuration** | `config/config.yaml` (scraping section) |
| **CLI Tool** | `scrape_url.py` |
| **Dashboard Page** | `pages/7_URL_Scraper.py` |
| **URL Detector** | `src/utils/url_detector.py` |
| **Universal Scraper** | `src/data_collection/universal_scraper.py` |

---

## 🎯 Your Test URLs

```
Trustpilot: https://www.trustpilot.com/review/www.asus.com
Yelp:       https://www.yelp.com/biz/food-for-friends-brighton
Google:     https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6
```

---

## 🔑 Apify API Key

```
apify_api_Xb3CqKVrb59vwToryufgc7i8Gndpkr1ivP8e
```

Already configured in `config/config.yaml`

---

## ✅ System Status

| Component | Status | Notes |
|-----------|--------|-------|
| URL Detector | ✅ Working | Tested all 3 platforms |
| Yelp Scraper | ✅ Ready | Selenium-based |
| Google Scraper | ✅ Ready | Apify + Selenium fallback |
| Trustpilot Scraper | ⚠️ Partial | Returns 0 reviews (needs Selenium) |
| CLI Tool | ✅ Working | Full features |
| Dashboard Page | ✅ Ready | UI complete |
| Dependencies | ✅ Installed | All packages ready |

---

## 🐛 Known Issues

1. **Trustpilot** returns 0 reviews
   - **Why:** Dynamic JavaScript loading
   - **Fix:** Add Selenium support (like Yelp)
   - **Workaround:** Test Yelp/Google first

---

## 🚀 Recommended Testing Order

1. ✅ URL Detector test (verified working)
2. 🧪 Yelp scraping (should work)
3. 🧪 Google scraping (should work)
4. 🔧 Trustpilot fix (if needed)

---

## 💡 Output Format

### CSV Columns
```
platform, rating, review_text, review_date, product_name, 
category, reviewer_name, verified_purchase, word_count, scraped_at
```

### File Naming
```
{platform}_{company}_{timestamp}.csv
Example: yelp_food_for_friends_brighton_20251106_235421.csv
```

---

## 📊 Next Steps

After scraping:
1. Check CSV in `data/scraped/`
2. Load into LLM Analysis page
3. Run multi-model analysis
4. Get insights!

---

**Full Documentation:** See `URL_SCRAPER_GUIDE.md`

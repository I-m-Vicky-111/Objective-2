# Objective 2 Pipeline – Comprehensive Guide

This document summarizes how the Objective 2 codebase is organized, how data flows through each stage, and how to run, validate, and extend the system. Use it alongside the repo tree (all paths are relative to the repo root).

---

## 1. Big picture

The project ingests multi-platform review CSVs, cleans them to a unified schema, and feeds batches of reviews into local Ollama models (llama3.2 by default) for summarization, sentiment scoring, and theme extraction. Outputs are grounded with MiniLM, metrics are written to JSON/CSV artifacts, telemetry captures hardware usage, and separate scripts compute human validation metrics and cross-model ablations.

```
data/raw/*.csv ──► preprocessing (dedup + filters, SQLite) ──► cleaned corpus
                                    │
                                    ▼
                         run_pipeline.py (LLM batches)
                            │   │   │
               summaries / sentiments / themes
                            │
            grounding + telemetry + weekly drift
                            │
 data/results/{analysis,telemetry,descriptive,weekly_sentiment}.*
```

---

## 2. Configuration files

| File | Purpose | Key keys |
|------|---------|----------|
| `config/config.yaml` | Primary pipeline config (base model). | `llm.server`, `llm.models`, `llm.generation`, `data.collection_window`, `grounding.*`, `evaluation.*`, `pipeline.batch_size`. |
| `config/config_alt.yaml` | Alternate run (qwen2.5) for ablation. | Same structure; different model tags. |

All thresholds (dedup, grounding), model tags, dates, token limits, etc. should only live in these YAMLs so runs are reproducible.

---

## 3. Data lifecycle

### 3.1 Raw inputs

- `scripts/seed_raw_data.py` populates `data/raw/{trustpilot,yelp,google}.csv` with 180 synthetic reviews (configurable counts). It deliberately injects spam/duplicates to drive dedup metrics.
- Required columns: `platform,category,product_name,rating,review_text,review_date,reviewer_name,verified_purchase`.
- Date window enforcement occurs in preprocessing using config values.

### 3.2 Preprocessing (`src/preprocessing/pipeline.py`)

Key functions:

| Function | Notes |
|----------|-------|
| `load_raw_reviews` | Loads all CSVs under `data/raw/` (error if missing). |
| `normalize_rating` | Maps diverse rating formats onto [1,5]. |
| `_is_spam` / `_is_english` | Filter logic for URLs/emails/promo text and language detection. |
| `remove_near_duplicates` | Dedups by platform/product grouping using RapidFuzz Levenshtein ≥ 0.85. |
| `_descriptive_stats` | Produces `data/results/descriptive.json` with `raw_n`, `n`, `kept_pct`, platform/category splits, rating stats. |
| `preprocess()` | Orchestrates the steps, writes `data/processed/reviews_clean.csv`, `data/processed/reviews.sqlite` (table `reviews`), and `data/logs/near_duplicates.csv`. |

Outputs: cleaned CSV/SQLite, descriptive metrics, near-duplicate log (may be empty but always present).

---

## 4. Core pipeline (`run_pipeline.py`)

Sequence per run:

1. Call `preprocess()` to refresh cleaned data + stats.
2. Chunk reviews by platform into `pipeline.batch_size` (default 50).
3. For each batch:
   - `OllamaAnalyzer.analyze_batch` returns summary, per-review sentiments, and themes (see §5).
   - `SemanticGrounder.assess` (MiniLM) grounds the summary sentence-by-sentence.
   - `TelemetryRecorder` captures GPU metrics during the batch.
4. Aggregate outputs into `data/results/analysis_results.json` with:
   - `models_requested` vs `models_used`
   - Per-batch summaries, sentiments, themes, grounding stats, telemetry, and source review metadata.
5. `weekly_sentiment()` (in `src/analysis/drift.py`) writes `data/results/weekly_sentiment.csv` with ISO week means.
6. Telemetry rollup stored in `data/results/telemetry.json` (`avg_power_w`, `avg_util_pct`, `peak_vram_mb`, `electricity_cost`, plus `note` when NVML is missing).

CLI options:

```
python run_pipeline.py [--config CONFIG] [--alt-model] [--results-out PATH]
```

Use `--alt-model` (or `scripts/run_pipeline_alt.sh`) to force the alternate model and write `analysis_results_alt.json`.

---

## 5. LLM integration (`src/llm_analysis/ollama_analyzer.py`)

Highlights:

- Health-checks `/api/tags` during init; raises if unreachable.
- `_request_generate` hits `/api/generate`; 404 triggers `_request_chat` with the same payload so older Ollama versions work.
- `_invoke` enforces non-empty responses; failures bubble up (no heuristics).
- Batch record includes `models_used` (actual tags) per stage and the generation parameters snapshot.

Heuristic helpers were removed—if Ollama isn’t running the pipeline stops, ensuring all artifacts are genuinely model-generated.

---

## 6. Grounding & telemetry

| Module | Path | Description |
|--------|------|-------------|
| Semantic grounding | `src/grounding/semantic_grounding.py` | Loads `sentence-transformers/all-MiniLM-L6-v2` (or a token-overlap fallback) to score each summary sentence against review sentences. Configurable `flag`/`strong` thresholds produce `strong/medium/weak` counts + weak sentence indices. |
| Telemetry | `src/telemetry/gpu_logger.py` | Uses `pynvml` sampling threads to gather utilization, power, and VRAM while each batch runs. Rollup includes `elapsed_hours`, `avg_power_w`, `electricity_cost`, and a `note` if NVML samples weren’t available. |

---

## 7. Weekly drift (`src/analysis/drift.py`)

`weekly_sentiment(records, output_csv)` groups review-level sentiment records by ISO week (Monday as start). The pipeline passes every sentiment with its date to produce `data/results/weekly_sentiment.csv`. Empty or NaN dates are dropped gracefully.

---

## 8. Validation workflow

1. Generate references: `scripts/seed_references.py` samples 50 reviews from the cleaned CSV and writes `data/validation/references.csv` with columns:
   `review_id,platform,ref_summary,human_sentiment,human_themes` (themes delimited with `;`). Stratification target: 18 Trustpilot / 17 Yelp / 15 Google.
2. Run `python validate.py`:
   - Reads `analysis_results.json` + `references.csv`.
   - Computes ROUGE-1/2/L (via `rouge-score`, or token-overlap fallback), BERTScore F1 (or fallback), Cohen’s κ (binned via config edges), MAE, Pearson r/p, ANOVA by platform, and theme precision/recall after synonym mapping.
   - Outputs `data/results/validation_metrics.json`, including `fallback_overlap` to indicate whether fallbacks were used.
   - Gracefully emits `analysis_results_missing` / `references_missing` errors if prerequisites aren’t available.

---

## 9. Cross-model ablation

1. Run the alternate pipeline (`python run_pipeline.py --alt-model`) to produce `data/results/analysis_results_alt.json`.
2. Execute `python scripts/compare_models.py --base data/results/analysis_results.json --alt data/results/analysis_results_alt.json` (configurable via `--config`, default `config/config.yaml`).
3. Output `data/results/ablation_flag.json` containing:
   - `base_avg_sentiment`, `alt_avg_sentiment`, `delta_sentiment`
   - `flagged` boolean based on `evaluation.delta_sentiment_flag`
   - `top_theme_differences` (largest count deltas across runs)

Use this artifact to justify model selection or highlight significant sentiment drift between models.

---

## 10. Evidence artifacts (must exist after full run)

| Path | Contents |
|------|----------|
| `data/results/descriptive.json` | Corpus stats: `raw_n`, `n`, `kept_pct`, rating percentiles, platform/category splits. |
| `data/processed/reviews_clean.csv` | Cleaned reviews aligned with stats. |
| `data/processed/reviews.sqlite` | SQLite mirror (table `reviews`). |
| `data/logs/near_duplicates.csv` | Dedup decisions (kept/removed IDs, similarity). |
| `data/results/analysis_results.json` | Batch outputs: summaries, sentiments, themes, grounding, telemetry, models used. |
| `data/results/analysis_results_alt.json` | Alternate model run (generated separately). |
| `data/results/weekly_sentiment.csv` | ISO week sentiment averages. |
| `data/validation/references.csv` | 50-item human reference set. |
| `data/results/validation_metrics.json` | Real ROUGE/BERTScore/κ/MAE/r/p/ANOVA/theme metrics. |
| `data/results/ablation_flag.json` | Cross-model comparison summary + flag. |
| `data/results/telemetry.json` | NVML-based telemetry rollup (with note if unavailable). |

Automated spot checks (see Prompt §12) should pass once all files reflect the latest run.

---

## 11. CLI cheat sheet (in order)

```powershell
# 0. Dependencies + Ollama
pip install -r requirements.txt
pip install sentence-transformers torch rouge-score bert-score pynvml
ollama serve
ollama pull llama3.2:3b-instruct
ollama pull qwen2.5:3b-instruct
curl http://127.0.0.1:11434/api/tags  # sanity check

# 1. Seed data (optional helper)
python scripts/seed_raw_data.py

# 2. Base pipeline (LLM batches + telemetry + grounding)
python run_pipeline.py

# 3. Seed human references (if not provided manually)
python scripts/seed_references.py

# 4. Validation metrics
python validate.py

# 5. Alt-model run + ablation comparison
python run_pipeline.py --alt-model
python scripts/compare_models.py --base data/results/analysis_results.json --alt data/results/analysis_results_alt.json

# (Optional) Re-run pipeline to refresh telemetry after enabling NVML
python run_pipeline.py
```

---

## 12. Tests

Pytest suite (`pytest tests`) covers key utilities:

| File | Coverage |
|------|----------|
| `tests/test_preprocessing.py` | Rating normalization + near-dup grouping logic. |
| `tests/test_grounding.py` | Threshold categorization for grounding. |
| `tests/test_evaluation.py` | Sentiment binning. |
| `tests/test_drift.py` | ISO week start helper. |

Additional legacy integration scripts (e.g., `test_multi_model.py`) are skipped automatically inside pytest but can be run manually for interactive experiments.

---

## 13. Troubleshooting tips

| Symptom | Fix |
|---------|-----|
| `No raw CSVs found` | Run `scripts/seed_raw_data.py` or provide your own `data/raw/*.csv`. |
| Ollama 404 on `/api/generate` | Ensure models are pulled, server is on `127.0.0.1`, fallback to `/api/chat` happens automatically—otherwise inspect analyzer logs. |
| `sentence-transformers` or `torch` missing | Install extras (`pip install sentence-transformers torch`). Grounding falls back to token overlap but validation should note `fallback_overlap=true`. |
| Validation error `references_missing` | Create/refresh `data/validation/references.csv` via seeding script or manual annotation. |
| Telemetry `avg_power_w` null | Install `pynvml`, ensure `nvidia-smi` works, rerun pipeline. A `note` field in telemetry explains when NVML data isn’t available. |
| Weekly sentiment constant | Indicates sentiments weren’t populated (likely due to LLM failure). Check `analysis_results.json` for real `models_used` entries. |

---

By following this guide you can reproduce the full Objective 2 workflow, generate the required evidence artifacts, and understand where to modify or extend each component. Keep configs as the single source of truth, re-run the pipeline whenever raw data or models change, and rely on the validation/ablation scripts for rigorous verification. 

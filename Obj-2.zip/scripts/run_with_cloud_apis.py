"""
Wrapper script to run pipeline with cloud APIs.
Sets API keys and runs the pipeline.
"""
import os
import sys
import subprocess

# Set API keys
os.environ['GOOGLE_API_KEY'] = 'AIzaSyA9-ipcwa-RWh8mtixFb4Os40rXzn2SZpg'
os.environ['GROQ_API_KEY'] = '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'

# Fix Windows console encoding
if sys.platform == 'win32':
    os.environ['PYTHONIOENCODING'] = 'utf-8'

print("=" * 80)
print(" RUNNING PIPELINE WITH CLOUD APIs")
print("=" * 80)
print(f"\nGoogle API Key set: {'GOOGLE_API_KEY' in os.environ}")
print(f"Groq API Key set: {'GROQ_API_KEY' in os.environ}")
print("\nStarting pipeline...\n")

# Run the pipeline
subprocess.run([sys.executable, 'run_pipeline.py', '--config', 'config/config_cloud.yaml'])

"""
Test Multi-Model LLM Analysis
Tests all 3 specialized Ollama models on sample reviews
"""

import sys
import os
sys.path.append('src')

import pandas as pd
from src.llm_analysis.ollama_analyzer import OllamaAnalyzer
import json
from datetime import datetime

print("=" * 80)
print("🧪 MULTI-MODEL LLM ANALYSIS TEST")
print("=" * 80)
print()

# Load reviews
print("📁 Loading test reviews...")
df = pd.read_csv("data/processed/reviews_clean.csv")
print(f"✅ Loaded {len(df)} reviews from 3 platforms")
print(f"   - Trustpilot: {len(df[df['platform'] == 'trustpilot'])} reviews")
print(f"   - Yelp: {len(df[df['platform'] == 'yelp'])} reviews")
print(f"   - Google: {len(df[df['platform'] == 'google'])} reviews")
print()

# Use first 10 reviews for quick test
test_df = df.head(10)
test_reviews = test_df['review_text'].tolist()  # Extract just the review texts
product_name = "Mixed Products (iPhone, Hotels, Google)"  # Combined products
print(f"🎯 Testing with {len(test_reviews)} reviews")
print(f"📦 Product: {product_name}")
print()

# Initialize analyzer
print("🔧 Initializing OllamaAnalyzer...")
analyzer = OllamaAnalyzer()
print()

# Test Ollama connection
print("🔌 Testing connection to Ollama server...")
is_connected = analyzer.test_connection()

if not is_connected:
    print("❌ ERROR: Could not connect to Ollama")
    print("   Make sure Ollama is running: ollama serve")
    sys.exit(1)

print("✅ Connected to Ollama successfully!")
print()
print("🤖 Multi-Model Configuration:")
print(f"   📝 Summarization:    qwen3-vl:235b-cloud    (235B parameters)")
print(f"   😊 Sentiment:        gpt-oss:120b-cloud    (120B parameters)")  
print(f"   🎨 Theme Extraction: kimi-k2:1t-cloud      (1 TRILLION parameters!)")
print()
print("=" * 80)
print()

# Run analysis
print("🚀 Starting multi-model analysis...")
print("⏱️  This may take 2-5 minutes due to large cloud models...")
print()

start_time = datetime.now()

try:
    results = analyzer.analyze_batch(test_reviews, product_name=product_name)
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    print()
    print("=" * 80)
    print("✅ ANALYSIS COMPLETE!")
    print("=" * 80)
    print()
    
    # Display results
    print(f"⏱️  Processing Time: {duration:.1f} seconds ({duration/60:.2f} minutes)")
    print(f"📊 Reviews Analyzed: {len(test_reviews)}")
    print()
    
    print("-" * 80)
    print("📝 SUMMARY (qwen3-vl:235b-cloud)")
    print("-" * 80)
    print(results['summary'])
    print()
    
    print("-" * 80)
    print("😊 SENTIMENT ANALYSIS (gpt-oss:120b-cloud)")
    print("-" * 80)
    print(f"Score: {results['sentiment']['sentiment_score']:.3f} (-1.0 to +1.0)")
    print(f"Confidence: {results['sentiment']['confidence']}")
    print(f"Justification: {results['sentiment']['justification']}")
    print()
    
    print("-" * 80)
    print("🎨 KEY THEMES (kimi-k2:1t-cloud)")
    print("-" * 80)
    for i, theme in enumerate(results['themes'], 1):
        print(f"{i}. {theme}")
    print()
    
    print("-" * 80)
    print("🤖 MODELS USED")
    print("-" * 80)
    print(f"Summarization: {results.get('models_used', {}).get('summarization', 'unknown')}")
    print(f"Sentiment:     {results.get('models_used', {}).get('sentiment', 'unknown')}")
    print(f"Themes:        {results.get('models_used', {}).get('themes', 'unknown')}")
    print()
    
    # Save results
    output_path = "data/results/test_multi_model_analysis.json"
    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)
    
    print("=" * 80)
    print(f"💾 Results saved to: {output_path}")
    print("=" * 80)
    print()
    
    # Performance metrics
    print("📈 PERFORMANCE METRICS:")
    print(f"   Average time per review: {duration/len(test_reviews):.2f} seconds")
    print(f"   Reviews per minute: {len(test_reviews)/(duration/60):.1f}")
    print(f"   Cost: $0.00 (Local Ollama models)")
    print()
    
    print("🎉 Multi-model LLM analysis completed successfully!")
    print()

except KeyboardInterrupt:
    print("\n⚠️  Analysis interrupted by user")
    sys.exit(1)
except Exception as e:
    print(f"\n❌ ERROR during analysis: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

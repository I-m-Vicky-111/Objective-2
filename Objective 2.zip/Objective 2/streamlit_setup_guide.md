# 🚀 Streamlit Demo Setup Guide

## 📋 Prerequisites

* Python 3.8+
* Ollama installed and running
* Your review analysis codebase
* At least 8GB RAM

---

## 🔧 Step 1: Install Streamlit Dependencies

Create a new file `requirements_streamlit.txt`:

```txt
# Streamlit dependencies
streamlit==1.29.0
plotly==5.18.0
pandas==2.0.3
```

Install:

```bash
pip install -r requirements_streamlit.txt
```

---

## 📁 Step 2: Project Structure

Make sure your project looks like this:

```
project_root/
├── streamlit_app.py          # The Streamlit app (artifact above)
├── data/
│   ├── raw/
│   ├── processed/
│   │   └── reviews_clean.csv  # Your processed data
│   └── results/
│       └── analysis_results.json  # Your analysis results
├── src/
│   ├── llm_analysis/
│   │   └── ollama_analyzer.py  # Your LLM analyzer
│   └── ...
└── requirements_streamlit.txt
```

---

## 🎯 Step 3: Launch the App

### Option 1: Quick Launch

```bash
# Make sure Ollama is running
ollama serve

# In another terminal, launch Streamlit
streamlit run streamlit_app.py
```

### Option 2: Custom Port

```bash
streamlit run streamlit_app.py --server.port 8080
```

### Option 3: Remote Access (for demo on another machine)

```bash
streamlit run streamlit_app.py --server.address 0.0.0.0 --server.port 8501
```

---

## 📊 Step 4: Using the Dashboard

### **Page 1: Home (🏠)**

* System status overview
* Quick start guide
* Check Ollama connection

### **Page 2: Data Upload (📤)**

Three tabs:

1. **Upload CSV** : Drag-drop your review CSV

* Required columns: `platform`, `rating`, `review_text`, `review_date`
* Validates and saves to `data/processed/`

1. **Load Existing** : Load previously uploaded data
2. **Data Preview** : View statistics and charts

### **Page 3: LLM Analysis (🤖)**

Two tabs:

1. **Batch Analysis** :

* Select batch size (10-100 reviews)
* Choose number of batches
* Click "Start Analysis"
* Watch progress bar
* Results auto-saved to `data/results/analysis_results.json`

1. **Test Single Review** :

* Enter any review text
* Get instant sentiment score (gauge chart)
* Generate summary
* Test different review types

### **Page 4: Visualizations (📊)**

Three tabs:

1. **Platform Analysis** :

* Pie chart: Review distribution
* Box plot: Ratings by platform
* Violin plot: Review length

1. **Sentiment Analysis** :

* Histogram: Sentiment scores
* Bar chart: Positive/Neutral/Negative categories
* Key metrics

1. **Theme Analysis** :

* Top 10 themes bar chart
* Theme sentiment scatter plot
* Full themes table

### **Page 5: Results Dashboard (📈)**

* Key metrics cards
* Expandable batch summaries
* Export buttons:
  * Download CSV
  * Download JSON

### **Page 6: Settings (⚙️)**

* LLM configuration
* Data management (clear cache)
* About information

---

## 🎨 Demo Workflow

### **For Live Presentation:**

1. **Start with Home Page**
   * Show system status (all green)
   * Explain the workflow
2. **Navigate to Data Upload**
   * Upload sample CSV
   * Show data preview charts
   * Highlight data quality metrics
3. **Go to LLM Analysis**
   * **Test Single Review** first (quick demo):
     * Enter: "Great camera but terrible battery life"
     * Show instant sentiment: ~0.2 (mixed)
     * Generate summary
   * **Batch Analysis** :
   * Set batch size: 50
   * Start analysis
   * Watch progress bar (shows it's actually working)
4. **Show Visualizations**
   * Platform comparison
   * Sentiment distribution
   * Top themes
5. **Results Dashboard**
   * Show comprehensive metrics
   * Expand a batch summary
   * Export to CSV
6. **Settings**
   * Show Ollama connection test
   * Demonstrate clearing data

---

## 🐛 Troubleshooting

### **Error: "Cannot import OllamaAnalyzer"**

```bash
# Make sure src/ is in the right place
ls src/llm_analysis/ollama_analyzer.py

# Or add to PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:${PWD}/src"
```

### **Error: "Ollama not connected"**

```bash
# Check if Ollama is running
curl http://localhost:11434/api/tags

# If not, start it
ollama serve
```

### **Error: "No module named 'plotly'"**

```bash
pip install plotly streamlit pandas
```

### **Slow Performance**

* Reduce batch size (try 20 instead of 50)
* Close other GPU applications
* Check GPU temperature (should be <80°C)

### **CSV Upload Fails**

* Check file encoding (should be UTF-8)
* Verify required columns exist
* Try smaller file (<10MB first)

---

## 📸 Screenshots You Can Take

For your presentation/documentation:

1. **Home page** - System status (all green)
2. **Data upload** - CSV preview with charts
3. **Single review test** - Sentiment gauge showing score
4. **Batch analysis** - Progress bar at 50%
5. **Platform visualization** - Pie chart
6. **Sentiment distribution** - Histogram
7. **Results dashboard** - Metrics cards
8. **Export dialog** - Download buttons

---

## 🎥 Recording the Demo

### **Recommended Flow (3-5 minutes):**

**[0:00-0:30] Introduction**

* "This is our interactive dashboard for multi-platform review analysis"
* Show home page, point out system status

**[0:30-1:00] Data Upload**

* Upload CSV
* "We collected 167 reviews from 3 platforms"
* Show preview charts

**[1:00-2:00] Single Review Test**

* Type a review: "Amazing product! But expensive and poor customer service"
* Show sentiment gauge: ~0.3 (mildly positive)
* Generate summary
* "Notice how it captures both positive and negative aspects"

**[2:00-3:30] Batch Analysis**

* "Now let's analyze 50 reviews at once"
* Click Start Analysis
* While processing: "This uses our local Llama 3.2 model, no API calls"
* Show progress bar
* Open results: "Here's the summary and extracted themes"

**[3:30-4:30] Visualizations**

* Platform distribution: "Most reviews from Trustpilot"
* Sentiment histogram: "70% positive reviews"
* Top themes: "Battery life is the #1 concern"

**[4:30-5:00] Conclusion**

* Results dashboard
* "All of this runs locally on consumer hardware"
* "Zero API costs, complete data privacy"
* Export button: "Results can be exported for reporting"

---

## 🚀 Advanced Features

### **Custom Themes**

Edit `streamlit_app.py` to change colors:

```python
st.set_page_config(
    page_title="Review Analysis",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        'About': "Custom about text"
    }
)
```

### **Add Authentication**

For production deployment:

```bash
pip install streamlit-authenticator
```

### **Deploy to Cloud**

```bash
# Streamlit Community Cloud (free)
# 1. Push code to GitHub
# 2. Connect at share.streamlit.io
# 3. Deploy in 1 click
```

---

## 📝 Sample CSV Format

Create `sample_reviews.csv` for testing:

```csv
platform,rating,review_text,review_date,product_name,category
trustpilot,5,"Great product! Love it.",2024-11-01,iPhone 15,electronics
yelp,3,"Average. Nothing special.",2024-11-02,Marriott Hotel,hospitality
google,1,"Terrible customer service.",2024-11-03,Apple Store,electronics
trustpilot,4,"Good but expensive.",2024-11-04,Sony Headphones,electronics
yelp,5,"Excellent stay! Highly recommend.",2024-11-05,Hilton Hotel,hospitality
```

---

## 🎓 Tips for Rebecca

Since you're helping Rebecca, here are specific tips:

### **If She Presents This:**

1. **Practice the single review test** - it's the most impressive live demo
2. **Pre-load data** - don't make audience wait for uploads
3. **Have backup screenshots** - in case live demo fails
4. **Prepare 2-3 example reviews** to analyze:
   * One clearly positive
   * One clearly negative
   * One mixed (most interesting!)

### **Key Talking Points:**

* "This dashboard makes our research  **interactive and accessible** "
* "Anyone can test their own reviews in real-time"
* "All processing happens **locally** - no cloud, no costs"
* "This demonstrates the **practical viability** of our approach"

---

## 🎉 Success Checklist

Before your demo/presentation:

* [ ] Streamlit launches without errors
* [ ] Ollama connection shows green checkmark
* [ ] Sample data loads correctly
* [ ] Single review test works (< 5 seconds)
* [ ] Batch analysis completes (test with 10 reviews)
* [ ] All visualizations render properly
* [ ] Export buttons generate files
* [ ] You can navigate between pages smoothly

---

**Now you have a fully functional, presentation-ready demo dashboard! 🎊**

Run it, test it, and wow your audience with live analysis!

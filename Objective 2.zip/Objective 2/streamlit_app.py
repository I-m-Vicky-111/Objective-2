# streamlit_app.py
"""
Interactive Demo Dashboard for Multi-Platform Review Analysis
Run with: streamlit run streamlit_app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import os
from datetime import datetime
import sys

# Add src to path for imports
sys.path.append('src')

# Import your modules
try:
    from llm_analysis.ollama_analyzer import OllamaAnalyzer
except ImportError:
    st.error("Cannot import OllamaAnalyzer. Make sure src/llm_analysis/ollama_analyzer.py exists.")
    OllamaAnalyzer = None

# ============================================
# PAGE CONFIGURATION
# ============================================

st.set_page_config(
    page_title="Review Analysis Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        border-left: 4px solid #1f77b4;
    }
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        padding: 1rem;
        border-radius: 0.5rem;
        color: #155724;
    }
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        padding: 1rem;
        border-radius: 0.5rem;
        color: #856404;
    }
</style>
""", unsafe_allow_html=True)

# ============================================
# SIDEBAR - NAVIGATION & SETTINGS
# ============================================

st.sidebar.title("🎛️ Navigation")
page = st.sidebar.radio(
    "Select Page",
    ["🏠 Home", "📤 Data Upload", "🤖 LLM Analysis", "📊 Visualizations", "📈 Results Dashboard", "⚙️ Settings"]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 📌 Quick Stats")

# Load data if exists
if os.path.exists("data/processed/reviews_clean.csv"):
    df = pd.read_csv("data/processed/reviews_clean.csv")
    st.sidebar.metric("Total Reviews", len(df))
    st.sidebar.metric("Platforms", df['platform'].nunique() if 'platform' in df.columns else "N/A")
else:
    st.sidebar.info("No data loaded yet. Upload data to begin.")
    df = None

st.sidebar.markdown("---")
st.sidebar.markdown("""
**Research Project:**  
Objective 2 - Multi-Platform Review Analysis  
*Powered by Llama 3.2 (Local)*
""")

# ============================================
# PAGE 1: HOME
# ============================================

if page == "🏠 Home":
    st.markdown('<p class="main-header">📊 Multi-Platform Review Analysis Dashboard</p>', unsafe_allow_html=True)
    
    st.markdown("""
    ## Welcome to the Interactive Demo
    
    This dashboard demonstrates the complete pipeline for analyzing customer reviews 
    from multiple platforms (Trustpilot, Yelp, Google Reviews) using local LLM deployment.
    
    ### 🎯 What This Demo Does:
    """)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **1️⃣ Data Collection**
        - Upload review data (CSV)
        - Multi-platform support
        - Data quality validation
        """)
    
    with col2:
        st.markdown("""
        **2️⃣ LLM Analysis**
        - Summarization
        - Sentiment scoring
        - Theme extraction
        """)
    
    with col3:
        st.markdown("""
        **3️⃣ Visualization**
        - Interactive charts
        - Cross-platform insights
        - Export reports
        """)
    
    st.markdown("---")
    
    # System Status
    st.subheader("🔧 System Status")
    
    status_col1, status_col2, status_col3 = st.columns(3)
    
    with status_col1:
        if OllamaAnalyzer:
            analyzer = OllamaAnalyzer()
            if analyzer.test_connection():
                st.markdown('<div class="success-box">✅ Ollama Connected</div>', unsafe_allow_html=True)
            else:
                st.markdown('<div class="warning-box">⚠️ Ollama Not Running</div>', unsafe_allow_html=True)
        else:
            st.error("❌ OllamaAnalyzer not available")
    
    with status_col2:
        if df is not None:
            st.markdown(f'<div class="success-box">✅ Data Loaded ({len(df)} reviews)</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="warning-box">⚠️ No Data Loaded</div>', unsafe_allow_html=True)
    
    with status_col3:
        if os.path.exists("data/results/analysis_results.json"):
            st.markdown('<div class="success-box">✅ Analysis Complete</div>', unsafe_allow_html=True)
        else:
            st.markdown('<div class="warning-box">⚠️ No Analysis Results</div>', unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Quick Start Guide
    st.subheader("🚀 Quick Start Guide")
    
    with st.expander("📖 Step-by-Step Instructions", expanded=True):
        st.markdown("""
        1. **Upload Data** (📤 Data Upload page)
           - Prepare CSV with columns: `platform`, `rating`, `review_text`, `review_date`
           - Upload file (max 200MB)
           - Preview and validate
        
        2. **Run Analysis** (🤖 LLM Analysis page)
           - Select reviews to analyze
           - Choose batch size (recommended: 50)
           - Click "Analyze" and wait (~5 min per batch)
        
        3. **View Results** (📊 Visualizations or 📈 Results Dashboard)
           - Explore sentiment distributions
           - Review extracted themes
           - Export reports
        
        4. **Test Individual Reviews** (🤖 LLM Analysis → "Test Single Review")
           - Enter custom review text
           - Get instant sentiment + summary
        """)

# ============================================
# PAGE 2: DATA UPLOAD
# ============================================

elif page == "📤 Data Upload":
    st.title("📤 Data Upload & Preprocessing")
    
    tab1, tab2, tab3 = st.tabs(["Upload CSV", "Load Existing", "Data Preview"])
    
    with tab1:
        st.subheader("Upload Review Data")
        
        st.markdown("""
        **Required CSV Columns:**
        - `platform` (e.g., "trustpilot", "yelp", "google")
        - `rating` (1.0 - 5.0)
        - `review_text` (the actual review content)
        - `review_date` (YYYY-MM-DD format)
        
        **Optional Columns:**
        - `product_name`, `reviewer_name`, `verified_purchase`, `category`
        """)
        
        uploaded_file = st.file_uploader("Choose CSV file", type="csv")
        
        if uploaded_file is not None:
            try:
                df_upload = pd.read_csv(uploaded_file)
                
                st.success(f"✅ File loaded: {len(df_upload)} rows")
                
                # Validation
                required_cols = ['platform', 'rating', 'review_text', 'review_date']
                missing_cols = [col for col in required_cols if col not in df_upload.columns]
                
                if missing_cols:
                    st.error(f"❌ Missing required columns: {missing_cols}")
                else:
                    st.success("✅ All required columns present")
                    
                    # Preview
                    st.dataframe(df_upload.head(10))
                    
                    # Save option
                    if st.button("💾 Save as Processed Data"):
                        os.makedirs("data/processed", exist_ok=True)
                        df_upload.to_csv("data/processed/reviews_clean.csv", index=False)
                        st.success("✅ Saved to data/processed/reviews_clean.csv")
                        st.balloons()
            
            except Exception as e:
                st.error(f"Error loading file: {e}")
    
    with tab2:
        st.subheader("Load Existing Data")
        
        if os.path.exists("data/processed/reviews_clean.csv"):
            df = pd.read_csv("data/processed/reviews_clean.csv")
            
            st.success(f"✅ Loaded: {len(df)} reviews")
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Total Reviews", len(df))
            col2.metric("Platforms", df['platform'].nunique() if 'platform' in df.columns else 0)
            col3.metric("Avg Rating", f"{df['rating'].mean():.2f}" if 'rating' in df.columns else "N/A")
            
        else:
            st.warning("No processed data found. Please upload data first.")
    
    with tab3:
        if df is not None:
            st.subheader("Data Preview & Statistics")
            
            # Platform distribution
            if 'platform' in df.columns:
                fig_platform = px.bar(
                    df['platform'].value_counts().reset_index(),
                    x='platform', y='count',
                    title="Reviews by Platform",
                    labels={'platform': 'Platform', 'count': 'Review Count'},
                    color='platform'
                )
                st.plotly_chart(fig_platform, use_container_width=True)
            
            # Rating distribution
            if 'rating' in df.columns:
                fig_rating = px.histogram(
                    df, x='rating',
                    title="Rating Distribution",
                    nbins=5,
                    labels={'rating': 'Star Rating', 'count': 'Frequency'}
                )
                st.plotly_chart(fig_rating, use_container_width=True)
            
            # Data table
            st.dataframe(df, use_container_width=True)
        else:
            st.info("Load data to see preview")

# ============================================
# PAGE 3: LLM ANALYSIS
# ============================================

elif page == "🤖 LLM Analysis":
    st.title("🤖 LLM Analysis Engine")
    
    tab1, tab2 = st.tabs(["Batch Analysis", "Test Single Review"])
    
    with tab1:
        st.subheader("Run Batch Analysis")
        
        if df is None:
            st.warning("⚠️ Please upload data first (📤 Data Upload page)")
        else:
            st.info(f"Loaded dataset: {len(df)} reviews")
            
            # Settings
            col1, col2 = st.columns(2)
            
            with col1:
                batch_size = st.slider("Batch Size", 10, 100, 50, 10)
                st.caption("Number of reviews to process together")
            
            with col2:
                num_batches = st.number_input("Number of Batches", 1, 10, 1)
                st.caption(f"Will process {batch_size * num_batches} reviews")
            
            if st.button("🚀 Start Analysis", type="primary"):
                if OllamaAnalyzer is None:
                    st.error("OllamaAnalyzer not available. Check imports.")
                else:
                    analyzer = OllamaAnalyzer()
                    
                    if not analyzer.test_connection():
                        st.error("❌ Cannot connect to Ollama. Please start Ollama server: `ollama serve`")
                    else:
                        progress_bar = st.progress(0)
                        status_text = st.empty()
                        
                        results = []
                        
                        for batch_num in range(num_batches):
                            status_text.text(f"Processing batch {batch_num + 1}/{num_batches}...")
                            
                            # Get batch
                            start_idx = batch_num * batch_size
                            end_idx = start_idx + batch_size
                            batch_reviews = df.iloc[start_idx:end_idx]['review_text'].tolist()
                            
                            # Analyze
                            result = analyzer.analyze_batch(batch_reviews, "Product")
                            result['batch_id'] = batch_num
                            result['review_count'] = len(batch_reviews)
                            results.append(result)
                            
                            progress_bar.progress((batch_num + 1) / num_batches)
                        
                        # Save results
                        os.makedirs("data/results", exist_ok=True)
                        with open("data/results/analysis_results.json", 'w') as f:
                            json.dump(results, f, indent=2)
                        
                        st.success("✅ Analysis Complete!")
                        st.balloons()
                        
                        # Display results
                        for result in results:
                            with st.expander(f"Batch {result['batch_id'] + 1} Results"):
                                st.markdown(f"**Summary:**\n{result['summary']}")
                                st.json(result['sentiment'])
                                st.json(result['themes'])
    
    with tab2:
        st.subheader("Test Single Review Analysis")
        
        st.markdown("Enter a review to analyze instantly:")
        
        sample_review = st.text_area(
            "Review Text",
            value="This product is amazing! Great quality and fast delivery. However, the customer service could be better.",
            height=150
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Analyze Sentiment"):
                if OllamaAnalyzer:
                    analyzer = OllamaAnalyzer()
                    if analyzer.test_connection():
                        with st.spinner("Analyzing..."):
                            sentiment = analyzer.analyze_sentiment(sample_review)
                        
                        st.success("Analysis Complete!")
                        
                        # Display sentiment
                        score = sentiment.get('sentiment_score', 0)
                        confidence = sentiment.get('confidence', 'unknown')
                        
                        # Gauge chart
                        fig = go.Figure(go.Indicator(
                            mode = "gauge+number+delta",
                            value = score,
                            domain = {'x': [0, 1], 'y': [0, 1]},
                            title = {'text': f"Sentiment Score<br><span style='font-size:0.8em'>Confidence: {confidence}</span>"},
                            delta = {'reference': 0},
                            gauge = {
                                'axis': {'range': [-1, 1]},
                                'bar': {'color': "darkblue"},
                                'steps' : [
                                    {'range': [-1, -0.3], 'color': "lightcoral"},
                                    {'range': [-0.3, 0.3], 'color': "lightyellow"},
                                    {'range': [0.3, 1], 'color': "lightgreen"}],
                                'threshold': {
                                    'line': {'color': "red", 'width': 4},
                                    'thickness': 0.75,
                                    'value': 0}}))
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                        st.json(sentiment)
                    else:
                        st.error("Ollama not connected")
                else:
                    st.error("OllamaAnalyzer not available")
        
        with col2:
            if st.button("Generate Summary"):
                if OllamaAnalyzer:
                    analyzer = OllamaAnalyzer()
                    if analyzer.test_connection():
                        with st.spinner("Summarizing..."):
                            summary = analyzer.summarize([sample_review], "Product")
                        
                        st.success("Summary Generated!")
                        st.markdown(f"**Summary:**\n\n{summary}")
                    else:
                        st.error("Ollama not connected")
                else:
                    st.error("OllamaAnalyzer not available")

# ============================================
# PAGE 4: VISUALIZATIONS
# ============================================

elif page == "📊 Visualizations":
    st.title("📊 Data Visualizations")
    
    if df is None:
        st.warning("No data loaded. Please upload data first.")
    else:
        tab1, tab2, tab3 = st.tabs(["Platform Analysis", "Sentiment Analysis", "Theme Analysis"])
        
        with tab1:
            st.subheader("Platform Comparison")
            
            col1, col2 = st.columns(2)
            
            with col1:
                # Platform distribution
                platform_counts = df['platform'].value_counts()
                fig1 = px.pie(
                    values=platform_counts.values,
                    names=platform_counts.index,
                    title="Review Distribution by Platform"
                )
                st.plotly_chart(fig1, use_container_width=True)
            
            with col2:
                # Rating by platform
                if 'rating' in df.columns:
                    fig2 = px.box(
                        df, x='platform', y='rating',
                        title="Rating Distribution by Platform",
                        color='platform'
                    )
                    st.plotly_chart(fig2, use_container_width=True)
            
            # Word count by platform
            if 'word_count' in df.columns:
                fig3 = px.violin(
                    df, x='platform', y='word_count',
                    title="Review Length Distribution by Platform",
                    color='platform',
                    box=True
                )
                st.plotly_chart(fig3, use_container_width=True)
        
        with tab2:
            st.subheader("Sentiment Analysis")
            
            if os.path.exists("data/results/analysis_results.json"):
                with open("data/results/analysis_results.json", 'r') as f:
                    results = json.load(f)
                
                # Extract sentiment scores
                sentiments = [r['sentiment']['sentiment_score'] for r in results if 'sentiment' in r]
                
                col1, col2 = st.columns(2)
                
                with col1:
                    # Sentiment distribution
                    fig_sent = px.histogram(
                        x=sentiments,
                        title="Sentiment Score Distribution",
                        labels={'x': 'Sentiment Score', 'y': 'Frequency'},
                        nbins=20
                    )
                    st.plotly_chart(fig_sent, use_container_width=True)
                
                with col2:
                    # Sentiment categories
                    categories = []
                    for s in sentiments:
                        if s < -0.3: categories.append("Negative")
                        elif s < 0.3: categories.append("Neutral")
                        else: categories.append("Positive")
                    
                    cat_counts = pd.Series(categories).value_counts()
                    fig_cat = px.bar(
                        x=cat_counts.index,
                        y=cat_counts.values,
                        title="Sentiment Categories",
                        labels={'x': 'Category', 'y': 'Count'},
                        color=cat_counts.index,
                        color_discrete_map={'Positive': 'green', 'Neutral': 'gray', 'Negative': 'red'}
                    )
                    st.plotly_chart(fig_cat, use_container_width=True)
                
                # Metrics
                avg_sentiment = sum(sentiments) / len(sentiments)
                col1, col2, col3 = st.columns(3)
                col1.metric("Average Sentiment", f"{avg_sentiment:.2f}")
                col2.metric("Positive Reviews", f"{sum(1 for s in sentiments if s > 0.3)}")
                col3.metric("Negative Reviews", f"{sum(1 for s in sentiments if s < -0.3)}")
            
            else:
                st.info("No analysis results found. Run analysis first.")
        
        with tab3:
            st.subheader("Theme Analysis")
            
            if os.path.exists("data/results/analysis_results.json"):
                with open("data/results/analysis_results.json", 'r') as f:
                    results = json.load(f)
                
                # Aggregate themes
                all_themes = []
                for result in results:
                    if 'themes' in result and isinstance(result['themes'], list):
                        all_themes.extend(result['themes'])
                
                if all_themes:
                    themes_df = pd.DataFrame(all_themes)
                    
                    # Top themes
                    if 'theme' in themes_df.columns:
                        theme_counts = themes_df['theme'].value_counts().head(10)
                        
                        fig_themes = px.bar(
                            x=theme_counts.values,
                            y=theme_counts.index,
                            orientation='h',
                            title="Top 10 Themes",
                            labels={'x': 'Frequency', 'y': 'Theme'}
                        )
                        st.plotly_chart(fig_themes, use_container_width=True)
                    
                    # Theme sentiments
                    if 'sentiment' in themes_df.columns and 'theme' in themes_df.columns:
                        fig_sent = px.strip(
                            themes_df.head(20), 
                            x='sentiment', 
                            y='theme',
                            title="Theme Sentiment Distribution",
                            color='sentiment',
                            color_discrete_map={'positive': 'green', 'negative': 'red', 'mixed': 'orange'}
                        )
                        st.plotly_chart(fig_sent, use_container_width=True)
                    
                    # Themes table
                    st.dataframe(themes_df, use_container_width=True)
                else:
                    st.info("No themes extracted yet.")
            else:
                st.info("No analysis results found. Run analysis first.")

# ============================================
# PAGE 5: RESULTS DASHBOARD
# ============================================

elif page == "📈 Results Dashboard":
    st.title("📈 Results Dashboard")
    
    if df is None or not os.path.exists("data/results/analysis_results.json"):
        st.warning("⚠️ Please upload data and run analysis first")
    else:
        # Load results
        with open("data/results/analysis_results.json", 'r') as f:
            results = json.load(f)
        
        # Key Metrics
        st.subheader("📊 Key Metrics")
        
        col1, col2, col3, col4 = st.columns(4)
        
        sentiments = [r['sentiment']['sentiment_score'] for r in results if 'sentiment' in r]
        avg_sentiment = sum(sentiments) / len(sentiments) if sentiments else 0
        
        col1.metric("Total Reviews Analyzed", sum(r.get('review_count', 0) for r in results))
        col2.metric("Batches Processed", len(results))
        col3.metric("Avg Sentiment Score", f"{avg_sentiment:.2f}")
        col4.metric("Processing Time", f"{sum(r.get('processing_time', 0) for r in results):.1f}s")
        
        st.markdown("---")
        
        # Batch Results
        st.subheader("📝 Batch Summaries")
        
        for i, result in enumerate(results):
            with st.expander(f"Batch {i+1} - {result.get('review_count', 0)} reviews"):
                st.markdown(f"**Summary:**\n\n{result.get('summary', 'N/A')}")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("**Sentiment:**")
                    st.json(result.get('sentiment', {}))
                
                with col2:
                    st.markdown("**Top Themes:**")
                    themes = result.get('themes', [])
                    if themes:
                        for theme in themes[:5]:
                            st.markdown(f"- **{theme.get('theme', 'N/A')}**: {theme.get('description', 'N/A')}")
        
        st.markdown("---")
        
        # Export
        st.subheader("💾 Export Results")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("📄 Export to CSV"):
                # Create export dataframe
                export_data = []
                for r in results:
                    export_data.append({
                        'batch_id': r.get('batch_id', 0),
                        'review_count': r.get('review_count', 0),
                        'sentiment_score': r.get('sentiment', {}).get('sentiment_score', 0),
                        'confidence': r.get('sentiment', {}).get('confidence', 'N/A'),
                        'summary': r.get('summary', 'N/A')
                    })
                
                export_df = pd.DataFrame(export_data)
                csv = export_df.to_csv(index=False)
                
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"analysis_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
        
        with col2:
            if st.button("📋 Export to JSON"):
                json_str = json.dumps(results, indent=2)
                
                st.download_button(
                    label="Download JSON",
                    data=json_str,
                    file_name=f"analysis_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json"
                )

# ============================================
# PAGE 6: SETTINGS
# ============================================

elif page == "⚙️ Settings":
    st.title("⚙️ System Settings")
    
    tab1, tab2, tab3 = st.tabs(["LLM Configuration", "Data Management", "About"])
    
    with tab1:
        st.subheader("LLM Configuration")
        
        st.markdown("**Ollama Settings**")
        
        model_name = st.text_input("Model Name", value="llama3.2:3b-instruct-q4_0")
        temperature = st.slider("Temperature", 0.0, 1.0, 0.3, 0.1)
        max_tokens = st.number_input("Max Tokens", 100, 2000, 500, 100)
        
        if st.button("Test Connection"):
            if OllamaAnalyzer:
                analyzer = OllamaAnalyzer(model_name=model_name, temperature=temperature, max_tokens=max_tokens)
                if analyzer.test_connection():
                    st.success("✅ Connection successful!")
                else:
                    st.error("❌ Cannot connect to Ollama. Make sure it's running.")
            else:
                st.error("OllamaAnalyzer not available")
    
    with tab2:
        st.subheader("Data Management")
        
        st.markdown("**Clear Data**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🗑️ Clear Processed Data"):
                if os.path.exists("data/processed/reviews_clean.csv"):
                    os.remove("data/processed/reviews_clean.csv")
                    st.success("✅ Processed data cleared")
                else:
                    st.info("No processed data to clear")
        
        with col2:
            if st.button("🗑️ Clear Analysis Results"):
                if os.path.exists("data/results/analysis_results.json"):
                    os.remove("data/results/analysis_results.json")
                    st.success("✅ Analysis results cleared")
                else:
                    st.info("No analysis results to clear")
    
    with tab3:
        st.subheader("About This Dashboard")
        
        st.markdown("""
        ### Multi-Platform Review Analysis System
        
        **Version:** 1.0.0  
        **Developed for:** Research Objective 2  
        **Last Updated:** November 2024
        
        **Key Features:**
        - Multi-platform review aggregation (Trustpilot, Yelp, Google)
        - Local LLM deployment (Llama 3.2)
        - Zero API costs
        - Interactive visualizations
        - Real-time analysis
        
        **Technology Stack:**
        - Frontend: Streamlit
        - LLM Backend: Ollama (Llama 3.2)
        - Visualization: Plotly
        - Data Processing: Pandas
        
        **Hardware Requirements:**
        - GPU: NVIDIA RTX 3050 or better (4GB+ VRAM)
        - RAM: 8GB minimum
        - Storage: 10GB free space
        
        **Citation:**
        If you use this tool in your research, please cite:
        ```
        [Your Name]. (2024). Multi-Platform Review Analysis Framework.
        Research Objective 2: Autonomous Prompt-Chaining Agents.
        ```
        
        ---
        
        💡 **Need Help?** Check the documentation or contact the research team.
        """)

# ============================================
# FOOTER
# ============================================

st.markdown("---")
st.markdown("""
<div style='text-align: center; color: gray; font-size: 0.9em;'>
    Multi-Platform Review Analysis Dashboard | Powered by Llama 3.2 (Local) | Research Project 2024
</div>
""", unsafe_allow_html=True)
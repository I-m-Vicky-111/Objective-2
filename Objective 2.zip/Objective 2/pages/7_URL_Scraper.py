"""
Streamlit Page: URL Scraper
Universal review scraper with live progress tracking
"""

import streamlit as st
import sys
import os
import pandas as pd
from datetime import datetime
import time

# Add src to path
sys.path.append('src')

from src.data_collection.universal_scraper import UniversalScraper
from src.utils.url_detector import detect_platform, extract_metadata
import yaml

# Page config
st.set_page_config(page_title="URL Scraper", page_icon="🔗", layout="wide")

# Load config
@st.cache_resource
def load_config():
    """Load scraping configuration"""
    try:
        with open('config/config.yaml', 'r') as f:
            config = yaml.safe_load(f)
        return config.get('scraping', {})
    except:
        return {}

# Initialize
config = load_config()

# Header
st.title("🔗 Universal URL Scraper")
st.markdown("Scrape reviews from **Trustpilot**, **Yelp**, or **Google Maps** by providing any URL")

# Sidebar
with st.sidebar:
    st.header("⚙️ Settings")
    
    limit = st.slider(
        "Number of reviews",
        min_value=5,
        max_value=100,
        value=60,
        step=5,
        help="Maximum number of reviews to collect"
    )
    
    output_format = st.selectbox(
        "Output format",
        options=["CSV", "JSON", "Both"],
        help="How to save the scraped data"
    )
    
    st.markdown("---")
    st.markdown("### 📋 Supported Platforms")
    st.markdown("✅ **Trustpilot** - Any company page")
    st.markdown("✅ **Yelp** - Any business page")
    st.markdown("✅ **Google Maps** - Any location")
    
    st.markdown("---")
    st.info("💡 **Tip**: Scraping may take 1-3 minutes depending on the platform")

# Main content
col1, col2 = st.columns([3, 1])

with col1:
    url_input = st.text_input(
        "🌐 Enter URL",
        placeholder="https://www.trustpilot.com/review/www.asus.com",
        help="Paste the full URL of the review page"
    )

with col2:
    st.markdown("<br>", unsafe_allow_html=True)
    scrape_button = st.button("🚀 Scrape Reviews", type="primary", use_container_width=True)

# URL Preview
if url_input:
    st.markdown("---")
    st.subheader("🔍 URL Analysis")
    
    platform = detect_platform(url_input)
    metadata = extract_metadata(url_input)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if platform != 'unknown':
            st.success(f"✅ Platform: **{platform.upper()}**")
        else:
            st.error("❌ **Unsupported Platform**")
            st.warning("Please use Trustpilot, Yelp, or Google Maps URLs")
    
    with col2:
        if metadata.get('company_name'):
            st.info(f"🏢 Company: **{metadata['company_name']}**")
        elif metadata.get('business_id'):
            business_name = metadata['business_id'].replace('-', ' ').title()
            st.info(f"🏪 Business: **{business_name}**")
        elif metadata.get('place_id'):
            st.info(f"📌 Place ID: **{metadata['place_id'][:12]}...**")
    
    with col3:
        st.metric("🎯 Target Reviews", limit)

# Scraping
if scrape_button and url_input:
    platform = detect_platform(url_input)
    
    if platform == 'unknown':
        st.error("❌ **Cannot scrape this URL**. Please use a Trustpilot, Yelp, or Google Maps URL.")
    else:
        st.markdown("---")
        st.subheader("🚀 Scraping in Progress...")
        
        # Progress indicators
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Initialize scraper
        status_text.text("Initializing scraper...")
        progress_bar.progress(10)
        time.sleep(0.5)
        
        scraper = UniversalScraper(config=config)
        
        # Start scraping
        status_text.text(f"Connecting to {platform.upper()}...")
        progress_bar.progress(30)
        
        result = scraper.scrape_url(url_input, limit=limit)
        
        progress_bar.progress(90)
        status_text.text("Processing results...")
        time.sleep(0.5)
        
        progress_bar.progress(100)
        
        if result['success']:
            reviews = result['reviews']
            
            # Success message
            st.success(f"✅ **Successfully scraped {len(reviews)} reviews!**")
            
            # Summary metrics
            st.markdown("---")
            st.subheader("📊 Summary")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Reviews", len(reviews))
            
            with col2:
                avg_rating = sum(r.get('rating', 0) for r in reviews) / len(reviews) if reviews else 0
                st.metric("Average Rating", f"{avg_rating:.2f} ⭐")
            
            with col3:
                positive = sum(1 for r in reviews if r.get('rating', 0) >= 4)
                st.metric("Positive Reviews", positive)
            
            with col4:
                negative = sum(1 for r in reviews if r.get('rating', 0) <= 2)
                st.metric("Negative Reviews", negative)
            
            # Rating distribution
            st.markdown("---")
            st.subheader("⭐ Rating Distribution")
            
            ratings = {}
            for r in reviews:
                rating = int(r.get('rating', 0))
                ratings[rating] = ratings.get(rating, 0) + 1
            
            rating_df = pd.DataFrame([
                {"Rating": f"{r} stars", "Count": count}
                for r, count in sorted(ratings.items(), reverse=True)
            ])
            
            if not rating_df.empty:
                st.bar_chart(rating_df.set_index("Rating"))
            else:
                st.info("No rating data available to display chart.")
            
            # Reviews table
            st.markdown("---")
            st.subheader("📝 Reviews")
            
            df = pd.DataFrame(reviews)
            
            # Display key columns
            display_columns = ['rating', 'review_text', 'reviewer_name', 'review_date']
            display_columns = [c for c in display_columns if c in df.columns]
            
            st.dataframe(
                df[display_columns].head(20),
                use_container_width=True,
                height=400
            )
            
            if len(df) > 20:
                st.info(f"Showing first 20 of {len(df)} reviews. Download full dataset below.")
            
            # Download buttons
            st.markdown("---")
            st.subheader("💾 Download Data")
            
            col1, col2, col3 = st.columns(3)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            company = metadata.get('company_name') or metadata.get('business_id') or platform
            company = company.replace('www.', '').replace('.com', '').replace('-', '_')
            
            with col1:
                if output_format in ["CSV", "Both"]:
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="📄 Download CSV",
                        data=csv,
                        file_name=f"{platform}_{company}_{timestamp}.csv",
                        mime="text/csv",
                        use_container_width=True
                    )
            
            with col2:
                if output_format in ["JSON", "Both"]:
                    import json
                    json_data = json.dumps(result, indent=2, ensure_ascii=False)
                    st.download_button(
                        label="📋 Download JSON",
                        data=json_data,
                        file_name=f"{platform}_{company}_{timestamp}.json",
                        mime="application/json",
                        use_container_width=True
                    )
            
            with col3:
                st.button("🔄 Scrape Another URL", on_click=lambda: st.rerun())
            
            # Next steps
            st.markdown("---")
            st.info("💡 **Next Step**: Use the downloaded data for LLM analysis in the 'LLM Analysis' page")
            
        else:
            # Error handling
            st.error(f"❌ **Scraping Failed**: {result['error']}")
            
            # Troubleshooting tips
            st.markdown("---")
            st.subheader("🔧 Troubleshooting")
            
            if platform == 'google':
                st.warning("**Google Maps**: Make sure you have a valid Apify API key in config.yaml")
                st.code("scraping:\n  google:\n    apify_key: 'your_key_here'")
            
            elif platform == 'yelp':
                st.warning("**Yelp**: This platform requires Selenium. Check that Chrome/ChromeDriver is installed.")
                st.code("pip install selenium webdriver-manager")
            
            elif platform == 'trustpilot':
                st.warning("**Trustpilot**: Check that the URL is accessible and rate limits aren't exceeded.")
            
            st.markdown("**Common issues:**")
            st.markdown("- Rate limiting (wait a few minutes and try again)")
            st.markdown("- Blocked by robots.txt")
            st.markdown("- Invalid URL format")
            st.markdown("- Network connectivity issues")

# Footer
st.markdown("---")
st.markdown("**🔗 Universal Scraper** | Powered by BeautifulSoup, Selenium & Apify | Built for multi-platform review analysis")

# Example URLs (if no input)
if not url_input:
    st.markdown("---")
    st.subheader("📌 Example URLs")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("**Trustpilot**")
        st.code("https://www.trustpilot.com/review/www.asus.com", language=None)
        if st.button("Try Trustpilot Example"):
            url_input = "https://www.trustpilot.com/review/www.asus.com"
    
    with col2:
        st.markdown("**Yelp**")
        st.code("https://www.yelp.com/biz/food-for-friends-brighton", language=None)
        if st.button("Try Yelp Example"):
            url_input = "https://www.yelp.com/biz/food-for-friends-brighton"
    
    with col3:
        st.markdown("**Google Maps**")
        st.code("https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6", language=None)
        if st.button("Try Google Example"):
            url_input = "https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6"

# 🚀 QUICK START GUIDE - 24 Hour Execution

## ⏱️ Time Allocation

| Phase                | Duration | Task                            | Status |
| -------------------- | -------- | ------------------------------- | ------ |
| **Hour 0-1**   | 1 hour   | Setup & Installation            | 🔄     |
| **Hour 1-4**   | 3 hours  | Data Collection (Overnight Run) | ⏳     |
| **Hour 4-5**   | 1 hour   | Preprocessing                   | ⏳     |
| **Hour 5-10**  | 5 hours  | LLM Analysis (GPU intensive)    | ⏳     |
| **Hour 10-12** | 2 hours  | Validation & Metrics            | ⏳     |
| **Hour 12-16** | 4 hours  | Results & Visualization         | ⏳     |
| **Hour 16-24** | 8 hours  | Paper Writing                   | ⏳     |

---

## 🛠️ STEP 1: Installation (Hour 0-1)

### 1.1 Clone/Download Code

```bash
# Create project directory
mkdir review_analysis
cd review_analysis

# Create folder structure
mkdir -p data/{raw,processed,results}
mkdir -p results/{figures,tables}
mkdir -p logs
mkdir -p src/{data_collection,preprocessing,llm_analysis,validation}
mkdir config
```

### 1.2 Install Python Dependencies

```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate  # Windows

# Install dependencies
pip install requests beautifulsoup4 selenium webdriver-manager pandas numpy
pip install langdetect nltk scikit-learn matplotlib seaborn plotly
pip install pyyaml python-dotenv tqdm
```

### 1.3 Install Ollama (If Not Already)

```bash
# Download from: https://ollama.ai/download/windows
# After installation, run:

ollama serve  # Start Ollama server (keep this running in separate terminal)

# In another terminal:
ollama pull llama3.2:3b-instruct-q4_0  # Download model (~2GB)
```

### 1.4 Verify Ollama

```bash
# Test Ollama
ollama list  # Should show llama3.2:3b-instruct-q4_0

# Quick test
ollama run llama3.2:3b-instruct-q4_0 "Hello, are you working?"
```

### 1.5 Download NLTK Data

```python
# Run in Python:
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('vader_lexicon')
```

---

## 📊 STEP 2: Data Collection (Hour 1-4)

### 2.1 Save All Code Files

Save these files from the artifacts:

1. `config/config.yaml` → Configuration
2. `src/data_collection/trustpilot_collector.py` → Trustpilot scraper
3. `src/data_collection/yelp_collector.py` → Yelp scraper
4. `src/data_collection/google_collector.py` → Google scraper
5. `src/llm_analysis/ollama_analyzer.py` → LLM analyzer
6. `main.py` → Main pipeline

### 2.2 Test Individual Scrapers

```bash
# Test Trustpilot (5-10 reviews)
python src/data_collection/trustpilot_collector.py

# Test Yelp
python src/data_collection/yelp_collector.py

# Test Google
python src/data_collection/google_collector.py
```

### 2.3 Run Full Collection (Overnight)

```bash
# This will collect 60 reviews from each platform (180 total)
# Estimated time: 2-3 hours (with rate limiting)

python main.py --mode collect
```

 **💡 TIP** : Run this overnight. You'll wake up to collected data!

---

## 🧹 STEP 3: Preprocessing (Hour 4-5)

### 3.1 Run Preprocessing

```bash
python main.py --mode preprocess
```

 **Expected Output** :

* `data/processed/reviews_clean.csv` (~150-170 reviews after filtering)
* Console log showing:
  * Duplicates removed
  * Spam filtered
  * Quality checks passed
  * Language distribution

### 3.2 Verify Data Quality

```python
import pandas as pd

df = pd.read_csv('data/processed/reviews_clean.csv')
print(f"Total reviews: {len(df)}")
print(f"Platforms: {df['platform'].value_counts()}")
print(f"Average rating: {df['rating'].mean():.2f}")
print(f"Average word count: {df['word_count'].mean():.1f}")
```

---

## 🤖 STEP 4: LLM Analysis (Hour 5-10)

### 4.1 Verify Ollama is Running

```bash
# In one terminal, make sure this is running:
ollama serve

# In another terminal:
ollama list  # Verify model is loaded
```

### 4.2 Test LLM Analyzer First

```bash
cd src/llm_analysis
python ollama_analyzer.py  # Run test function
```

 **Expected Output** :

```
✓ Connected to Ollama. Model 'llama3.2:3b-instruct-q4_0' is available.
Generating summary for 5 reviews...
✓ Summary generated in 3.45s
Analyzing sentiment...
✓ Sentiment: 0.4 (medium)
Extracting themes...
✓ Extracted 5 themes
```

### 4.3 Run Full Analysis

```bash
# This is GPU-intensive and will take 3-5 hours for 150 reviews
python main.py --mode analyze
```

 **Progress Monitoring** :

```
Processing batch 1/3...
✓ Batch complete - Sentiment: 0.65
Processing batch 2/3...
✓ Batch complete - Sentiment: 0.42
...
```

 **💡 Performance Tips** :

* Close all other applications
* Monitor GPU temperature (shouldn't exceed 80°C)
* If overheating, add `time.sleep(60)` between batches in code

---

## 📈 STEP 5: Validation & Visualization (Hour 10-12)

### 5.1 Generate Metrics

```bash
python main.py --mode visualize
```

 **Generated Files** :

* `results/figures/platform_distribution.png`
* `results/figures/rating_distribution.png`
* `results/figures/sentiment_over_time.png`
* `results/tables/summary_statistics.csv`

### 5.2 Manual Validation

```python
# Manually check 10 random summaries
import json
import random

with open('data/results/analysis_results.json', 'r') as f:
    results = json.load(f)

sample = random.choice(results)
print(sample['summary'])
# Verify: Does summary match the reviews in that batch?
```

---

## 📝 STEP 6: Paper Writing (Hour 12-24)

### 6.1 Materials & Methods

Use the template from "Research Paper Section Templates" artifact.

 **Fill in** :

* Actual review counts (from your `reviews_clean.csv`)
* Specific products you collected
* Processing times (from logs)
* Cost: $0 (all local)

 **Word count target** : 2000-2500 words

### 6.2 Results & Discussion

 **Include** :

1. **Table 1** : Data collection summary

* Trustpilot: X reviews, Y% retention
* Yelp: X reviews, Y% retention
* Google: X reviews, Y% retention

1. **Table 2** : Preprocessing impact

* Initial: 180 reviews
* After dedup: X reviews
* After cleaning: Y reviews
* Final: Z reviews

1. **Table 3** : LLM performance

* Average processing time per batch
* Sentiment distribution
* Top 5 themes across all reviews

1. **Figures** :

* Platform distribution bar chart
* Rating distribution histogram
* Sentiment scores box plot
* Theme frequency pie chart

 **Word count target** : 3000-3500 words

### 6.3 Conclusion

Use the template provided.

 **Emphasize** :

* Local LLM viability (no API costs!)
* Processing efficiency with RTX 3050
* Scalability potential
* Limitations (only 150 reviews, English only)

 **Word count target** : 500-700 words

---

## 🚨 TROUBLESHOOTING

### Problem: Ollama not connecting

```bash
# Solution 1: Restart Ollama
taskkill /F /IM ollama.exe  # Windows
ollama serve

# Solution 2: Check port
netstat -ano | findstr :11434
# Should show ollama.exe listening
```

### Problem: GPU out of memory

```bash
# Solution: Reduce batch size
# In config/config.yaml:
llm:
  batch_processing:
    batch_size: 25  # Reduce from 50 to 25
```

### Problem: Scraping returns 0 reviews

```bash
# Solution: Try different URLs or use manual data
# Edit src/data_collection/trustpilot_collector.py
# Update the URL to a different company with more reviews
```

### Problem: LLM generating gibberish

```bash
# Solution: Lower temperature
# In config/config.yaml:
llm:
  generation_params:
    temperature: 0.1  # Reduce from 0.3 to 0.1
```

---

## ✅ CHECKPOINT VERIFICATION

After each phase, verify:

 **After Collection** :

* [ ] `data/raw/*.csv` files exist
* [ ] At least 120 reviews collected
* [ ] No error logs in `logs/pipeline.log`

 **After Preprocessing** :

* [ ] `data/processed/reviews_clean.csv` exists
* [ ] At least 100 reviews remain
* [ ] No rows with empty `review_text`

 **After Analysis** :

* [ ] `data/results/analysis_results.json` exists
* [ ] All batches have `summary`, `sentiment`, `themes`
* [ ] Sentiment scores between -1 and +1

 **After Visualization** :

* [ ] At least 3 PNG files in `results/figures/`
* [ ] Charts are readable and labeled
* [ ] No blank/error images

---

## 📞 EMERGENCY CONTACTS

If stuck, check:

1. `logs/pipeline.log` - Full error details
2. Ollama logs: `C:\Users\<YourName>\.ollama\logs\` (Windows)
3. GPU temperature: Use MSI Afterburner or Task Manager

---

## 🎯 SUCCESS CRITERIA

By Hour 24, you should have:

✅ 100-170 cleaned reviews
✅ 3-4 analysis batches with summaries
✅ Sentiment scores for all batches
✅ 5-7 extracted themes
✅ 4-5 visualization charts
✅ Complete Materials & Methods section (2000+ words)
✅ Complete Results & Discussion section (3000+ words)
✅ Complete Conclusion section (500+ words)

 **Total Deliverables** : Working code + Clean dataset + Analysis results + 5500+ words of research paper

---

## ⏭️ NEXT STEPS (Post-24 Hours)

1. **Human Validation** : Manually verify 10% of summaries
2. **Enhance Figures** : Add error bars, statistical tests
3. **Refine Writing** : Proofread, add citations, format tables
4. **Supplementary Materials** : Include sample reviews, full prompt templates
5. **Code Repository** : Push to GitHub with README

---

**Good luck! You've got this! 🚀**

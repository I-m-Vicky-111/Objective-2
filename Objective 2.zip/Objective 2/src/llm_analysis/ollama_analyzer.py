# src/llm_analysis/ollama_analyzer.py
"""
Ollama LLM Analyzer for Local Model Inference
Supports multi-model setup: separate models for summarization, sentiment, and themes
Optimized for cloud-based Ollama models (qwen3-v1, gpt-oss, kimi-k2)
"""

import requests
import json
import logging
from typing import List, Dict, Union
import time
import yaml
from pathlib import Path

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class OllamaAnalyzer:
    """
    LLM analyzer using local Ollama models with multi-model support
    Different models for: summarization, sentiment analysis, and theme extraction
    """
    
    def __init__(self, 
                 config_path: str = "config/config.yaml",
                 model_name: str = None,  # Legacy support
                 base_url: str = "http://localhost:11434",
                 temperature: float = 0.3,
                 max_tokens: int = 500):
        """
        Initialize Ollama analyzer with multi-model configuration
        
        Args:
            config_path: Path to config.yaml file
            model_name: (Legacy) Single model name (overrides config)
            base_url: Ollama API endpoint
            temperature: Generation temperature (0.0-1.0)
            max_tokens: Maximum tokens to generate
        """
        # Load configuration
        self.config = self._load_config(config_path)
        
        # Set models from config or use legacy single model
        if model_name:
            # Legacy mode: use same model for all tasks
            self.model_summarization = model_name
            self.model_sentiment = model_name
            self.model_themes = model_name
            logger.info(f"Using single model for all tasks: {model_name}")
        else:
            # Multi-model mode from config
            self.model_summarization = self.config['llm']['models']['summarization']['name']
            self.model_sentiment = self.config['llm']['models']['sentiment']['name']
            self.model_themes = self.config['llm']['models']['theme_extraction']['name']
            logger.info(f"Multi-model setup:")
            logger.info(f"  - Summarization: {self.model_summarization}")
            logger.info(f"  - Sentiment: {self.model_sentiment}")
            logger.info(f"  - Themes: {self.model_themes}")
        
        # Server settings
        self.base_url = self.config.get('llm', {}).get('server', {}).get('base_url', base_url)
        self.api_endpoint = f"{self.base_url}/api/generate"
        
        # Generation parameters
        gen_params = self.config.get('llm', {}).get('generation_params', {})
        self.temperature = gen_params.get('temperature', temperature)
        self.max_tokens = gen_params.get('max_tokens', max_tokens)
        self.top_p = gen_params.get('top_p', 0.9)
        self.repeat_penalty = gen_params.get('repeat_penalty', 1.1)
    
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file"""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            logger.warning(f"Config file not found at {config_path}, using defaults")
            return self._default_config()
        except Exception as e:
            logger.error(f"Error loading config: {e}")
            return self._default_config()
    
    def _default_config(self) -> dict:
        """Default configuration if config file not found"""
        return {
            'llm': {
                'models': {
                    'summarization': {'name': 'llama3.2:3b-instruct-q4_0'},
                    'sentiment': {'name': 'llama3.2:3b-instruct-q4_0'},
                    'theme_extraction': {'name': 'llama3.2:3b-instruct-q4_0'}
                },
                'server': {'base_url': 'http://localhost:11434'},
                'generation_params': {
                    'temperature': 0.3,
                    'max_tokens': 500,
                    'top_p': 0.9,
                    'repeat_penalty': 1.1
                }
            }
        }
    
    def test_connection(self, test_all_models: bool = True) -> bool:
        """
        Test if Ollama is running and models are available
        
        Args:
            test_all_models: If True, test all 3 models. If False, just check server.
        """
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get('models', [])
                model_names = [m['name'] for m in models]
                
                if test_all_models:
                    # Check all three models
                    models_to_check = [
                        self.model_summarization,
                        self.model_sentiment,
                        self.model_themes
                    ]
                    
                    missing_models = []
                    for model in set(models_to_check):  # Use set to avoid duplicates
                        if model not in model_names:
                            missing_models.append(model)
                    
                    if missing_models:
                        logger.error(f"Missing models: {missing_models}")
                        logger.info(f"Available models: {model_names}")
                        logger.info(f"To install missing models:")
                        for model in missing_models:
                            logger.info(f"  ollama pull {model}")
                        return False
                    else:
                        logger.info(f"✓ Connected to Ollama. All models available.")
                        return True
                else:
                    logger.info(f"✓ Connected to Ollama server.")
                    return True
            else:
                logger.error("Ollama server not responding")
                return False
        except requests.exceptions.ConnectionError:
            logger.error("Cannot connect to Ollama. Please start it: 'ollama serve'")
            return False
        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return False
    
    def _generate(self, prompt: str, system: str = None, model_name: str = None) -> str:
        """
        Generate text using Ollama model
        
        Args:
            prompt: User prompt
            system: System instruction (optional)
            model_name: Specific model to use (if None, uses default)
            
        Returns:
            Generated text
        """
        if model_name is None:
            model_name = self.model_summarization  # Default fallback
        
        payload = {
            "model": model_name,
            "prompt": prompt,
            "system": system or "You are a helpful AI assistant.",
            "temperature": self.temperature,
            "stream": False,
            "options": {
                "num_predict": self.max_tokens,
                "top_p": self.top_p,
                "repeat_penalty": self.repeat_penalty
            }
        }
        
        try:
            logger.debug(f"Generating with model: {model_name}")
            response = requests.post(
                self.api_endpoint,
                json=payload,
                timeout=300  # 5 minutes for cloud models
            )
            response.raise_for_status()
            
            result = response.json()
            return result.get('response', '').strip()
            
        except requests.exceptions.Timeout:
            logger.error(f"Request timeout for model {model_name}. Model inference took too long.")
            return ""
        except Exception as e:
            logger.error(f"Generation error with {model_name}: {e}")
            return ""
    
    # ============ SUMMARIZATION ============
    
    def summarize(self, reviews: List[str], product_name: str = "the product") -> str:
        """
        Generate summary from list of reviews using summarization model
        
        Args:
            reviews: List of review texts
            product_name: Product/service name
            
        Returns:
            Summary text
        """
        logger.info(f"Generating summary for {len(reviews)} reviews using {self.model_summarization}...")
        
        # Combine reviews (limit to avoid token overflow)
        combined_text = "\n\n".join(reviews[:50])  # Max 50 reviews per batch
        
        # Truncate if too long
        if len(combined_text) > 8000:
            combined_text = combined_text[:8000] + "..."
        
        system_prompt = "You are an expert customer feedback analyst."
        
        user_prompt = f"""Summarize the following {len(reviews)} customer reviews for {product_name}.

Create a concise 75-100 word summary that:
1. Highlights the top 3 positive aspects
2. Identifies the top 3 negative aspects
3. Notes overall customer consensus

IMPORTANT: Only include information explicitly stated in the reviews. Do not invent details.

Reviews:
{combined_text}

Format your response as:
SUMMARY: [overall summary in 2-3 sentences]
POSITIVES: [point 1], [point 2], [point 3]
NEGATIVES: [point 1], [point 2], [point 3]
"""
        
        start_time = time.time()
        summary = self._generate(user_prompt, system_prompt, model_name=self.model_summarization)
        duration = time.time() - start_time
        
        logger.info(f"✓ Summary generated in {duration:.2f}s")
        return summary
    
    # ============ SENTIMENT ANALYSIS ============
    
    def analyze_sentiment(self, text: str) -> Dict[str, Union[float, str]]:
        """
        Analyze sentiment of text using sentiment analysis model
        
        Args:
            text: Text to analyze (could be summary or single review)
            
        Returns:
            Dict with sentiment_score (-1 to +1), confidence, justification
        """
        logger.info(f"Analyzing sentiment using {self.model_sentiment}...")
        
        system_prompt = "You are a sentiment analysis expert."
        
        user_prompt = f"""Analyze the sentiment of this text.

Text: {text}

Provide a JSON response with:
1. sentiment_score: float between -1.0 (very negative) and +1.0 (very positive)
2. confidence: "low", "medium", or "high"
3. justification: one sentence explaining the score

Response format:
{{"sentiment_score": 0.0, "confidence": "medium", "justification": "explanation here"}}

IMPORTANT: Respond with ONLY the JSON object, no other text.
"""
        
        response = self._generate(user_prompt, system_prompt, model_name=self.model_sentiment)
        
        # Parse JSON response
        try:
            # Extract JSON from response (sometimes LLMs add extra text)
            if '{' in response and '}' in response:
                json_start = response.find('{')
                json_end = response.rfind('}') + 1
                json_str = response[json_start:json_end]
                sentiment = json.loads(json_str)
            else:
                # Fallback: manual parsing
                sentiment = self._parse_sentiment_fallback(response)
            
            logger.info(f"✓ Sentiment: {sentiment.get('sentiment_score', 'N/A')} ({sentiment.get('confidence', 'N/A')})")
            return sentiment
            
        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON sentiment. Using fallback.")
            return self._parse_sentiment_fallback(response)
    
    def _parse_sentiment_fallback(self, text: str) -> Dict:
        """Fallback sentiment parsing if JSON fails"""
        # Simple keyword-based fallback
        text_lower = text.lower()
        
        if 'positive' in text_lower and 'negative' not in text_lower:
            score = 0.7
        elif 'negative' in text_lower and 'positive' not in text_lower:
            score = -0.7
        elif 'neutral' in text_lower:
            score = 0.0
        else:
            score = 0.0
        
        return {
            'sentiment_score': score,
            'confidence': 'low',
            'justification': 'Parsed from unstructured response'
        }
    
    # ============ THEME EXTRACTION ============
    
    def extract_themes(self, reviews: List[str], product_name: str = "the product") -> List[Dict]:
        """
        Extract main themes from reviews using theme extraction model
        
        Args:
            reviews: List of review texts
            product_name: Product/service name
            
        Returns:
            List of theme dictionaries
        """
        logger.info(f"Extracting themes from {len(reviews)} reviews using {self.model_themes}...")
        
        # Combine reviews
        combined_text = "\n\n".join(reviews[:50])
        if len(combined_text) > 8000:
            combined_text = combined_text[:8000] + "..."
        
        system_prompt = "You are a business intelligence analyst."
        
        user_prompt = f"""Extract the main themes from these customer reviews for {product_name}.

Identify 5-7 themes that appear most frequently.

For each theme provide:
- Theme name (2-3 words)
- Brief description (one sentence)
- Sentiment: positive, negative, or mixed
- Frequency estimate (percentage of reviews mentioning it)

Reviews:
{combined_text}

Output as JSON array:
[{{"theme": "Product Quality", "description": "...", "sentiment": "positive", "frequency_pct": 45}}]

IMPORTANT: Respond with ONLY the JSON array, no other text.
"""
        
        response = self._generate(user_prompt, system_prompt, model_name=self.model_themes)
        
        # Parse JSON array
        try:
            if '[' in response and ']' in response:
                json_start = response.find('[')
                json_end = response.rfind(']') + 1
                json_str = response[json_start:json_end]
                themes = json.loads(json_str)
            else:
                themes = self._parse_themes_fallback(response)
            
            logger.info(f"✓ Extracted {len(themes)} themes")
            return themes
            
        except json.JSONDecodeError:
            logger.warning("Failed to parse JSON themes. Using fallback.")
            return self._parse_themes_fallback(response)
    
    def _parse_themes_fallback(self, text: str) -> List[Dict]:
        """Fallback theme extraction if JSON fails"""
        # Extract themes from unstructured text
        lines = text.split('\n')
        themes = []
        
        for line in lines:
            line = line.strip()
            if len(line) > 10 and any(char.isalpha() for char in line):
                # Basic theme extraction
                themes.append({
                    'theme': line[:50],
                    'description': line,
                    'sentiment': 'mixed',
                    'frequency_pct': 0
                })
        
        return themes[:7]  # Return max 7 themes
    
    # ============ BATCH PROCESSING ============
    
    def analyze_batch(self, reviews: List[str], product_name: str = "the product") -> Dict:
        """
        Complete analysis of a review batch using all three models
        
        Args:
            reviews: List of review texts
            product_name: Product name
            
        Returns:
            Dict with summary, sentiment, themes, model info
        """
        logger.info(f"\n{'='*60}")
        logger.info(f"Analyzing batch of {len(reviews)} reviews for {product_name}")
        logger.info(f"Multi-model setup:")
        logger.info(f"  Summarization: {self.model_summarization}")
        logger.info(f"  Sentiment: {self.model_sentiment}")
        logger.info(f"  Themes: {self.model_themes}")
        logger.info(f"{'='*60}\n")
        
        start_time = time.time()
        
        # 1. Summarization (using qwen3-v1:235b-cloud)
        summary = self.summarize(reviews, product_name)
        
        # 2. Sentiment (using gpt-oss:120b-cloud, based on summary)
        sentiment = self.analyze_sentiment(summary)
        
        # 3. Theme Extraction (using kimi-k2:1t-cloud, from original reviews)
        themes = self.extract_themes(reviews, product_name)
        
        duration = time.time() - start_time
        
        logger.info(f"\n✓ Batch analysis complete in {duration:.2f}s")
        
        return {
            'summary': summary,
            'sentiment': sentiment,
            'themes': themes,
            'processing_time': duration,
            'models_used': {
                'summarization': self.model_summarization,
                'sentiment': self.model_sentiment,
                'themes': self.model_themes
            },
            'review_count': len(reviews)
        }


# ============ TESTING ============

def test_ollama_analyzer():
    """Test function for Ollama analyzer with multi-model setup"""
    logger.info("Testing Ollama Analyzer with Multi-Model Setup...")
    
    # Initialize with config
    analyzer = OllamaAnalyzer(config_path="config/config.yaml")
    
    # Test connection
    if not analyzer.test_connection(test_all_models=True):
        logger.error("Cannot proceed without Ollama connection to all models")
        logger.info("\nMake sure you have pulled the models:")
        logger.info(f"  ollama pull {analyzer.model_summarization}")
        logger.info(f"  ollama pull {analyzer.model_sentiment}")
        logger.info(f"  ollama pull {analyzer.model_themes}")
        return
    
    # Sample reviews
    sample_reviews = [
        "Great product! The quality is excellent and delivery was fast. Would buy again.",
        "Disappointed with this purchase. The product broke after just 2 weeks of use.",
        "Average product. Nothing special but it works as expected for the price.",
        "Love it! Best purchase I've made this year. Highly recommend to everyone.",
        "Not worth the money. Customer service was unhelpful when I had issues."
    ]
    
    # Run analysis
    results = analyzer.analyze_batch(sample_reviews, "Sample Product")
    
    # Print results
    print("\n" + "="*80)
    print("ANALYSIS RESULTS (Multi-Model Setup)")
    print("="*80)
    print(f"\nMODELS USED:")
    print(json.dumps(results['models_used'], indent=2))
    print(f"\nSUMMARY:\n{results['summary']}")
    print(f"\nSENTIMENT:\n{json.dumps(results['sentiment'], indent=2)}")
    print(f"\nTHEMES:\n{json.dumps(results['themes'], indent=2)}")
    print(f"\nProcessing Time: {results['processing_time']:.2f}s")
    print(f"Review Count: {results['review_count']}")


if __name__ == "__main__":
    test_ollama_analyzer()
import requests

models_to_test = [
    "qwen2.5:3b-instruct",
    "llama3.2:1b", 
    "phi3:mini",
    "llama3.2:3b-instruct-q4_0"
]

for model in models_to_test:
    print(f"\n{'='*60}")
    print(f"Testing: {model}")
    print('='*60)
    
    payload = {
        "model": model,
        "prompt": "Say hello in one sentence.",
        "stream": False,
        "options": {"num_predict": 30}
    }
    
    try:
        resp = requests.post('http://127.0.0.1:11434/api/generate', 
                           json=payload, 
                           timeout=30)
        print(f'Status: {resp.status_code}')
        if resp.status_code == 200:
            response_text = resp.json().get("response", "")
            print(f'✓ SUCCESS: {response_text[:100]}')
        else:
            print(f'✗ FAILED: {resp.text[:150]}')
    except Exception as e:
        print(f'✗ EXCEPTION: {e}')

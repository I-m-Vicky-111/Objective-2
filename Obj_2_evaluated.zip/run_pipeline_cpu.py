"""
Run pipeline with Ollama forced to use CPU for local models.
This prevents GPU CUDA errors while keeping the model configuration.
"""
import os
import sys

# Force Ollama to use CPU instead of GPU to avoid CUDA errors
os.environ["OLLAMA_NUM_GPU"] = "0"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

# Now import and run the pipeline
import run_pipeline

if __name__ == "__main__":
    print("=" * 60)
    print("Running pipeline with CPU-only mode for local models")
    print("This avoids GPU CUDA errors with llama3.2 models")
    print("=" * 60)
    print()

    # The actual pipeline logic is in run_pipeline module
    # Just importing it will execute the main code

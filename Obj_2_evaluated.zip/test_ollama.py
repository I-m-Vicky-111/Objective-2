import requests
import json

# Test server
print("Testing Ollama server...")
resp = requests.get('http://127.0.0.1:11434/api/tags')
print(f'Server status: {resp.status_code}')

if resp.status_code == 200:
    models = resp.json()['models']
    print(f'Total models: {len(models)}')
    
    # Test llama3.2:latest
    print("\nTesting llama3.2:latest with short prompt...")
    test_payload = {
        "model": "llama3.2:latest",
        "prompt": "Say hello",
        "stream": False,
        "options": {
            "num_predict": 50
        }
    }
    
    try:
        resp = requests.post('http://127.0.0.1:11434/api/generate', 
                           json=test_payload, 
                           timeout=30)
        print(f'Response status: {resp.status_code}')
        if resp.status_code == 200:
            print(f'Response: {resp.json().get("response", "")[:100]}')
        else:
            print(f'Error: {resp.text[:200]}')
    except Exception as e:
        print(f'Exception: {e}')
    
    # Test with longer prompt (like the actual pipeline)
    print("\nTesting llama3.2:latest with longer prompt...")
    long_prompt = """
    You are an expert research analyst. Summarize the key points across the
    following customer reviews in 3-4 sentences. Focus on consensus insights,
    sentiment drivers, and grounded product evidence. Avoid hallucinations.

    Review ID: test_1
    Rating (1-5 norm): 0.80
    Text: Great product, really enjoyed using it. Highly recommended for anyone.
    
    Review ID: test_2
    Rating (1-5 norm): 0.60
    Text: Good but could be better. Some features are missing.
    """
    
    test_payload2 = {
        "model": "llama3.2:latest",
        "prompt": long_prompt,
        "stream": False,
        "options": {
            "temperature": 0.3,
            "top_p": 0.9,
            "repeat_penalty": 1.1,
            "num_predict": 500
        }
    }
    
    try:
        resp = requests.post('http://127.0.0.1:11434/api/generate', 
                           json=test_payload2, 
                           timeout=60)
        print(f'Response status: {resp.status_code}')
        if resp.status_code == 200:
            print(f'Response: {resp.json().get("response", "")[:200]}')
        else:
            print(f'Error: {resp.text[:500]}')
    except Exception as e:
        print(f'Exception: {e}')

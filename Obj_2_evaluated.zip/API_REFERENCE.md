# Feedbackverse Objective 2 - API Reference & Quick Operations

> **Quick reference card for daily operations**
> **Last Updated**: November 13, 2025

---

## Table of Contents
1. [30-Second Quick Start](#30-second-quick-start)
2. [Command Reference](#command-reference)
3. [File Paths Quick Access](#file-paths-quick-access)
4. [Configuration Quick Edit](#configuration-quick-edit)
5. [Troubleshooting Commands](#troubleshooting-commands)
6. [Python API Usage](#python-api-usage)
7. [Dashboard Navigation](#dashboard-navigation)
8. [Data Format Specifications](#data-format-specifications)

---

## 30-Second Quick Start

### Start Dashboard
```powershell
cd "J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2"
streamlit run streamlit_app.py
```
**URL**: http://localhost:8501

### Run Full Pipeline
```powershell
# Terminal 1: Start Ollama
ollama serve

# Terminal 2: Run analysis
cd "J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2"
.\.venv\Scripts\Activate.ps1
python run_pipeline.py
```

### Quick Test (10 reviews)
```powershell
python quick_test_analysis.py
```

---

## Command Reference

### Data Collection

```bash
# Generate synthetic test data
python scripts/seed_raw_data.py

# Scrape from Trustpilot
python scrape_url.py \
  --url "https://www.trustpilot.com/review/www.asus.com" \
  --limit 50 \
  --format csv

# Scrape from Yelp
python scrape_url.py \
  --url "https://www.yelp.com/biz/food-for-friends-brighton" \
  --limit 50 \
  --format json

# Scrape from Google Maps
python scrape_url.py \
  --url "https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6" \
  --limit 50 \
  --format both
```

### Analysis Pipeline

```bash
# Full pipeline (default config)
python run_pipeline.py

# With alternate model
python run_pipeline.py --alt-model

# Custom config
python run_pipeline.py --config config/custom.yaml

# Custom output path
python run_pipeline.py --results-out data/results/my_analysis.json

# Combined options
python run_pipeline.py \
  --config config/config_alt.yaml \
  --results-out data/results/analysis_alt.json
```

### Validation

```bash
# Generate human references (50 samples)
python scripts/seed_references.py

# Run validation
python validate.py

# Custom paths
python validate.py \
  --analysis data/results/analysis_results.json \
  --references data/validation/references.csv \
  --output data/results/validation_metrics.json \
  --config config/config.yaml
```

### Ablation Study

```bash
# Step 1: Run base model
python run_pipeline.py

# Step 2: Run alternate model
python run_pipeline.py \
  --alt-model \
  --results-out data/results/analysis_results_alt.json

# Step 3: Compare models
python scripts/compare_models.py \
  --base data/results/analysis_results.json \
  --alt data/results/analysis_results_alt.json \
  --output data/results/ablation_flag.json
```

### Testing

```bash
# Run all unit tests
pytest tests/

# Run specific test file
pytest tests/test_evaluation.py

# Run with verbose output
pytest -v tests/

# Run smoke checks
python smoke_checks.py

# Test Ollama connection
python -c "from src.llm_analysis.ollama_analyzer import OllamaAnalyzer; print(OllamaAnalyzer().test_connection())"
```

### Ollama Management

```bash
# Start Ollama server
ollama serve

# List available models
ollama list

# Pull a model
ollama pull llama3.2:1b
ollama pull llama3.2:3b-instruct
ollama pull qwen2.5:3b-instruct

# Test Ollama API
curl http://127.0.0.1:11434/api/tags

# Remove a model
ollama rm llama3.2:1b
```

---

## File Paths Quick Access

### Input Data

| Path | Description |
|------|-------------|
| `data/raw/*.csv` | Raw review CSVs (manual placement) |
| `data/scraped/*.csv` | Scraped reviews from URLs |
| `data/validation/references.csv` | Human reference labels (50 samples) |

### Processed Data

| Path | Description |
|------|-------------|
| `data/processed/reviews_clean.csv` | Cleaned and deduplicated reviews |
| `data/processed/reviews.sqlite` | SQLite database (table: `reviews`) |
| `data/logs/near_duplicates.csv` | Deduplication log |

### Analysis Outputs

| Path | Description |
|------|-------------|
| `data/results/analysis_results.json` | Main analysis output |
| `data/results/analysis_results_alt.json` | Alternate model analysis |
| `data/results/descriptive.json` | Corpus statistics |
| `data/results/telemetry.json` | GPU/RAM metrics |
| `data/results/weekly_sentiment.csv` | Weekly sentiment trends |
| `data/results/validation_metrics.json` | Human agreement metrics |
| `data/results/ablation_flag.json` | Model comparison results |

### Configuration

| Path | Description |
|------|-------------|
| `config/config.yaml` | Primary configuration |
| `config/config_alt.yaml` | Alternate model configuration |

---

## Configuration Quick Edit

### Switch Models

**Edit** `config/config.yaml`:

```yaml
llm:
  models:
    summarization:
      name: "llama3.2:1b"  # Change this
    sentiment:
      name: "llama3.2:1b"  # Change this
    themes:
      name: "llama3.2:1b"  # Change this
```

**Available models:**
- `llama3.2:1b` (fastest, low memory)
- `llama3.2:3b-instruct` (balanced)
- `qwen2.5:3b-instruct` (alternate for ablation)
- `heuristic` (rule-based fallback, no API calls)

### Adjust Batch Size

```yaml
pipeline:
  batch_size: 50  # Reduce to 10-20 for slower models
```

### Change Date Window

```yaml
data:
  collection_window:
    start: "2024-09-10"  # YYYY-MM-DD
    end: "2024-11-01"    # YYYY-MM-DD
```

### Adjust Grounding Thresholds

```yaml
grounding:
  thresholds:
    flag: 0.50   # Min similarity to flag weak evidence
    strong: 0.70 # Min similarity for strong evidence
```

### Change Sentiment Bins

```yaml
evaluation:
  sentiment_bin_edges: [-1.0, -0.6, -0.2, 0.2, 0.6, 1.0]
  # 5 bins: Very Negative | Negative | Neutral | Positive | Very Positive
```

---

## Troubleshooting Commands

### Check System Status

```bash
# Python version
python --version

# Pip packages
pip list | grep -E "(ollama|streamlit|pandas|torch|transformers)"

# Ollama status
curl http://127.0.0.1:11434/api/tags

# GPU status (if NVIDIA)
nvidia-smi

# Disk space
du -sh data/
```

### Fix Common Issues

#### Ollama Not Running

```bash
# Windows: Check if Ollama service is running
Get-Process | Where-Object {$_.ProcessName -like "*ollama*"}

# Start Ollama
ollama serve

# Verify
curl http://127.0.0.1:11434/api/tags
```

#### Streamlit Won't Start

```bash
# Kill existing processes
Get-Process | Where-Object {$_.ProcessName -like "*streamlit*"} | Stop-Process -Force

# Restart
streamlit run streamlit_app.py
```

#### Out of Memory

```bash
# Check memory usage
Get-Process python | Select-Object Name, @{Name="Memory(MB)";Expression={$_.WorkingSet / 1MB}}

# Solutions:
# 1. Reduce batch size in config.yaml
# 2. Use smaller model (llama3.2:1b instead of 3b)
# 3. Switch to heuristic mode (set all models to "heuristic")
```

#### Missing Dependencies

```bash
# Reinstall all dependencies
pip install -r requirements.txt --force-reinstall

# Install optional dependencies
pip install sentence-transformers torch rouge-score bert-score pynvml
```

#### Empty CSV Files in data/scraped/

```bash
# Remove empty files
Remove-Item data/scraped/*.csv -Include @(Get-ChildItem data/scraped/*.csv | Where-Object {$_.Length -eq 0})

# Or manually:
cd data/scraped
del google_*.csv  # Delete specific files
```

### Reset Everything

```bash
# Delete all outputs
Remove-Item data/processed/* -Recurse -Force
Remove-Item data/results/* -Recurse -Force
Remove-Item data/logs/* -Recurse -Force

# Re-run pipeline
python run_pipeline.py
```

---

## Python API Usage

### Import Modules

```python
from src.preprocessing.pipeline import preprocess
from src.llm_analysis.ollama_analyzer import OllamaAnalyzer
from src.grounding.semantic_grounding import SemanticGrounder, GroundingThresholds
from src.evaluation.human_agreement import (
    bin_scores, kappa_binned, mae_continuous,
    pearson_corr, anova_by_platform
)
```

### Preprocessing

```python
import pandas as pd
from src.preprocessing.pipeline import preprocess

# Run preprocessing
cleaned_df = preprocess("config/config.yaml")

# Access cleaned data
print(f"Loaded {len(cleaned_df)} reviews")
print(cleaned_df.columns)
```

### LLM Analysis

```python
from src.llm_analysis.ollama_analyzer import OllamaAnalyzer

# Initialize analyzer
analyzer = OllamaAnalyzer("config/config.yaml")

# Check connection
if analyzer.test_connection():
    print("Ollama connected!")

# Analyze a batch
reviews = [
    {
        "review_id": "123",
        "rating_norm": 4.5,
        "review_text": "Great product, fast shipping!"
    }
]

result = analyzer.analyze_batch(reviews, batch_index=0)

print(f"Summary: {result['summary']}")
print(f"Themes: {result['themes']}")
print(f"Sentiments: {result['sentiments']}")
```

### Grounding

```python
from src.grounding.semantic_grounding import SemanticGrounder, GroundingThresholds

# Initialize grounder
thresholds = GroundingThresholds(flag=0.5, strong=0.7)
grounder = SemanticGrounder(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    thresholds=thresholds
)

# Assess summary
summary = "The product has excellent battery life and design."
reviews = [
    "Battery lasts all day, very impressed!",
    "Design is sleek and modern.",
    "Shipping was fast."
]

grounding = grounder.assess(summary, reviews)

print(f"Strong evidence: {grounding['strong']}")
print(f"Weak sentences: {grounding['weak_indices']}")
```

### Validation Metrics

```python
from src.evaluation.human_agreement import (
    bin_scores, kappa_binned, mae_continuous,
    pearson_corr, anova_by_platform
)

human_scores = [0.8, -0.3, 0.5, -0.7, 0.2]
model_scores = [0.7, -0.2, 0.4, -0.8, 0.3]
platforms = ["google", "yelp", "google", "trustpilot", "yelp"]

# Binning
edges = [-1.0, -0.6, -0.2, 0.2, 0.6, 1.0]
bins = bin_scores(model_scores, edges)
print(f"Bins: {bins}")

# Agreement
kappa = kappa_binned(human_scores, model_scores, edges)
print(f"Cohen's κ: {kappa:.3f}")

# Error
mae = mae_continuous(human_scores, model_scores)
print(f"MAE: {mae:.3f}")

# Correlation
pearson = pearson_corr(human_scores, model_scores)
print(f"Pearson r: {pearson['r']:.3f}, p: {pearson['p']:.4f}")

# Platform differences
anova = anova_by_platform(model_scores, platforms)
print(f"ANOVA F: {anova['F']:.2f}, p: {anova['p']:.4f}")
```

### URL Scraper

```python
from src.data_collection.universal_scraper import UniversalScraper

# Initialize scraper
scraper = UniversalScraper()

# Scrape reviews
url = "https://www.trustpilot.com/review/www.asus.com"
reviews = scraper.scrape(url, limit=20)

print(f"Scraped {len(reviews)} reviews")
for review in reviews[:3]:
    print(f"- {review['reviewer_name']}: {review['rating']}/5")
```

---

## Dashboard Navigation

### Page Overview

| Page | URL Path | Purpose |
|------|----------|---------|
| **Home** | `/` | System status, quick stats |
| **Data Upload** | `/1_Data_Upload` | Upload CSVs, view loaded reviews |
| **LLM Analysis** | `/2_LLM_Analysis` | Test single review or batch |
| **Visualizations** | `/3_Visualizations` | Charts, trends, word clouds |
| **Results Dashboard** | `/4_Results_Dashboard` | View analysis outputs |
| **Settings** | `/5_Settings` | Test Ollama, view config |
| **URL Scraper** | `/7_URL_Scraper` | Scrape from URLs |

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl + R` | Reload page |
| `Ctrl + Shift + R` | Clear cache and reload |
| `Ctrl + Click` (on button) | Re-run without cache |

### Sidebar Widgets

- **Select Platform**: Filter by platform
- **Date Range**: Filter by review date
- **Show Raw Data**: Toggle CSV view

---

## Data Format Specifications

### Input CSV Format

**Required columns:**
```csv
platform,category,product_name,rating,review_text,review_date,reviewer_name,verified_purchase
```

**Example:**
```csv
platform,category,product_name,rating,review_text,review_date,reviewer_name,verified_purchase
trustpilot,electronics,iPhone 15 Pro,5,Excellent phone!,2024-10-15,John,true
yelp,hospitality,The French Laundry,4,Great food,2024-10-14,Jane,false
google,services,Local Plumber,3,Average,2024-10-13,Bob,true
```

### Reference CSV Format (for validation)

**Required columns:**
```csv
review_id,platform,ref_summary,human_sentiment,human_themes
```

**Example:**
```csv
review_id,platform,ref_summary,human_sentiment,human_themes
5361ab521bf82230d24cc30b96816bf8,trustpilot,iPhone feedback highlights battery.,0.538,battery;price;staff
3db3e325871aaef2400518302d3ffe85,trustpilot,Quality concerns noted.,-0.242,experience;battery;quality
```

### Analysis Results JSON Schema

```json
{
  "created_at": "2025-11-13T10:30:00Z",
  "config": "config/config.yaml",
  "models_requested": {
    "summarization": "llama3.2:1b",
    "sentiment": "llama3.2:1b",
    "themes": "llama3.2:1b"
  },
  "models_used": {
    "summarization": "llama3.2:1b",
    "themes": "llama3.2:1b",
    "sentiment": "llama3.2:1b"
  },
  "batch_size": 50,
  "batches": [
    {
      "batch_index": 0,
      "platform": "google",
      "review_ids": ["id1", "id2", "..."],
      "summary": "Overall positive reviews...",
      "themes": ["Quality", "Price", "Service"],
      "sentiments": [
        {"review_id": "id1", "sentiment": 0.7},
        {"review_id": "id2", "sentiment": -0.3}
      ],
      "grounding": {
        "strong": 2,
        "medium": 1,
        "weak": 0,
        "weak_indices": [],
        "method": "minilm"
      },
      "telemetry": {
        "avg_util_pct": 45.2,
        "avg_power_w": 120.5,
        "peak_vram_mb": 2048
      },
      "elapsed_s": 12.3
    }
  ],
  "telemetry_summary": {
    "elapsed_hours": 0.05,
    "avg_power_w": 118.3,
    "electricity_cost": 0.00071
  }
}
```

### Validation Metrics JSON Schema

```json
{
  "rouge1": 0.456,
  "rouge2": 0.289,
  "rougeL": 0.412,
  "bertscore_F1": 0.782,
  "kappa_binned": 0.714,
  "mae": 0.183,
  "pearson_r": 0.907,
  "pearson_p": 0.0001,
  "anova_F": 5.82,
  "anova_p": 0.004,
  "theme_precision": 0.68,
  "theme_recall": 0.62,
  "n": 50,
  "fallback_overlap": false
}
```

---

## Emergency Commands

### Kill All Python Processes

```powershell
Get-Process | Where-Object {$_.ProcessName -like "*python*"} | Stop-Process -Force
```

### Force Stop Streamlit

```powershell
Get-Process | Where-Object {$_.ProcessName -like "*streamlit*"} | Stop-Process -Force
```

### Clear Cache

```bash
# Clear Python cache
find . -type d -name "__pycache__" -exec rm -r {} +
find . -type f -name "*.pyc" -delete

# Clear Streamlit cache
rm -rf .streamlit/cache
```

### Fresh Start

```bash
# Deactivate environment
deactivate

# Reactivate
.\.venv\Scripts\Activate.ps1

# Reinstall dependencies
pip install -r requirements.txt

# Restart everything
ollama serve
streamlit run streamlit_app.py
```

---

## Performance Tips

### Speed Up Analysis

1. **Reduce batch size**: Edit `config.yaml` → `pipeline.batch_size: 10`
2. **Use smaller model**: Change to `llama3.2:1b`
3. **Disable grounding**: Comment out grounding in `run_pipeline.py`
4. **Use heuristic mode**: Set all models to `"heuristic"` in config

### Reduce Memory Usage

1. **Use 1B models**: `llama3.2:1b` uses ~12 GB RAM
2. **Lower batch size**: Smaller batches = less memory
3. **Disable telemetry**: Saves ~500 MB
4. **Close other applications**: Free up RAM

### Optimize for Accuracy

1. **Use 3B models**: Better quality, slower
2. **Increase batch size**: More context for LLM
3. **Enable grounding**: Validates outputs
4. **Lower temperature**: `temperature: 0.1` for more deterministic outputs

---

## Quick Reference Cards

### 5-Minute Demo Script

1. **Home** (30s) - Show green checkmarks
2. **Data Upload** (30s) - "180 reviews, 3 platforms"
3. **Single Review Test** (90s) - Live sentiment analysis
4. **Visualizations** (90s) - Show 3 charts
5. **Results** (60s) - Expand batch summary
6. **Wrap-up** (30s) - "Zero API costs, all local"

### Research Paper Metrics

- **Models**: 3 specialized LLMs (llama3.2)
- **Cost**: $0 (all local inference)
- **Processing**: ~30-40s per 50-review batch
- **Reviews**: 180 test reviews
- **Platforms**: Trustpilot, Yelp, Google
- **Outputs**: Summaries + Sentiment + Themes

### Files You Need

| When | Files Needed |
|------|--------------|
| **Running pipeline** | `config/config.yaml`, `data/raw/*.csv` |
| **Validation** | `data/validation/references.csv` |
| **Ablation** | `config/config_alt.yaml` |
| **Scraping** | URLs only (no files needed) |
| **Dashboard** | `streamlit_app.py`, `pages/*.py` |

---

**For detailed setup instructions, see [PROJECT_GUIDE.md](PROJECT_GUIDE.md)**
**For metric evidence, see [EVALUATION_EVIDENCE.md](EVALUATION_EVIDENCE.md)**
**For development history, see [DEVELOPMENT_LOG.md](DEVELOPMENT_LOG.md)**

---

**End of API Reference**

# Feedbackverse Objective 2 - Complete Project Guide

> **Last Updated**: November 13, 2025
> **Status**: Production Ready ✅

---

## Table of Contents
1. [Overview](#overview)
2. [Installation & Setup](#installation--setup)
3. [System Architecture](#system-architecture)
4. [Data Flow](#data-flow)
5. [Configuration](#configuration)
6. [Running the Pipeline](#running-the-pipeline)
7. [URL Scraper Guide](#url-scraper-guide)
8. [Streamlit Dashboard](#streamlit-dashboard)
9. [File Structure](#file-structure)
10. [Troubleshooting](#troubleshooting)

---

## Overview

This repository hosts the **Objective 2 analysis stack** for multi-platform review analysis:
- ✅ Preprocessing (deduplication, normalization, filtering)
- ✅ Local LLM analysis (summarization, sentiment, themes via Ollama)
- ✅ Semantic grounding (sentence-level validation)
- ✅ Telemetry logging (GPU/RAM monitoring)
- ✅ Validation metrics (human agreement, statistical tests)
- ✅ Ablation tooling (cross-model comparison)
- ✅ Universal URL scraper (Trustpilot, Yelp, Google Maps)
- ✅ Interactive Streamlit dashboard

The pipeline ingests multi-platform review data, cleans it, and produces auditable JSON/CSV artifacts under `data/results/`.

---

## Installation & Setup

### Prerequisites
- Python 3.11+
- Ollama (for local LLM inference)
- NVIDIA GPU with drivers (optional, for telemetry)

### Step 1: Clone and Setup Environment

```bash
cd "J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2"

# Create virtual environment (if not exists)
python -m venv .venv

# Activate environment
.\.venv\Scripts\Activate.ps1  # PowerShell
# or
.venv\Scripts\activate  # CMD
```

### Step 2: Install Dependencies

```bash
# Core dependencies
pip install -r requirements.txt

# Optional: Enhanced features
pip install sentence-transformers torch rouge-score bert-score pynvml
```

### Step 3: Setup Ollama

```bash
# Start Ollama server
ollama serve

# Pull recommended models (in separate terminal)
ollama pull llama3.2:1b
ollama pull llama3.2:3b-instruct
ollama pull qwen2.5:3b-instruct

# Verify installation
curl http://127.0.0.1:11434/api/tags
```

---

## System Architecture

### Big Picture

```
data/raw/*.csv ──► Preprocessing ──► Cleaned corpus
                     (dedup + filters + SQLite)
                             │
                             ▼
                    run_pipeline.py
                             │
            ┌────────────────┼────────────────┐
            │                │                │
       Summaries       Sentiments         Themes
     (LLM batch 1)    (LLM batch 2)   (LLM batch 3)
            │                │                │
            └────────────────┴────────────────┘
                             │
              Grounding + Telemetry + Drift Analysis
                             │
                             ▼
          data/results/{analysis, telemetry, descriptive, weekly_sentiment}.*
```

### Key Components

| Component | Path | Purpose |
|-----------|------|---------|
| **Preprocessing** | `src/preprocessing/pipeline.py` | Dedup, filter spam, normalize ratings, detect language |
| **LLM Analysis** | `src/llm_analysis/ollama_analyzer.py` | Batch summarization, sentiment scoring, theme extraction |
| **Grounding** | `src/grounding/semantic_grounding.py` | Validate summaries against source reviews (MiniLM embeddings) |
| **Telemetry** | `src/telemetry/gpu_logger.py` | GPU/RAM monitoring during batch processing |
| **Validation** | `src/evaluation/human_agreement.py` | Cohen's κ, MAE, Pearson r, ANOVA |
| **URL Scraper** | `src/data_collection/universal_scraper.py` | Multi-platform review scraper |
| **Dashboard** | `streamlit_app.py` | Interactive UI for all features |

---

## Data Flow

### 1. Raw Data Input

Place CSV files in `data/raw/` with these columns:
```csv
platform,category,product_name,rating,review_text,review_date,reviewer_name,verified_purchase
```

Or use the URL scraper:
```bash
python scrape_url.py --url "https://www.trustpilot.com/review/www.asus.com" --limit 50
```

### 2. Preprocessing

```bash
python run_pipeline.py
```

**What happens:**
1. Loads all CSVs from `data/raw/` and `data/scraped/`
2. Removes exact duplicates (hash-based)
3. Removes near-duplicates (Levenshtein similarity ≥ 0.85)
4. Filters spam (URLs, promo codes, < 10 words)
5. Filters non-English reviews
6. Normalizes ratings to 1-5 scale
7. Applies date window filter (from config)

**Outputs:**
- `data/processed/reviews_clean.csv` - Cleaned reviews
- `data/processed/reviews.sqlite` - SQLite database
- `data/results/descriptive.json` - Corpus statistics
- `data/logs/near_duplicates.csv` - Deduplication log

### 3. LLM Analysis

**Batch Processing:**
- Reviews are chunked by platform (default: 50 per batch)
- Each batch gets:
  - Summary (3-4 sentences)
  - Per-review sentiment scores (-1 to +1)
  - Key themes (3-5 labels)

**Grounding:**
- Each summary sentence is validated against source reviews
- Uses MiniLM embeddings for semantic similarity
- Categorizes as strong/medium/weak evidence

**Output:**
- `data/results/analysis_results.json` - Complete analysis with all metadata

### 4. Validation

```bash
python validate.py --references data/validation/references.csv
```

**Metrics computed:**
- **ROUGE-1/2/L**: Summary overlap with human references
- **BERTScore F1**: Semantic similarity
- **Cohen's κ**: Agreement on binned sentiment (5 categories)
- **MAE**: Mean absolute error on continuous sentiment
- **Pearson r/p**: Correlation with human scores
- **ANOVA**: Cross-platform bias detection (F-statistic, p-value)
- **Theme precision/recall**: After synonym mapping

**Output:**
- `data/results/validation_metrics.json`

---

## Configuration

### Primary Config: `config/config.yaml`

```yaml
llm:
  server:
    base_url: "http://127.0.0.1:11434"
    timeout: 120
  models:
    summarization:
      name: "llama3.2:1b"  # or "llama3.2:3b-instruct"
    sentiment:
      name: "llama3.2:1b"
    themes:
      name: "llama3.2:1b"
    alt_small:
      name: "qwen2.5:3b-instruct"  # For ablation
  generation:
    temperature: 0.3
    top_p: 0.9
    repeat_penalty: 1.1
    tokens:
      summary_max: 500
      themes_max: 350

pipeline:
  batch_size: 50
  max_retries: 2
  delay_between_batches: 0

data:
  collection_window:
    start: "2024-09-10"
    end: "2024-11-01"

grounding:
  model: "sentence-transformers/all-MiniLM-L6-v2"
  thresholds:
    flag: 0.50
    strong: 0.70

evaluation:
  sentiment_bin_edges: [-1.0, -0.6, -0.2, 0.2, 0.6, 1.0]  # 5 bins
  electricity_cost_per_kwh: 0.12
  delta_sentiment_flag: 0.30
```

### Alternate Config: `config/config_alt.yaml`

Used for ablation studies with different models. Same structure as primary config.

---

## Running the Pipeline

### Full Pipeline (Recommended)

```bash
# Start Ollama (Terminal 1)
ollama serve

# Run pipeline (Terminal 2)
cd "J:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2"
.\.venv\Scripts\Activate.ps1
python run_pipeline.py
```

**Expected Output:**
```
Processing 180 reviews...
Batch 0: google (50 reviews) - 12.3s
Batch 1: yelp (50 reviews) - 11.8s
Batch 2: trustpilot (50 reviews) - 13.1s
...
Pipeline complete: 180 reviews in 45.2s
Results saved to data/results/analysis_results.json
```

### Validation Run

```bash
python validate.py \
  --analysis data/results/analysis_results.json \
  --references data/validation/references.csv \
  --output data/results/validation_metrics.json
```

### Ablation Study (Alternate Model)

```bash
# Run with alternate model
python run_pipeline.py --alt-model --results-out data/results/analysis_results_alt.json

# Compare models
python scripts/compare_models.py \
  --base data/results/analysis_results.json \
  --alt data/results/analysis_results_alt.json \
  --output data/results/ablation_flag.json
```

---

## URL Scraper Guide

### Overview

The universal scraper supports:
- ✅ **Trustpilot** (company pages)
- ✅ **Yelp** (business pages)
- ✅ **Google Maps** (location pages)

### Command Line Usage

```bash
# Basic usage
python scrape_url.py --url "YOUR_URL" --limit 20

# Trustpilot example
python scrape_url.py \
  --url "https://www.trustpilot.com/review/www.asus.com" \
  --limit 50 \
  --format csv

# Yelp example
python scrape_url.py \
  --url "https://www.yelp.com/biz/food-for-friends-brighton" \
  --limit 30 \
  --format json

# Google Maps example
python scrape_url.py \
  --url "https://maps.app.goo.gl/Fyjq1LtEM6JZEHMg6" \
  --limit 40 \
  --format both
```

### Output Location

- **CSV**: `data/scraped/{platform}_{identifier}_{timestamp}.csv`
- **JSON**: `data/scraped/{platform}_{identifier}_{timestamp}.json`

### Via Streamlit Dashboard

1. Start dashboard: `streamlit run streamlit_app.py`
2. Navigate to **"7_URL_Scraper"** page
3. Enter URL, select limit, click **"Scrape Reviews"**
4. Download results

---

## Streamlit Dashboard

### Starting the Dashboard

```bash
streamlit run streamlit_app.py
```

**URL**: http://localhost:8501

### Dashboard Pages

| Page | Features |
|------|----------|
| **🏠 Home** | System status, quick stats, navigation |
| **📤 Data Upload** | Upload CSVs, view loaded reviews |
| **🤖 LLM Analysis** | Test single review or batch analysis |
| **📊 Visualizations** | Platform distribution, sentiment trends, word clouds |
| **📈 Results Dashboard** | View all analysis results, expand batches |
| **⚙️ Settings** | Test Ollama connection, view config |
| **🔗 URL Scraper** | Scrape reviews from URLs |

### Testing the System

1. **Check Status** (Home page):
   - ✅ Ollama Connected
   - ✅ Data Loaded
   - ✅ Models Available

2. **Single Review Test** (LLM Analysis page):
   - Enter a sample review
   - Click "Analyze Review"
   - View sentiment, summary, themes

3. **View Results** (Results Dashboard):
   - Expand batch details
   - Check grounding scores
   - Review telemetry

---

## File Structure

```
j:\Research Paper Uncle\Feedbackverse\Codebase\Objective 2\
│
├── config/
│   ├── config.yaml              # Primary configuration
│   └── config_alt.yaml          # Alternate model config
│
├── data/
│   ├── raw/                     # Raw input CSVs
│   ├── scraped/                 # Scraped reviews
│   ├── processed/               # Cleaned data
│   │   ├── reviews_clean.csv
│   │   └── reviews.sqlite
│   ├── validation/              # Human references
│   │   └── references.csv
│   ├── results/                 # All outputs
│   │   ├── analysis_results.json
│   │   ├── validation_metrics.json
│   │   ├── descriptive.json
│   │   ├── telemetry.json
│   │   ├── weekly_sentiment.csv
│   │   └── ablation_flag.json
│   └── logs/
│       └── near_duplicates.csv
│
├── src/
│   ├── preprocessing/
│   │   └── pipeline.py          # Dedup, filter, normalize
│   ├── llm_analysis/
│   │   └── ollama_analyzer.py   # LLM batch processing
│   ├── grounding/
│   │   └── semantic_grounding.py # Embedding-based validation
│   ├── telemetry/
│   │   └── gpu_logger.py        # Hardware monitoring
│   ├── evaluation/
│   │   ├── human_agreement.py   # Statistical metrics
│   │   └── text_overlap.py      # ROUGE, BERTScore
│   ├── analysis/
│   │   └── drift.py             # Weekly sentiment trends
│   ├── data_collection/
│   │   ├── universal_scraper.py # Multi-platform scraper
│   │   ├── trustpilot_collector.py
│   │   ├── yelp_collector.py
│   │   └── google_maps_scraper.py
│   └── utils/
│       └── config_loader.py
│
├── scripts/
│   ├── seed_raw_data.py         # Generate synthetic reviews
│   ├── seed_references.py       # Sample human references
│   └── compare_models.py        # Ablation analysis
│
├── tests/
│   ├── test_preprocessing.py
│   ├── test_evaluation.py
│   ├── test_grounding.py
│   └── test_drift.py
│
├── pages/                       # Streamlit pages
│   ├── 1_📤_Data_Upload.py
│   ├── 2_🤖_LLM_Analysis.py
│   ├── 3_📊_Visualizations.py
│   ├── 4_📈_Results_Dashboard.py
│   ├── 5_⚙️_Settings.py
│   └── 7_🔗_URL_Scraper.py
│
├── run_pipeline.py              # Main orchestrator
├── validate.py                  # Validation metrics
├── scrape_url.py               # URL scraper CLI
├── streamlit_app.py            # Dashboard entry point
├── requirements.txt            # Dependencies
└── PROJECT_GUIDE.md            # This file

```

---

## Troubleshooting

### Issue: "No raw CSVs found"

**Solution:**
```bash
# Option 1: Generate synthetic data
python scripts/seed_raw_data.py

# Option 2: Add your own CSVs to data/raw/
# Ensure they have the required columns
```

### Issue: "Ollama server not reachable"

**Solution:**
```bash
# Start Ollama
ollama serve

# Verify it's running
curl http://127.0.0.1:11434/api/tags

# Check models are pulled
ollama list
```

### Issue: Validation shows "only 6 samples matched"

**Solution:**
```bash
# Regenerate references aligned with current analysis
python scripts/seed_references.py

# Then re-run validation
python validate.py
```

### Issue: "sentence-transformers" or "torch" missing

**Solution:**
```bash
pip install sentence-transformers torch

# Note: Grounding falls back to token overlap if unavailable
```

### Issue: Telemetry shows "avg_power_w: null"

**Solution:**
```bash
# Install NVML support
pip install pynvml

# Ensure NVIDIA drivers are installed
nvidia-smi

# Re-run pipeline
python run_pipeline.py
```

### Issue: Streamlit dashboard won't load

**Solution:**
```bash
# Kill existing Streamlit processes
Get-Process | Where-Object {$_.ProcessName -like "*streamlit*"} | Stop-Process

# Restart dashboard
streamlit run streamlit_app.py
```

### Issue: Empty CSV files in data/scraped/

**Explanation:** The scraper may have failed due to robots.txt restrictions or network issues. These files are safely ignored during preprocessing.

**Solution:**
```bash
# Remove empty files
Remove-Item data/scraped/*.csv -Filter {$_.Length -eq 0}

# Re-scrape with proper delay
python scrape_url.py --url "YOUR_URL" --limit 20
```

---

## CLI Cheat Sheet

```bash
# ====================
# SETUP
# ====================

# Install dependencies
pip install -r requirements.txt
pip install sentence-transformers torch rouge-score bert-score pynvml

# Start Ollama
ollama serve
ollama pull llama3.2:1b

# ====================
# DATA COLLECTION
# ====================

# Generate synthetic data
python scripts/seed_raw_data.py

# Scrape from URL
python scrape_url.py --url "YOUR_URL" --limit 50

# ====================
# ANALYSIS PIPELINE
# ====================

# Full pipeline
python run_pipeline.py

# With alternate model
python run_pipeline.py --alt-model

# Custom config
python run_pipeline.py --config config/custom.yaml

# ====================
# VALIDATION
# ====================

# Generate references
python scripts/seed_references.py

# Run validation
python validate.py

# Custom paths
python validate.py \
  --analysis data/results/analysis_results.json \
  --references data/validation/references.csv \
  --output data/results/validation_metrics.json

# ====================
# ABLATION
# ====================

# Compare models
python scripts/compare_models.py \
  --base data/results/analysis_results.json \
  --alt data/results/analysis_results_alt.json

# ====================
# TESTING
# ====================

# Run unit tests
pytest tests/

# Run smoke checks
python smoke_checks.py

# ====================
# DASHBOARD
# ====================

# Start Streamlit dashboard
streamlit run streamlit_app.py

# Kill Streamlit
Get-Process | Where-Object {$_.ProcessName -like "*streamlit*"} | Stop-Process
```

---

## Next Steps

1. **For Research**: See [EVALUATION_EVIDENCE.md](EVALUATION_EVIDENCE.md) for metric documentation
2. **For Quick Operations**: See [API_REFERENCE.md](API_REFERENCE.md) for command shortcuts
3. **For Development History**: See [DEVELOPMENT_LOG.md](DEVELOPMENT_LOG.md) for changelog

---

**End of Project Guide**

"""
Comprehensive diagnostic script to check all system components,
identify potential issues, and validate the pipeline.
"""

import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DiagnosticChecker:
    """Comprehensive system diagnostic checker."""

    def __init__(self, config_path: str = "config/config_alt.yaml"):
        self.config_path = config_path
        self.issues = []
        self.warnings = []
        self.successes = []

    def check_all(self) -> Dict:
        """Run all diagnostic checks."""
        logger.info("=" * 70)
        logger.info("STARTING COMPREHENSIVE SYSTEM DIAGNOSTIC")
        logger.info("=" * 70)

        self.check_config()
        self.check_directories()
        self.check_dependencies()
        self.check_ollama_server()
        self.check_models()
        self.check_data_files()
        self.check_preprocessing()
        self.check_llm_analysis()
        self.check_grounding()

        self.print_summary()

        return {
            "issues": self.issues,
            "warnings": self.warnings,
            "successes": self.successes
        }

    def check_config(self):
        """Check configuration file."""
        logger.info("\n[1/9] Checking Configuration...")
        try:
            config_path = Path(self.config_path)
            if not config_path.exists():
                self.issues.append(f"Config file not found: {self.config_path}")
                return

            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)

            # Check required sections
            required_sections = ['llm', 'pipeline', 'data', 'grounding', 'evaluation']
            for section in required_sections:
                if section not in config:
                    self.issues.append(f"Missing config section: {section}")
                else:
                    self.successes.append(f"Config section '{section}' found")

            # Check LLM config
            if 'llm' in config:
                llm_config = config['llm']
                if 'server' not in llm_config:
                    self.issues.append("Missing 'server' in llm config")
                else:
                    base_url = llm_config['server'].get('base_url', 'http://127.0.0.1:11434')
                    timeout = llm_config['server'].get('timeout', 180)
                    self.successes.append(f"LLM server URL: {base_url}")
                    self.successes.append(f"LLM timeout: {timeout}s")

                    if timeout < 120:
                        self.warnings.append(f"Timeout {timeout}s may be too short for large batches")

                # Check models
                if 'models' in llm_config:
                    models = llm_config['models']
                    for stage in ['summarization', 'sentiment', 'themes']:
                        if stage in models and 'name' in models[stage]:
                            model_name = models[stage]['name']
                            self.successes.append(f"{stage} model: {model_name}")
                        else:
                            self.warnings.append(f"Missing model config for {stage}")

        except Exception as e:
            self.issues.append(f"Error reading config: {str(e)}")

    def check_directories(self):
        """Check required directories."""
        logger.info("\n[2/9] Checking Directory Structure...")

        required_dirs = [
            "data/raw",
            "data/scraped",
            "data/processed",
            "data/results",
            "data/logs",
            "src/llm_analysis",
            "src/preprocessing",
            "src/grounding",
            "tests"
        ]

        for dir_path in required_dirs:
            path = Path(dir_path)
            if path.exists():
                self.successes.append(f"Directory exists: {dir_path}")
            else:
                self.warnings.append(f"Directory missing: {dir_path} (will be created if needed)")

    def check_dependencies(self):
        """Check Python dependencies."""
        logger.info("\n[3/9] Checking Python Dependencies...")

        required_packages = [
            'pandas',
            'numpy',
            'yaml',
            'requests',
            'langdetect',
            'sentence_transformers',
            'torch',
        ]

        optional_packages = [
            'rapidfuzz',
        ]

        for package in required_packages:
            try:
                __import__(package)
                self.successes.append(f"Required package installed: {package}")
            except ImportError:
                self.issues.append(f"Required package missing: {package}")

        for package in optional_packages:
            try:
                __import__(package)
                self.successes.append(f"Optional package installed: {package}")
            except ImportError:
                self.warnings.append(f"Optional package missing: {package} (fallback available)")

    def check_ollama_server(self):
        """Check Ollama server connectivity."""
        logger.info("\n[4/9] Checking Ollama Server...")

        try:
            import requests
            response = requests.get("http://127.0.0.1:11434/api/tags", timeout=5)
            if response.status_code == 200:
                self.successes.append("Ollama server is running and accessible")

                # Check available models
                data = response.json()
                if 'models' in data:
                    models = [m['name'] for m in data['models']]
                    self.successes.append(f"Available models: {', '.join(models)}")

                    # Check if configured model is available
                    try:
                        with open(self.config_path, 'r') as f:
                            config = yaml.safe_load(f)
                        required_model = config['llm']['models']['sentiment']['name']

                        if any(required_model in model for model in models):
                            self.successes.append(f"Required model available: {required_model}")
                        else:
                            self.warnings.append(f"Required model not found: {required_model}")
                            self.warnings.append(f"Run: ollama pull {required_model}")
                    except:
                        pass
            else:
                self.issues.append(f"Ollama server responded with status {response.status_code}")
        except requests.ConnectionError:
            self.issues.append("Cannot connect to Ollama server at http://127.0.0.1:11434")
            self.issues.append("Start server with: ollama serve")
        except Exception as e:
            self.issues.append(f"Error checking Ollama server: {str(e)}")

    def check_models(self):
        """Check model configuration and availability."""
        logger.info("\n[5/9] Checking Model Configuration...")

        try:
            from src.llm_analysis.ollama_analyzer import OllamaAnalyzer

            # Try to initialize analyzer
            try:
                analyzer = OllamaAnalyzer(self.config_path)
                self.successes.append("OllamaAnalyzer initialized successfully")

                # Check if connection test works
                if analyzer.test_connection():
                    self.successes.append("Model connection test passed")
                else:
                    self.warnings.append("Model connection test failed (may fall back to heuristic)")

            except RuntimeError as e:
                self.warnings.append(f"Analyzer initialization warning: {str(e)}")
            except Exception as e:
                self.issues.append(f"Error initializing analyzer: {str(e)}")

        except ImportError as e:
            self.issues.append(f"Cannot import OllamaAnalyzer: {str(e)}")

    def check_data_files(self):
        """Check for raw data files."""
        logger.info("\n[6/9] Checking Data Files...")

        raw_dirs = ["data/raw", "data/scraped"]
        found_files = []

        for dir_path in raw_dirs:
            path = Path(dir_path)
            if path.exists():
                csv_files = list(path.glob("*.csv"))
                found_files.extend(csv_files)

        if found_files:
            self.successes.append(f"Found {len(found_files)} raw CSV file(s)")
            for file in found_files:
                self.successes.append(f"  - {file.name}")
        else:
            self.warnings.append("No raw CSV files found in data/raw or data/scraped")
            self.warnings.append("Add review data files to run the pipeline")

    def check_preprocessing(self):
        """Check preprocessing functionality."""
        logger.info("\n[7/9] Checking Preprocessing...")

        try:
            from src.preprocessing.pipeline import normalize_rating, _is_spam, _is_english

            # Test rating normalization
            test_ratings = [5, "4/5", "80%", "8 out of 10"]
            for rating in test_ratings:
                try:
                    result = normalize_rating(rating)
                    if 1.0 <= result <= 5.0:
                        self.successes.append(f"Rating normalization OK: {rating} -> {result:.2f}")
                    else:
                        self.warnings.append(f"Rating out of range: {rating} -> {result}")
                except Exception as e:
                    self.issues.append(f"Rating normalization failed for {rating}: {str(e)}")

            # Test spam detection
            spam_text = "Check out http://example.com"
            if _is_spam(spam_text):
                self.successes.append("Spam detection working correctly")
            else:
                self.warnings.append("Spam detection may have issues")

            # Test language detection
            english_text = "This is a test review"
            if _is_english(english_text):
                self.successes.append("Language detection working correctly")
            else:
                self.warnings.append("Language detection may have issues")

        except Exception as e:
            self.issues.append(f"Error checking preprocessing: {str(e)}")

    def check_llm_analysis(self):
        """Check LLM analysis functionality."""
        logger.info("\n[8/9] Checking LLM Analysis...")

        try:
            from src.llm_analysis.ollama_analyzer import OllamaAnalyzer

            try:
                analyzer = OllamaAnalyzer(self.config_path)

                # Test JSON extraction
                test_jsons = [
                    '{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}',
                    '```json\n{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}\n```',
                    'Here is the result: {"sentiments": [{"review_id": "1", "sentiment": 0.5}]}',
                ]

                for test_json in test_jsons:
                    try:
                        result = analyzer._extract_json_from_text(test_json)
                        if isinstance(result, dict):
                            self.successes.append("JSON extraction working for various formats")
                            break
                    except:
                        pass
                else:
                    self.warnings.append("JSON extraction may have issues with some formats")

                self.successes.append("LLM analysis module is functional")

            except RuntimeError as e:
                self.warnings.append(f"LLM analyzer warning: {str(e)}")

        except Exception as e:
            self.issues.append(f"Error checking LLM analysis: {str(e)}")

    def check_grounding(self):
        """Check grounding functionality."""
        logger.info("\n[9/9] Checking Semantic Grounding...")

        try:
            from src.grounding.semantic_grounding import SemanticGrounder, GroundingThresholds

            thresholds = GroundingThresholds(flag=0.5, strong=0.7)
            grounder = SemanticGrounder(thresholds=thresholds)

            if grounder.available:
                self.successes.append("Semantic grounding model available")
                self.successes.append(f"Using device: {grounder.device}")
            else:
                self.warnings.append("Semantic grounding model unavailable (will use heuristic)")

            # Test basic functionality
            try:
                result = grounder.assess("Test summary.", ["Test review."])
                if isinstance(result, dict) and 'weak' in result:
                    self.successes.append("Grounding assessment working correctly")
            except Exception as e:
                self.warnings.append(f"Grounding test failed: {str(e)}")

        except Exception as e:
            self.issues.append(f"Error checking grounding: {str(e)}")

    def print_summary(self):
        """Print diagnostic summary."""
        logger.info("\n" + "=" * 70)
        logger.info("DIAGNOSTIC SUMMARY")
        logger.info("=" * 70)

        if self.successes:
            logger.info(f"\n✓ SUCCESSES ({len(self.successes)}):")
            for success in self.successes:
                logger.info(f"  ✓ {success}")

        if self.warnings:
            logger.info(f"\n⚠ WARNINGS ({len(self.warnings)}):")
            for warning in self.warnings:
                logger.warning(f"  ⚠ {warning}")

        if self.issues:
            logger.info(f"\n✗ ISSUES ({len(self.issues)}):")
            for issue in self.issues:
                logger.error(f"  ✗ {issue}")

        logger.info("\n" + "=" * 70)
        if not self.issues:
            logger.info("STATUS: READY TO RUN ✓")
        elif len(self.issues) <= 2 and len(self.warnings) <= 3:
            logger.info("STATUS: MOSTLY READY (minor issues) ⚠")
        else:
            logger.info("STATUS: NEEDS ATTENTION ✗")
        logger.info("=" * 70 + "\n")


def main():
    """Run diagnostic checks."""
    checker = DiagnosticChecker()
    results = checker.check_all()

    # Save results to file
    output_path = Path("data/logs/diagnostic_results.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w') as f:
        json.dump(results, f, indent=2)

    logger.info(f"Detailed results saved to: {output_path}")

    # Return exit code based on issues
    return 0 if not results['issues'] else 1


if __name__ == "__main__":
    sys.exit(main())

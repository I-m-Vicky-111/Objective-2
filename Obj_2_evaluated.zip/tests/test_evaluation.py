import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.evaluation.human_agreement import bin_scores  # noqa: E402


def test_bin_scores_respects_edges():
    edges = [-1.0, -0.5, 0.0, 0.5, 1.0]
    scores = [-0.8, -0.2, 0.3, 0.9]
    bins = bin_scores(scores, edges)
    assert bins == [0, 1, 2, 3]

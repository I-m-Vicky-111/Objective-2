import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from src.analysis.drift import week_start  # noqa: E402


def test_week_start_returns_monday():
    dt = datetime(2024, 10, 16)  # Wednesday
    assert week_start(dt).date().isoformat() == "2024-10-14"

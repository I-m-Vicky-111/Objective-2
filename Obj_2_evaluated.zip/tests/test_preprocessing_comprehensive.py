"""
Comprehensive tests for preprocessing pipeline including deduplication,
normalization, and filtering.
"""

import unittest
import pandas as pd
import numpy as np
import sys
from pathlib import Path
from datetime import datetime

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.preprocessing.pipeline import (
    normalize_rating,
    _normalize_text,
    _hash_text,
    _is_spam,
    _is_english,
    remove_near_duplicates,
    _window_filter,
)


class TestRatingNormalization(unittest.TestCase):
    """Test rating normalization across different formats."""

    def test_normalize_standard_5_scale(self):
        """Test normalization of standard 1-5 ratings."""
        self.assertAlmostEqual(normalize_rating(5), 5.0)
        self.assertAlmostEqual(normalize_rating(1), 1.0)
        self.assertAlmostEqual(normalize_rating(3), 3.0)

    def test_normalize_ratio_format(self):
        """Test normalization of ratio format (e.g., 4/5)."""
        self.assertAlmostEqual(normalize_rating("4/5"), 4.0)
        self.assertAlmostEqual(normalize_rating("5/5"), 5.0)
        self.assertAlmostEqual(normalize_rating("3/5"), 3.0)

    def test_normalize_10_scale(self):
        """Test normalization of 10-point scale."""
        self.assertAlmostEqual(normalize_rating("8 out of 10"), 4.2, places=1)
        self.assertAlmostEqual(normalize_rating("10"), 5.0)
        self.assertAlmostEqual(normalize_rating("5"), 3.0)

    def test_normalize_percentage(self):
        """Test normalization of percentage ratings."""
        self.assertAlmostEqual(normalize_rating("80%"), 4.2, places=1)
        self.assertAlmostEqual(normalize_rating("100%"), 5.0)
        self.assertAlmostEqual(normalize_rating("0%"), 1.0)

    def test_normalize_invalid_returns_nan(self):
        """Test that invalid ratings return NaN."""
        self.assertTrue(np.isnan(normalize_rating(None)))
        self.assertTrue(np.isnan(normalize_rating("")))
        self.assertTrue(np.isnan(normalize_rating("invalid")))

    def test_normalize_out_of_range(self):
        """Test that out-of-range values are handled correctly."""
        result = normalize_rating(150)
        # 150/100 = 1.5, then 1.0 + 4.0 * 1.5 = 7.0, but should be clamped
        self.assertTrue(1.0 <= result <= 5.0 or np.isnan(result))


class TestTextNormalization(unittest.TestCase):
    """Test text normalization and hashing."""

    def test_normalize_text_removes_extra_spaces(self):
        """Test that extra whitespace is normalized."""
        text = "This   has    multiple     spaces"
        normalized = _normalize_text(text)
        self.assertEqual(normalized, "this has multiple spaces")

    def test_normalize_text_lowercase(self):
        """Test that text is converted to lowercase."""
        text = "MiXeD CaSe TeXt"
        normalized = _normalize_text(text)
        self.assertEqual(normalized, "mixed case text")

    def test_hash_text_consistent(self):
        """Test that same text produces same hash."""
        text = "Test review text"
        hash1 = _hash_text(text)
        hash2 = _hash_text(text)
        self.assertEqual(hash1, hash2)

    def test_hash_text_different_for_different_text(self):
        """Test that different text produces different hash."""
        hash1 = _hash_text("Text 1")
        hash2 = _hash_text("Text 2")
        self.assertNotEqual(hash1, hash2)

    def test_hash_ignores_case_and_spacing(self):
        """Test that hash is same regardless of case and spacing."""
        hash1 = _hash_text("Test Text")
        hash2 = _hash_text("test  text")
        self.assertEqual(hash1, hash2)


class TestSpamDetection(unittest.TestCase):
    """Test spam and low-quality review detection."""

    def test_spam_detection_url(self):
        """Test that reviews with URLs are marked as spam."""
        self.assertTrue(_is_spam("Check out http://example.com for deals"))
        self.assertTrue(_is_spam("Visit www.example.com"))

    def test_spam_detection_email(self):
        """Test that reviews with emails are marked as spam."""
        self.assertTrue(_is_spam("Contact me at user@example.com"))

    def test_spam_detection_promo_code(self):
        """Test that reviews with promo codes are marked as spam."""
        self.assertTrue(_is_spam("Use promo code SAVE20"))
        self.assertTrue(_is_spam("discount code available"))

    def test_spam_detection_short_review(self):
        """Test that very short reviews are marked as spam."""
        self.assertTrue(_is_spam("Good"))
        self.assertTrue(_is_spam("Nice product"))

    def test_not_spam_valid_review(self):
        """Test that valid reviews are not marked as spam."""
        valid_review = "This is a great product with excellent quality and fast shipping"
        self.assertFalse(_is_spam(valid_review))

    def test_spam_detection_invalid_input(self):
        """Test spam detection with invalid input."""
        self.assertTrue(_is_spam(None))
        self.assertTrue(_is_spam(123))


class TestLanguageDetection(unittest.TestCase):
    """Test English language detection."""

    def test_english_detection_valid(self):
        """Test that English text is correctly identified."""
        text = "This is a great product with excellent quality"
        self.assertTrue(_is_english(text))

    def test_english_detection_empty(self):
        """Test that empty text returns False."""
        self.assertFalse(_is_english(""))
        self.assertFalse(_is_english(None))

    def test_english_detection_invalid_type(self):
        """Test language detection with invalid type."""
        self.assertFalse(_is_english(123))


class TestDuplicateRemoval(unittest.TestCase):
    """Test near-duplicate removal functionality."""

    def test_remove_exact_duplicates(self):
        """Test removal of exact duplicate reviews."""
        df = pd.DataFrame({
            "review_id": ["r1", "r2", "r3"],
            "review_text": [
                "This is a great product",
                "This is a great product",
                "Different review"
            ],
            "platform": ["amazon", "amazon", "amazon"],
            "product_name": ["Product A", "Product A", "Product A"],
        })

        filtered, logs = remove_near_duplicates(df, threshold=0.85)

        # Should keep first and last, remove middle duplicate
        self.assertEqual(len(filtered), 2)
        self.assertEqual(len(logs), 1)

    def test_remove_near_duplicates(self):
        """Test removal of near-duplicate reviews."""
        df = pd.DataFrame({
            "review_id": ["r1", "r2", "r3"],
            "review_text": [
                "This is a great product with excellent quality",
                "This is a great product with excellent quality!",  # Very similar
                "Completely different review about something else"
            ],
            "platform": ["amazon", "amazon", "amazon"],
            "product_name": ["Product A", "Product A", "Product A"],
        })

        filtered, logs = remove_near_duplicates(df, threshold=0.90)

        # Should remove the near-duplicate
        self.assertEqual(len(filtered), 2)
        self.assertGreater(len(logs), 0)

    def test_keep_different_products(self):
        """Test that similar reviews for different products are kept."""
        df = pd.DataFrame({
            "review_id": ["r1", "r2"],
            "review_text": [
                "This is a great product",
                "This is a great product"
            ],
            "platform": ["amazon", "amazon"],
            "product_name": ["Product A", "Product B"],  # Different products
        })

        filtered, logs = remove_near_duplicates(df, threshold=0.85)

        # Should keep both since they're for different products
        self.assertEqual(len(filtered), 2)
        self.assertEqual(len(logs), 0)

    def test_similarity_threshold(self):
        """Test that threshold correctly controls duplicate detection."""
        df = pd.DataFrame({
            "review_id": ["r1", "r2"],
            "review_text": [
                "This is a good product",
                "This is a great product"  # Similar but not identical
            ],
            "platform": ["amazon", "amazon"],
            "product_name": ["Product A", "Product A"],
        })

        # High threshold - should keep both
        filtered_high, logs_high = remove_near_duplicates(df, threshold=0.95)
        self.assertEqual(len(filtered_high), 2)

        # Low threshold - should remove one
        filtered_low, logs_low = remove_near_duplicates(df, threshold=0.70)
        self.assertEqual(len(filtered_low), 1)


class TestWindowFilter(unittest.TestCase):
    """Test date window filtering."""

    def test_window_filter_start_date(self):
        """Test filtering with start date."""
        df = pd.DataFrame({
            "review_date": ["2024-01-01", "2024-06-01", "2024-12-01"],
            "review_text": ["Review 1", "Review 2", "Review 3"]
        })

        filtered = _window_filter(df, start="2024-05-01", end=None)

        self.assertEqual(len(filtered), 2)  # Should keep last two

    def test_window_filter_end_date(self):
        """Test filtering with end date."""
        df = pd.DataFrame({
            "review_date": ["2024-01-01", "2024-06-01", "2024-12-01"],
            "review_text": ["Review 1", "Review 2", "Review 3"]
        })

        filtered = _window_filter(df, start=None, end="2024-07-01")

        self.assertEqual(len(filtered), 2)  # Should keep first two

    def test_window_filter_both_dates(self):
        """Test filtering with both start and end dates."""
        df = pd.DataFrame({
            "review_date": ["2024-01-01", "2024-06-01", "2024-12-01"],
            "review_text": ["Review 1", "Review 2", "Review 3"]
        })

        filtered = _window_filter(df, start="2024-05-01", end="2024-07-01")

        self.assertEqual(len(filtered), 1)  # Should keep only middle one

    def test_window_filter_no_dates(self):
        """Test that no filtering occurs when dates are not specified."""
        df = pd.DataFrame({
            "review_date": ["2024-01-01", "2024-06-01", "2024-12-01"],
            "review_text": ["Review 1", "Review 2", "Review 3"]
        })

        filtered = _window_filter(df, start=None, end=None)

        self.assertEqual(len(filtered), 3)  # Should keep all


if __name__ == "__main__":
    unittest.main()

"""
Integration tests for the complete pipeline flow.
Tests data flow, error handling, and end-to-end functionality.
"""

import json
import unittest
import tempfile
import shutil
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock
import pandas as pd

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.preprocessing.pipeline import preprocess
from src.llm_analysis.ollama_analyzer import OllamaAnalyzer
from src.grounding.semantic_grounding import SemanticGrounder, GroundingThresholds


class TestDataFlow(unittest.TestCase):
    """Test data flow through the pipeline."""

    def setUp(self):
        """Set up temporary directories for testing."""
        self.temp_dir = tempfile.mkdtemp()
        self.data_dir = Path(self.temp_dir) / "data"
        self.raw_dir = self.data_dir / "raw"
        self.processed_dir = self.data_dir / "processed"
        self.results_dir = self.data_dir / "results"
        self.logs_dir = self.data_dir / "logs"

        # Create directories
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

    def tearDown(self):
        """Clean up temporary directories."""
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_review_id_consistency(self):
        """Test that review IDs are consistent through the pipeline."""
        # Create sample data with known review IDs
        reviews = pd.DataFrame({
            "platform": ["amazon", "amazon"],
            "category": ["electronics", "electronics"],
            "product_name": ["Test Product", "Test Product"],
            "rating": [5, 3],
            "review_text": [
                "This is an excellent product with great quality",
                "Average product, nothing special but works fine"
            ],
            "review_date": ["2024-10-01", "2024-10-02"],
            "reviewer_name": ["John Doe", "Jane Smith"],
            "verified_purchase": [True, True],
        })

        # Save to raw directory
        reviews.to_csv(self.raw_dir / "test_reviews.csv", index=False)

        # Mock config path
        config_path = "config/config_alt.yaml"

        # Mock preprocess to use our temp directories
        with patch('src.preprocessing.pipeline.PreprocessPaths') as mock_paths:
            mock_paths.return_value.raw_dir = self.raw_dir
            mock_paths.return_value.scraped_dir = Path(self.temp_dir) / "scraped"
            mock_paths.return_value.processed_csv = self.processed_dir / "reviews_clean.csv"
            mock_paths.return_value.processed_sqlite = self.processed_dir / "reviews.sqlite"
            mock_paths.return_value.descriptive_json = self.results_dir / "descriptive.json"
            mock_paths.return_value.near_dup_csv = self.logs_dir / "near_duplicates.csv"

            # This test validates the logic exists
            # In real scenario, we'd run preprocess with temp paths
            pass

    def test_sentiment_score_ranges(self):
        """Test that sentiment scores are within valid range [-1, 1]."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        reviews = [
            {"review_id": "r1", "review_text": "Excellent product!", "rating_norm": 5.0},
            {"review_id": "r2", "review_text": "Terrible experience", "rating_norm": 1.0},
        ]

        # Mock invoke to return various responses
        test_responses = [
            ('{"sentiments": [{"review_id": "r1", "sentiment": 0.9}, {"review_id": "r2", "sentiment": -0.8}]}', "model"),
            ('{"sentiments": [{"review_id": "r1", "sentiment": 1.5}, {"review_id": "r2", "sentiment": -1.2}]}', "model"),  # Out of range
        ]

        for response, model in test_responses:
            with patch.object(analyzer, '_invoke', return_value=(response, model)):
                sentiments, _ = analyzer._sentiments(reviews)

                for sentiment in sentiments:
                    self.assertGreaterEqual(sentiment["sentiment"], -1.0,
                                          f"Sentiment {sentiment['sentiment']} is below -1.0")
                    self.assertLessEqual(sentiment["sentiment"], 1.0,
                                       f"Sentiment {sentiment['sentiment']} is above 1.0")

    def test_batch_size_handling(self):
        """Test that different batch sizes are handled correctly."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        # Test with different batch sizes
        for batch_size in [1, 5, 10]:
            reviews = [
                {"review_id": f"r{i}", "review_text": f"Review {i}", "rating_norm": 3.0}
                for i in range(batch_size)
            ]

            with patch.object(analyzer, '_summarize', return_value=("Summary", "model")):
                with patch.object(analyzer, '_themes', return_value=(["Theme"], "model")):
                    with patch.object(analyzer, '_sentiments', return_value=(
                        [{"review_id": f"r{i}", "sentiment": 0.0} for i in range(batch_size)],
                        "model"
                    )):
                        result = analyzer.analyze_batch(reviews, 0)

                        self.assertEqual(len(result["review_ids"]), batch_size)
                        self.assertEqual(len(result["sentiments"]), batch_size)


class TestErrorHandling(unittest.TestCase):
    """Test error handling throughout the pipeline."""

    def test_empty_review_handling(self):
        """Test handling of empty or null reviews."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        # Test with empty review text
        reviews = [
            {"review_id": "r1", "review_text": "", "rating_norm": 3.0},
        ]

        with patch.object(analyzer, '_invoke', return_value=("", "heuristic")):
            sentiments, model = analyzer._sentiments(reviews)
            self.assertEqual(len(sentiments), 1)

    def test_malformed_json_recovery(self):
        """Test recovery from malformed JSON responses."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        reviews = [
            {"review_id": "r1", "review_text": "Test review", "rating_norm": 4.0},
        ]

        malformed_responses = [
            '{"sentiments": [{"review_id": "r1", "sentiment": 0.5}',  # Missing closing brace
            '{"sentiments": [{"review_id": "r1" "sentiment": 0.5}]}',  # Missing comma
            'The sentiment is: {"sentiments": [{"review_id": "r1", "sentiment": 0.5}]}',  # Extra text
        ]

        for malformed in malformed_responses:
            with patch.object(analyzer, '_invoke', return_value=(malformed, "model")):
                # Should fall back to heuristic
                sentiments, model = analyzer._sentiments(reviews)
                self.assertEqual(len(sentiments), 1)
                self.assertIn("review_id", sentiments[0])
                self.assertIn("sentiment", sentiments[0])

    def test_missing_review_id_handling(self):
        """Test handling when review_id is missing."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        reviews = [
            {"review_text": "Test review", "rating_norm": 4.0},  # Missing review_id
        ]

        with patch.object(analyzer, '_invoke', return_value=("", "heuristic")):
            sentiments, model = analyzer._sentiments(reviews)
            # Should handle gracefully
            self.assertEqual(len(sentiments), 1)


class TestGroundingIntegration(unittest.TestCase):
    """Test grounding functionality integration."""

    def test_grounding_with_empty_summary(self):
        """Test grounding with empty or null summary."""
        grounder = SemanticGrounder(
            thresholds=GroundingThresholds(flag=0.5, strong=0.7)
        )

        result = grounder.assess("", ["Some review text"])

        self.assertIn("weak", result)
        self.assertIn("medium", result)
        self.assertIn("strong", result)
        self.assertIsInstance(result["weak"], int)

    def test_grounding_with_empty_reviews(self):
        """Test grounding with no review texts."""
        grounder = SemanticGrounder(
            thresholds=GroundingThresholds(flag=0.5, strong=0.7)
        )

        result = grounder.assess("Some summary", [])

        self.assertIn("weak", result)
        # All sentences should be weak with no reviews to ground against
        self.assertGreater(result["weak"], 0)

    def test_grounding_sentence_splitting(self):
        """Test that sentences are split correctly for grounding."""
        grounder = SemanticGrounder(
            thresholds=GroundingThresholds(flag=0.5, strong=0.7)
        )

        summary = "First sentence. Second sentence! Third sentence?"
        reviews = ["This is a review with similar content."]

        result = grounder.assess(summary, reviews)

        # Should have processed 3 sentences
        self.assertEqual(len(result["sentence_scores"]), 3)


class TestPipelineLogic(unittest.TestCase):
    """Test pipeline logic and flow."""

    def test_rating_normalization_logic(self):
        """Test rating normalization preserves relationships."""
        from src.preprocessing.pipeline import normalize_rating

        # Higher ratings should normalize to higher values
        ratings = [1, 2, 3, 4, 5]
        normalized = [normalize_rating(r) for r in ratings]

        for i in range(len(normalized) - 1):
            self.assertLessEqual(normalized[i], normalized[i + 1],
                               f"Rating {ratings[i]} normalized to {normalized[i]} should be <= "
                               f"rating {ratings[i+1]} normalized to {normalized[i+1]}")

    def test_heuristic_sentiment_consistency(self):
        """Test that heuristic sentiment is consistent with ratings."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            analyzer = OllamaAnalyzer("config/config_alt.yaml")

        # High-rated positive review
        positive_review = {
            "review_id": "r1",
            "review_text": "excellent amazing wonderful great fantastic",
            "rating_norm": 5.0
        }

        # Low-rated negative review
        negative_review = {
            "review_id": "r2",
            "review_text": "terrible awful horrible bad disappointing",
            "rating_norm": 1.0
        }

        with patch.object(analyzer, '_invoke', return_value=("", "heuristic")):
            sentiments, _ = analyzer._sentiments([positive_review, negative_review])

            positive_sentiment = next(s for s in sentiments if s["review_id"] == "r1")
            negative_sentiment = next(s for s in sentiments if s["review_id"] == "r2")

            # Positive review should have higher sentiment than negative
            self.assertGreater(positive_sentiment["sentiment"],
                             negative_sentiment["sentiment"])


if __name__ == "__main__":
    unittest.main()

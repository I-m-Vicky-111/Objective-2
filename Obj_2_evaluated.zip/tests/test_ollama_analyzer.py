"""
Comprehensive tests for OllamaAnalyzer including JSON parsing, error handling,
and retry logic.
"""

import json
import unittest
from unittest.mock import MagicMock, Mock, patch

import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.llm_analysis.ollama_analyzer import OllamaAnalyzer


class TestJSONExtraction(unittest.TestCase):
    """Test the robust JSON extraction method."""

    def setUp(self):
        """Set up test analyzer."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            self.analyzer = OllamaAnalyzer("config/config_alt.yaml")

    def test_extract_clean_json_object(self):
        """Test extraction of clean JSON object."""
        text = '{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}'
        result = self.analyzer._extract_json_from_text(text)
        self.assertEqual(result["sentiments"][0]["review_id"], "1")

    def test_extract_json_with_markdown(self):
        """Test extraction when JSON is wrapped in markdown code blocks."""
        text = '```json\n{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}\n```'
        result = self.analyzer._extract_json_from_text(text)
        self.assertEqual(result["sentiments"][0]["review_id"], "1")

    def test_extract_json_with_text_before(self):
        """Test extraction when text appears before JSON."""
        text = 'Here is the analysis:\n{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}'
        result = self.analyzer._extract_json_from_text(text)
        self.assertEqual(result["sentiments"][0]["review_id"], "1")

    def test_extract_json_with_text_after(self):
        """Test extraction when text appears after JSON."""
        text = '{"sentiments": [{"review_id": "1", "sentiment": 0.5}]}\nThat\'s the result.'
        result = self.analyzer._extract_json_from_text(text)
        self.assertEqual(result["sentiments"][0]["review_id"], "1")

    def test_extract_json_array(self):
        """Test extraction of JSON array."""
        text = '["Theme 1", "Theme 2", "Theme 3"]'
        result = self.analyzer._extract_json_from_text(text)
        # Array should be wrapped in sentiments key
        self.assertIn("sentiments", result)

    def test_extract_nested_json(self):
        """Test extraction of nested JSON with multiple braces."""
        text = 'Result: {"data": {"sentiments": [{"review_id": "1", "sentiment": 0.5}]}}'
        result = self.analyzer._extract_json_from_text(text)
        self.assertIsInstance(result, dict)

    def test_invalid_json_raises_error(self):
        """Test that invalid JSON raises ValueError."""
        text = 'This is not JSON at all, just plain text.'
        with self.assertRaises(ValueError):
            self.analyzer._extract_json_from_text(text)


class TestSentimentAnalysis(unittest.TestCase):
    """Test sentiment analysis functionality."""

    def setUp(self):
        """Set up test analyzer with mocked server check."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            self.analyzer = OllamaAnalyzer("config/config_alt.yaml")

    def test_sentiment_with_valid_response(self):
        """Test sentiment analysis with valid model response."""
        reviews = [
            {"review_id": "r1", "review_text": "Great product!", "rating_norm": 5.0},
            {"review_id": "r2", "review_text": "Terrible quality", "rating_norm": 1.0},
        ]

        # Mock the invoke method to return valid JSON
        valid_response = '{"sentiments": [{"review_id": "r1", "sentiment": 0.8}, {"review_id": "r2", "sentiment": -0.7}]}'
        with patch.object(self.analyzer, '_invoke', return_value=(valid_response, "qwen2.5:3b-instruct")):
            sentiments, model = self.analyzer._sentiments(reviews)

        self.assertEqual(len(sentiments), 2)
        self.assertEqual(sentiments[0]["review_id"], "r1")
        self.assertAlmostEqual(sentiments[0]["sentiment"], 0.8, places=2)

    def test_sentiment_with_markdown_response(self):
        """Test sentiment analysis when model returns markdown-wrapped JSON."""
        reviews = [
            {"review_id": "r1", "review_text": "Great product!", "rating_norm": 5.0},
        ]

        markdown_response = '```json\n{"sentiments": [{"review_id": "r1", "sentiment": 0.8}]}\n```'
        with patch.object(self.analyzer, '_invoke', return_value=(markdown_response, "qwen2.5:3b-instruct")):
            sentiments, model = self.analyzer._sentiments(reviews)

        self.assertEqual(len(sentiments), 1)
        self.assertEqual(sentiments[0]["review_id"], "r1")

    def test_sentiment_fallback_to_heuristic(self):
        """Test fallback to heuristic when JSON parsing fails."""
        reviews = [
            {"review_id": "r1", "review_text": "This is a great amazing product!", "rating_norm": 5.0},
        ]

        # Invalid response that can't be parsed
        with patch.object(self.analyzer, '_invoke', return_value=("Invalid JSON response", "qwen2.5:3b-instruct")):
            sentiments, model = self.analyzer._sentiments(reviews)

        # Should fall back to heuristic
        self.assertEqual(len(sentiments), 1)
        self.assertEqual(sentiments[0]["review_id"], "r1")
        # Heuristic should give positive sentiment for "great" and "amazing"
        self.assertGreater(sentiments[0]["sentiment"], 0)

    def test_sentiment_heuristic_mode(self):
        """Test sentiment analysis in pure heuristic mode."""
        reviews = [
            {"review_id": "r1", "review_text": "terrible awful bad product", "rating_norm": 1.0},
            {"review_id": "r2", "review_text": "excellent amazing wonderful", "rating_norm": 5.0},
        ]

        with patch.object(self.analyzer, '_invoke', return_value=("", "heuristic")):
            sentiments, model = self.analyzer._sentiments(reviews)

        self.assertEqual(len(sentiments), 2)
        # Negative review should have negative sentiment
        self.assertLess(sentiments[0]["sentiment"], 0)
        # Positive review should have positive sentiment
        self.assertGreater(sentiments[1]["sentiment"], 0)


class TestThemeExtraction(unittest.TestCase):
    """Test theme extraction functionality."""

    def setUp(self):
        """Set up test analyzer."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            self.analyzer = OllamaAnalyzer("config/config_alt.yaml")

    def test_themes_with_valid_array(self):
        """Test theme extraction with valid JSON array."""
        reviews = [
            {"review_id": "r1", "review_text": "Great quality and good price", "rating_norm": 5.0},
        ]

        valid_response = '["Product Quality", "Value for Money", "Customer Service"]'
        with patch.object(self.analyzer, '_invoke', return_value=(valid_response, "qwen2.5:3b-instruct")):
            themes, model = self.analyzer._themes(reviews)

        self.assertEqual(len(themes), 3)
        self.assertIn("Product Quality", themes)

    def test_themes_with_object_response(self):
        """Test theme extraction when response is object with themes key."""
        reviews = [
            {"review_id": "r1", "review_text": "Great quality", "rating_norm": 5.0},
        ]

        object_response = '{"themes": ["Product Quality", "Design"]}'
        with patch.object(self.analyzer, '_invoke', return_value=(object_response, "qwen2.5:3b-instruct")):
            themes, model = self.analyzer._themes(reviews)

        self.assertEqual(len(themes), 2)
        self.assertIn("Product Quality", themes)

    def test_themes_fallback_to_heuristic(self):
        """Test fallback to heuristic theme extraction."""
        reviews = [
            {"review_id": "r1", "review_text": "Great quality and excellent customer service", "rating_norm": 5.0},
        ]

        with patch.object(self.analyzer, '_invoke', return_value=("Invalid response", "qwen2.5:3b-instruct")):
            themes, model = self.analyzer._themes(reviews)

        # Heuristic should find themes based on keywords
        self.assertGreater(len(themes), 0)
        # Should contain quality or service based themes
        self.assertTrue(any("Quality" in theme or "Service" in theme for theme in themes))


class TestRetryLogic(unittest.TestCase):
    """Test retry and error handling logic."""

    def setUp(self):
        """Set up test analyzer."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            self.analyzer = OllamaAnalyzer("config/config_alt.yaml")

    @patch('src.llm_analysis.ollama_analyzer.requests.post')
    @patch('src.llm_analysis.ollama_analyzer.time.sleep')
    def test_retry_on_timeout(self, mock_sleep, mock_post):
        """Test that requests are retried on timeout."""
        import requests

        # First two calls timeout, third succeeds
        mock_post.side_effect = [
            requests.Timeout("Timeout 1"),
            requests.Timeout("Timeout 2"),
            Mock(status_code=200, json=lambda: {"response": "Success"}),
        ]

        result = self.analyzer._request_generate("qwen2.5:3b-instruct", "test prompt", 100)

        self.assertEqual(result, "Success")
        # Should have been called 3 times
        self.assertEqual(mock_post.call_count, 3)
        # Should have slept twice (after first two failures)
        self.assertEqual(mock_sleep.call_count, 2)

    @patch('src.llm_analysis.ollama_analyzer.requests.post')
    @patch('src.llm_analysis.ollama_analyzer.time.sleep')
    def test_max_retries_exceeded(self, mock_sleep, mock_post):
        """Test that exception is raised after max retries."""
        import requests

        # All calls timeout
        mock_post.side_effect = requests.Timeout("Persistent timeout")

        with self.assertRaises(requests.Timeout):
            self.analyzer._request_generate("qwen2.5:3b-instruct", "test prompt", 100)

        # Should have tried 4 times (initial + 3 retries)
        self.assertEqual(mock_post.call_count, 4)


class TestBatchAnalysis(unittest.TestCase):
    """Test complete batch analysis."""

    def setUp(self):
        """Set up test analyzer."""
        with patch.object(OllamaAnalyzer, '_check_server', return_value=True):
            self.analyzer = OllamaAnalyzer("config/config_alt.yaml")

    def test_analyze_batch_complete(self):
        """Test complete batch analysis with all components."""
        reviews = [
            {"review_id": "r1", "review_text": "Great quality product", "rating_norm": 5.0},
            {"review_id": "r2", "review_text": "Poor customer service", "rating_norm": 2.0},
        ]

        # Mock all three analysis methods
        with patch.object(self.analyzer, '_summarize', return_value=("Overall mixed feedback", "qwen2.5:3b-instruct")):
            with patch.object(self.analyzer, '_themes', return_value=(["Quality", "Service"], "qwen2.5:3b-instruct")):
                with patch.object(self.analyzer, '_sentiments', return_value=(
                    [{"review_id": "r1", "sentiment": 0.8}, {"review_id": "r2", "sentiment": -0.6}],
                    "qwen2.5:3b-instruct"
                )):
                    result = self.analyzer.analyze_batch(reviews, 0)

        self.assertEqual(result["batch_index"], 0)
        self.assertEqual(result["summary"], "Overall mixed feedback")
        self.assertEqual(len(result["themes"]), 2)
        self.assertEqual(len(result["sentiments"]), 2)
        self.assertIn("models_used", result)
        self.assertIn("elapsed_s", result)


if __name__ == "__main__":
    unittest.main()

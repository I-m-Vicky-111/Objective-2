"""
Quick script to compare human vs model sentiments in detail.
"""
import io
import sys
import json
import pandas as pd
import numpy as np

# Fix Windows console encoding
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except (AttributeError, io.UnsupportedOperation):
        pass

# Load validation data
refs = pd.read_csv('data/validation/references.csv')
analysis = json.load(open('data/results/analysis_results.json'))

# Build lookup
lookup = {}
for batch in analysis['batches']:
    for sent in batch['sentiments']:
        lookup[sent['review_id']] = sent['sentiment']

# Compare
print('='*80)
print('DETAILED HUMAN VS MODEL SENTIMENT COMPARISON')
print('='*80)
print()

matches = []
human_vals = []
model_vals = []

for i, row in refs.iterrows():
    rid = row['review_id']
    human = row['human_sentiment']
    model = lookup.get(rid)

    if model is not None:
        matches.append((rid, human, model))
        human_vals.append(human)
        model_vals.append(model)

print(f'Total references: {len(refs)}')
print(f'Matched: {len(matches)}')
print()

# Show first 15 comparisons
print('Sample Comparisons (Human vs Model):')
print('-'*80)
print(f'{"#":<4} {"Human":>8} {"Model":>8} {"Diff":>8} {"Agreement"}')
print('-'*80)

for i, (rid, human, model) in enumerate(matches[:15], 1):
    diff = abs(human - model)
    agree = "✓ Good" if diff < 0.3 else ("~ OK" if diff < 0.5 else "✗ BAD")
    print(f'{i:<4} {human:>+8.2f} {model:>+8.2f} {diff:>8.2f} {agree}')

print()
print('='*80)
print('STATISTICS')
print('='*80)
print(f'Human sentiment - Mean: {np.mean(human_vals):.3f}, Std: {np.std(human_vals):.3f}')
print(f'Model sentiment - Mean: {np.mean(model_vals):.3f}, Std: {np.std(model_vals):.3f}')
print(f'Mean Absolute Error: {np.mean([abs(h-m) for h, m in zip(human_vals, model_vals)]):.3f}')
print(f'Correlation: {np.corrcoef(human_vals, model_vals)[0,1]:.3f}')
print()

# Check if model is just outputting same values
print('Model output distribution:')
unique_models = pd.Series(model_vals).value_counts().head(10)
print(unique_models)
print()

# Check polarity flips
print('POLARITY FLIP ANALYSIS:')
print('-'*80)
neg_human_pos_model = sum(1 for h, m in zip(human_vals, model_vals) if h < -0.3 and m > 0.3)
pos_human_neg_model = sum(1 for h, m in zip(human_vals, model_vals) if h > 0.3 and m < -0.3)
print(f'Negative humans → Positive models: {neg_human_pos_model}')
print(f'Positive humans → Negative models: {pos_human_neg_model}')
print()

# Agreement by bin
print('AGREEMENT BY SENTIMENT CATEGORY:')
print('-'*80)

def bin_sentiment(val):
    if val <= -0.6:
        return "Very Negative"
    elif val <= -0.3:
        return "Negative"
    elif val <= 0.3:
        return "Neutral"
    elif val <= 0.6:
        return "Positive"
    else:
        return "Very Positive"

correct_bin = sum(1 for h, m in zip(human_vals, model_vals) if bin_sentiment(h) == bin_sentiment(m))
print(f'Same bin agreement: {correct_bin}/{len(human_vals)} = {100*correct_bin/len(human_vals):.1f}%')

import requests
import json

prompt = """
Analyze the sentiment of each review below. Output ONLY a valid JSON object with this exact format:
{"sentiments":[{"review_id":"id1","sentiment":0.5},{"review_id":"id2","sentiment":-0.3}]}

Use sentiment scores from -1.0 (very negative) to 1.0 (very positive).
Do not include any explanations, just the JSON object.

Review ID: test_1
Rating (1-5 norm): 0.80
Text: Great product, really enjoyed using it. Highly recommended for anyone.

Review ID: test_2
Rating (1-5 norm): 0.60
Text: Good but could be better. Some features are missing.
"""

payload = {
    "model": "qwen2.5:3b-instruct",
    "prompt": prompt,
    "stream": False,
    "options": {
        "temperature": 0.3,
        "top_p": 0.9,
        "repeat_penalty": 1.1,
        "num_predict": 500
    }
}

print("Testing sentiment analysis with qwen2.5:3b-instruct...")
resp = requests.post('http://127.0.0.1:11434/api/generate', 
                   json=payload, 
                   timeout=30)

if resp.status_code == 200:
    response_text = resp.json().get("response", "")
    print(f"\nRaw response:\n{response_text}\n")
    print("="*60)
    
    # Try to parse it
    try:
        parsed = json.loads(response_text)
        print("✓ JSON parsed successfully!")
        print(f"Sentiments: {parsed}")
    except json.JSONDecodeError as e:
        print(f"✗ JSON parse failed: {e}")
        print(f"Error at position: {e.pos}")
        if e.pos < len(response_text):
            print(f"Context: ...{response_text[max(0,e.pos-50):e.pos+50]}...")
else:
    print(f"Error: {resp.status_code} - {resp.text}")

"""
Quick test to verify emoji UTF-8 encoding fix on Windows.
"""
import io
import sys
import logging

# Fix Windows console encoding for emoji support
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    except (AttributeError, io.UnsupportedOperation):
        pass

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Test emoji output
print("=" * 80)
print("Testing Emoji Support on Windows")
print("=" * 80)

emojis_to_test = [
    ("✅", "Check mark"),
    ("📝", "Memo"),
    ("🎨", "Artist palette"),
    ("😊", "Smiling face"),
    ("⏱️", "Stopwatch"),
    ("🤖", "Robot"),
    ("📊", "Bar chart"),
    ("🔍", "Magnifying glass"),
    ("📦", "Package"),
]

logger.info("\n🧪 EMOJI ENCODING TEST")
logger.info("=" * 60)

for emoji, name in emojis_to_test:
    try:
        logger.info(f"{emoji} {name}")
        print(f"✓ {emoji} {name} - OK")
    except UnicodeEncodeError as e:
        print(f"✗ {name} - FAILED: {e}")

logger.info("=" * 60)
logger.info("✅ All emojis displayed successfully!")
print("\n✅ Emoji encoding test PASSED!")
print("\nYou can now run the pipeline without encoding errors:")
print("  python run_pipeline_with_audit.py --config config/config_alt.yaml")
